package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_5819;

@Mixin(class_1927.class)
public interface ExplosionAccessor {

    @Accessor
    boolean isFire();

    @Accessor
    class_1927.class_4179 getBlockInteraction();

    @Accessor
    class_1937 getLevel();

    @Accessor
    class_5819 getRandom();

    @Accessor
    double getX();

    @Accessor
    double getY();

    @Accessor
    double getZ();

    @Accessor
    float getRadius();

    @Accessor
    class_1297 getSource();

}
