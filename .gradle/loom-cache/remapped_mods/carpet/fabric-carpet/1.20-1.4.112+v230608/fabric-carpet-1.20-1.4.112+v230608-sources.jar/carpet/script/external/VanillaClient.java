package carpet.script.external;

import carpet.mixins.ShulkerBoxAccessMixin;
import net.minecraft.class_2627;
import net.minecraft.class_602;
import net.minecraft.class_827;

public class VanillaClient
{
    public static class_602<?> ShulkerBoxRenderer_model(class_827<class_2627> shulkerBoxRenderer) {
        return ((ShulkerBoxAccessMixin)shulkerBoxRenderer).getModel();
    }
}
