package carpet.fakes;

import java.util.List;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5455;

public interface RecipeManagerInterface
{
    /**
     * Gets all the recipes for a given item. Also used for {@link carpet.helpers.HopperCounter#guessColor} to guess the
     * colour of an item to display it prettily
     */
    List<class_1860<?>> getAllMatching(final class_3956<?> type, final class_2960 output, final class_5455 registryAccess);
}
