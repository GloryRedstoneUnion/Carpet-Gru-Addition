package carpet.fakes;

import net.minecraft.class_2487;

public interface BlockStateArgumentInterface
{
    class_2487 getCMTag();
}
