package carpet.mixins;

import carpet.fakes.EntityInterface;
import carpet.script.EntityEventsGroup;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import static carpet.script.CarpetEventServer.Event.PLAYER_ATTACKS_ENTITY;
import static carpet.script.CarpetEventServer.Event.PLAYER_DEALS_DAMAGE;
import static carpet.script.CarpetEventServer.Event.PLAYER_INTERACTS_WITH_ENTITY;
import static carpet.script.CarpetEventServer.Event.PLAYER_TAKES_DAMAGE;
import static carpet.script.CarpetEventServer.Event.PLAYER_COLLIDES_WITH_ENTITY;

@Mixin(class_1657.class)
public abstract class Player_scarpetEventsMixin extends class_1309
{
    protected Player_scarpetEventsMixin(class_1299<? extends class_1309> type, class_1937 world)
    {
        super(type, world);
    }

    @Inject(method = "actuallyHurt", cancellable = true, locals = LocalCapture.CAPTURE_FAILHARD, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;getDamageAfterArmorAbsorb(Lnet/minecraft/world/damagesource/DamageSource;F)F"
    ))
    private void playerTakingDamage(class_1282 source, float amount, CallbackInfo ci)
    {
        // version of LivingEntity_scarpetEventsMixin::entityTakingDamage
        ((EntityInterface)this).getEventContainer().onEvent(EntityEventsGroup.Event.ON_DAMAGE, amount, source);
        if (PLAYER_TAKES_DAMAGE.isNeeded())
        {
            if(PLAYER_TAKES_DAMAGE.onDamage(this, amount, source)) {
                ci.cancel();
            }
        }
        if (source.method_5529() instanceof class_3222 && PLAYER_DEALS_DAMAGE.isNeeded())
        {
            if(PLAYER_DEALS_DAMAGE.onDamage(this, amount, source)) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "touch", at = @At("HEAD"))
    private void onEntityCollision(class_1297 entity, CallbackInfo ci)
    {
        if (PLAYER_COLLIDES_WITH_ENTITY.isNeeded() && !method_37908().field_9236)
        {
            PLAYER_COLLIDES_WITH_ENTITY.onEntityHandAction((class_3222)(Object)this, entity, null);
        }
    }

    @Inject(method = "interactOn", cancellable = true, at = @At("HEAD"))
    private void doInteract(class_1297 entity, class_1268 hand, CallbackInfoReturnable<class_1269> cir)
    {
        if (!method_37908().field_9236 && PLAYER_INTERACTS_WITH_ENTITY.isNeeded())
        {
            if(PLAYER_INTERACTS_WITH_ENTITY.onEntityHandAction((class_3222) (Object)this, entity, hand)) {
                cir.setReturnValue(class_1269.field_5811);
                cir.cancel();
            }
        }
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void onAttack(class_1297 target, CallbackInfo ci)
    {
        if (!method_37908().field_9236 && PLAYER_ATTACKS_ENTITY.isNeeded() && target.method_5732())
        {
            if(PLAYER_ATTACKS_ENTITY.onEntityHandAction((class_3222) (Object)this, target, null)) {
                ci.cancel();
            }
        }
    }
}
