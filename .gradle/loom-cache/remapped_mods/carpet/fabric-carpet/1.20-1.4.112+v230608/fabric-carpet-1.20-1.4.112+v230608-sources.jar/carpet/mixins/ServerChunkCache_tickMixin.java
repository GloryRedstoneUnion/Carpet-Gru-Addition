package carpet.mixins;

import carpet.fakes.MinecraftServerInterface;
import carpet.fakes.ThreadedAnvilChunkStorageInterface;
import carpet.helpers.ServerTickRateManager;
import carpet.utils.CarpetProfiler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2818;
import net.minecraft.class_3193;
import net.minecraft.class_3204;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3898;
import com.google.common.collect.Lists;

@Mixin(class_3215.class)
public abstract class ServerChunkCache_tickMixin
{

    @Shadow @Final class_3218 level;

    @Shadow @Final
    public class_3898 chunkMap;

    CarpetProfiler.ProfilerToken currentSection;

    @Inject(method = "tickChunks", at = @At("HEAD"))
    private void startSpawningSection(CallbackInfo ci)
    {
        currentSection = CarpetProfiler.start_section(level, "Spawning", CarpetProfiler.TYPE.GENERAL);
    }

    @Inject(method = "tickChunks", at = @At(
            value = "FIELD",
            target = "net/minecraft/server/level/ServerChunkCache.level:Lnet/minecraft/server/level/ServerLevel;",
            ordinal = 10
    ))
    private void skipChunkTicking(CallbackInfo ci)
    {
        if (currentSection != null)
        {
            CarpetProfiler.end_current_section(currentSection);
        }
    }

    @Inject(method = "tickChunks", at = @At(
            value = "INVOKE",
            target = "net/minecraft/server/level/ServerLevel.tickChunk(Lnet/minecraft/world/level/chunk/LevelChunk;I)V",
            shift = At.Shift.AFTER
    ))
    private void resumeSpawningSection(CallbackInfo ci)
    {
        currentSection = CarpetProfiler.start_section(level, "Spawning", CarpetProfiler.TYPE.GENERAL);
    }

    @Inject(method = "tickChunks", at = @At("RETURN"))
    private void stopSpawningSection(CallbackInfo ci)
    {
        if (currentSection != null)
        {
            CarpetProfiler.end_current_section(currentSection);
        }
    }

    //// Tick freeze
    @Redirect(method = "tickChunks", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerLevel;isDebug()Z"
    ))
    private boolean skipChunkTicking(class_3218 serverWorld)
    {
        boolean debug = serverWorld.method_27982();
        if (!((MinecraftServerInterface)serverWorld.method_8503()).getTickRateManager().runsNormally())
        {
            // simplified chunk tick iteration assuming world is frozen otherwise as suggested by Hadron67
            // to be kept in sync with the original injection source
            if (!debug){
                List<class_3193> holders = Lists.newArrayList(((ThreadedAnvilChunkStorageInterface)chunkMap).getChunksCM());
                Collections.shuffle(holders);
                for (class_3193 holder: holders){
                    Optional<class_2818> optional = holder.method_16145().getNow(class_3193.field_16427).left();
                    if (optional.isPresent()){
                        holder.method_14006(optional.get());
                    }
                }
            }
            return true;
        }
        return debug;
    }

    @Redirect(method = "tick", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/DistanceManager;purgeStaleTickets()V"
    ))
    private void pauseTicketSystem(class_3204 distanceManager)
    {
        // pausing expiry of tickets
        // that will prevent also chunks from unloading, so require a deep frozen state
        ServerTickRateManager trm = ((MinecraftServerInterface) level.method_8503()).getTickRateManager();
        if (!trm.runsNormally() && trm.deeplyFrozen()) return;
        distanceManager.method_14045();
    }

}
