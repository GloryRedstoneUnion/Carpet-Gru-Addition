package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.RedstoneWireBlockInterface;
import carpet.helpers.RedstoneWireTurbo;
import com.google.common.collect.Sets;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2457;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

import static net.minecraft.class_2457.field_11432;

@Mixin(class_2457.class)
public abstract class RedstoneWireBlock_fastMixin implements RedstoneWireBlockInterface {

    @Shadow
    private void updatePowerStrength(class_1937 world_1, class_2338 blockPos_1, class_2680 blockState_1) { }

    @Shadow
    private int calculateTargetStrength(class_1937 world, class_2338 pos) { return 0; }

    @Override
    @Accessor("shouldSignal")
    public abstract void setWiresGivePower(boolean wiresGivePower);

    @Override
    @Accessor("shouldSignal")
    public abstract boolean getWiresGivePower();

    // =

    private RedstoneWireTurbo wireTurbo = null;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onRedstoneWireBlockCTOR(class_4970.class_2251 settings, CallbackInfo ci) {
        //noinspection ConstantConditions
        wireTurbo = new RedstoneWireTurbo((class_2457) (Object) this);
    }

    // =

    public void fastUpdate(class_1937 world, class_2338 pos, class_2680 state, class_2338 source) {
        // [CM] fastRedstoneDust -- update based on carpet rule
        if (CarpetSettings.fastRedstoneDust) {
            wireTurbo.updateSurroundingRedstone(world, pos, state, source);
            return;
        }
        updatePowerStrength(world, pos, state);
    }

    /**
     * @author theosib, soykaf, gnembon
     */
    @Inject(method = "updatePowerStrength", at = @At("HEAD"), cancellable = true)
    private void updateLogicAlternative(class_1937 world, class_2338 pos, class_2680 state, CallbackInfo cir) {
        if (CarpetSettings.fastRedstoneDust) {
            updateLogicPublic(world, pos, state);
            cir.cancel();
        }
    }

    @Override
    public class_2680 updateLogicPublic(class_1937 world_1, class_2338 blockPos_1, class_2680 blockState_1) {
        int i = this.calculateTargetStrength(world_1, blockPos_1);
        class_2680 blockState = blockState_1;
        if (blockState_1.method_11654(field_11432) != i) {
            blockState_1 = blockState_1.method_11657(field_11432, i);
            if (world_1.method_8320(blockPos_1) == blockState) {
                // [Space Walker] suppress shape updates and emit those manually to
                // bypass the new neighbor update stack.
                if (world_1.method_8652(blockPos_1, blockState_1, class_2248.field_31031 | class_2248.field_31028))
                    wireTurbo.updateNeighborShapes(world_1, blockPos_1, blockState_1);
            }

            if (!CarpetSettings.fastRedstoneDust) {
                Set<class_2338> set = Sets.newHashSet();
                set.add(blockPos_1);
                class_2350[] var6 = class_2350.values();
                int var7 = var6.length;

                for (int var8 = 0; var8 < var7; ++var8) {
                    class_2350 direction = var6[var8];
                    set.add(blockPos_1.method_10093(direction));
                }

                for (class_2338 blockPos : set) {
                    world_1.method_8452(blockPos, blockState_1.method_26204());
                }
            }
        }
        return blockState_1;
    }

    // =


    @Redirect(method = "onPlace", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/RedStoneWireBlock;updatePowerStrength(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V"))
    private void redirectOnBlockAddedUpdate(class_2457 self, class_1937 world_1, class_2338 blockPos_1, class_2680 blockState_1) {
        fastUpdate(world_1, blockPos_1, blockState_1, null);
    }

    @Redirect(method = "onRemove", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/RedStoneWireBlock;updatePowerStrength(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V"))
    private void redirectOnStateReplacedUpdate(class_2457 self, class_1937 world_1, class_2338 blockPos_1, class_2680 blockState_1) {
        fastUpdate(world_1, blockPos_1, blockState_1, null);
    }

    @Redirect(method = "neighborChanged", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/RedStoneWireBlock;updatePowerStrength(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V"))
    private void redirectNeighborUpdateUpdate(
            class_2457 self,
            class_1937 world_1,
            class_2338 blockPos_1,
            class_2680 blockState_1,
            class_2680 blockState_2,
            class_1937 world_2,
            class_2338 blockPos_2,
            class_2248 block_1,
            class_2338 blockPos_3,
            boolean boolean_1) {
        fastUpdate(world_1, blockPos_1, blockState_1, blockPos_3);
    }
}
