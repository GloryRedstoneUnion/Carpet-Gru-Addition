@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.annotation;

import javax.annotation.ParametersAreNonnullByDefault;
