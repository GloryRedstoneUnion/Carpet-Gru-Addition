package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2168;
import net.minecraft.class_6413;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_6413.class)
public class PerfCommand_permissionMixin
{
    @Inject(method = "method_37340", at = @At("HEAD"), cancellable = true, remap = false)
    private static void canRun(class_2168 source, CallbackInfoReturnable<Boolean> cir)
    {
        cir.setReturnValue(source.method_9259(CarpetSettings.perfPermissionLevel));
    }

}
