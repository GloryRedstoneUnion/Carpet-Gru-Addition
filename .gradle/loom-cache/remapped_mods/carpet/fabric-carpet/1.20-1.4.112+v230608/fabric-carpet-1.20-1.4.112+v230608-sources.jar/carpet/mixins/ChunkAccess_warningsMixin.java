package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2338;
import net.minecraft.class_2791;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2791.class)
public abstract class ChunkAccess_warningsMixin
{
    // failed to mixin into interface. need to mixin in two places that uses it
    @Inject(method = "markPosForPostprocessing(Lnet/minecraft/core/BlockPos;)V",
        at =@At("HEAD"), cancellable = true)
    private void squashWarnings(class_2338 blockPos_1, CallbackInfo ci)
    {
        if (CarpetSettings.skipGenerationChecks.get()) ci.cancel();
    }
}
