package carpet.mixins;

import carpet.fakes.InventoryBearerInterface;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1496;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1496.class)
public class HorseBaseEntity_scarpetMixin implements InventoryBearerInterface
{

    @Shadow protected class_1277 inventory;

    @Override
    public class_1263 getCMInventory()
    {
        return inventory;
    }
}
