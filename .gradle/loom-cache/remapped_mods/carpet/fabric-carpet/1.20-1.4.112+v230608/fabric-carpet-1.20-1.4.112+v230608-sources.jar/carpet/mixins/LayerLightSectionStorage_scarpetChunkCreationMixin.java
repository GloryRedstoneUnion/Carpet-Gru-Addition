package carpet.mixins;

import java.util.Arrays;
import net.minecraft.class_2804;
import net.minecraft.class_3556;
import net.minecraft.class_3560;
import net.minecraft.class_4076;
import carpet.fakes.Lighting_scarpetChunkCreationInterface;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.LongSet;

@Mixin(class_3560.class)
public abstract class LayerLightSectionStorage_scarpetChunkCreationMixin implements Lighting_scarpetChunkCreationInterface
{
    @Shadow
    protected abstract class_2804 getDataLayer(long sectionPos, boolean cached);

    @Shadow
    @Final
    protected LongSet changedSections;

    @Shadow
    @Final
    protected class_3556<?> updatingSectionData;

    @Shadow protected abstract boolean storingLightForSection(long sectionPos);

    @Shadow
    @Final
    protected Long2ObjectMap<class_2804> queuedSections;

    @Override
    public void removeLightData(long cPos)
    {

        for (int y = -1; y < 17; ++y)
        {
            long sectionPos = class_4076.method_18685(class_4076.method_18686(cPos), y, class_4076.method_18690(cPos));

            this.queuedSections.remove(sectionPos);

            if (this.storingLightForSection(sectionPos))
            {
                if (this.changedSections.add(sectionPos))
                    this.updatingSectionData.method_15502(sectionPos);

                Arrays.fill(this.getDataLayer(sectionPos, true).method_12137(), (byte) 0);
            }
        }
    }
}
