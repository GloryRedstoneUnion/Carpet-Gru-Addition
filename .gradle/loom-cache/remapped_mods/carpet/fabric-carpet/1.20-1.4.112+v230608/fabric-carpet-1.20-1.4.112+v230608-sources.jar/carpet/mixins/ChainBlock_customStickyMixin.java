package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;

import carpet.CarpetSettings;
import carpet.CarpetSettings.ChainStoneMode;
import carpet.fakes.BlockBehaviourInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;
import net.minecraft.class_5172;
import net.minecraft.class_5551;

@Mixin(class_5172.class)
public class ChainBlock_customStickyMixin implements BlockBehaviourInterface {

    @Override
    public boolean isSticky(class_2680 state) {
        return CarpetSettings.chainStone.enabled();
    }

    @Override
    public boolean isStickyToNeighbor(class_1937 level, class_2338 pos, class_2680 state, class_2338 neighborPos, class_2680 neighborState, class_2350 dir, class_2350 moveDir) {
        class_2351 axis = state.method_11654(class_5172.field_11459);

        if (axis != dir.method_10166()) {
            return false;
        }

        if (CarpetSettings.chainStone == ChainStoneMode.STICK_TO_ALL) {
            return true;
        }
        if (neighborState.method_27852((class_2248)(Object)this)) {
            return axis == neighborState.method_11654(class_5172.field_11459);
        }
        if (neighborState.method_27852(class_2246.field_10455)) {
            return axis == neighborState.method_11654(class_5551.field_10927).method_10166();
        }

        return class_2248.method_20044(level, neighborPos, dir.method_10153());
    }
}
