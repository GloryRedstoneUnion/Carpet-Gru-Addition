package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import carpet.helpers.QuasiConnectivity;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

@Mixin(class_2315.class)
public class DispenserBlock_qcMixin {

    @Redirect(
        method = "neighborChanged",
        at = @At(
            value = "INVOKE",
            ordinal = 1,
            target =  "Lnet/minecraft/world/level/Level;hasNeighborSignal(Lnet/minecraft/core/BlockPos;)Z"
        )
    )
    private boolean carpet_hasQuasiSignal(class_1937 _level, class_2338 above, class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_2338 neighborPos, boolean movedByPiston) {
        return QuasiConnectivity.hasQuasiSignal(level, pos);
    }
}
