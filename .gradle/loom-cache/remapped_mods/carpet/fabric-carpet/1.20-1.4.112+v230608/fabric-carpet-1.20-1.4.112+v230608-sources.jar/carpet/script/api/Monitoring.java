package carpet.script.api;

import carpet.script.CarpetContext;
import carpet.script.Expression;
import carpet.script.exception.InternalExpressionException;
import carpet.script.external.Vanilla;
import carpet.script.utils.SystemInfo;
import carpet.script.value.ListValue;
import carpet.script.value.MapValue;
import carpet.script.value.NumericValue;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import it.unimi.dsi.fastutil.objects.Object2IntMap;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_3218;

public class Monitoring
{
    private static final Map<String, class_1311> MOB_CATEGORY_MAP = Arrays.stream(class_1311.values()).collect(Collectors.toMap(class_1311::method_6133, Function.identity()));

    public static void apply(Expression expression)
    {
        expression.addContextFunction("system_info", -1, (c, t, lv) ->
        {
            if (lv.isEmpty())
            {
                return SystemInfo.getAll();
            }
            if (lv.size() == 1)
            {
                String what = lv.get(0).getString();
                Value res = SystemInfo.get(what, (CarpetContext) c);
                if (res == null)
                {
                    throw new InternalExpressionException("Unknown option for 'system_info': " + what);
                }
                return res;
            }
            throw new InternalExpressionException("'system_info' requires one or no parameters");
        });
        // game processed snooper functions
        expression.addContextFunction("get_mob_counts", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            class_3218 world = cc.level();
            class_1948.class_5262 info = world.method_14178().method_27908();
            if (info == null)
            {
                return Value.NULL;
            }
            Object2IntMap<class_1311> mobcounts = info.method_27830();
            int chunks = info.method_27823();
            if (lv.isEmpty())
            {
                Map<Value, Value> retDict = new HashMap<>();
                for (class_1311 category : mobcounts.keySet())
                {
                    int currentCap = category.method_6134() * chunks / Vanilla.NaturalSpawner_MAGIC_NUMBER();
                    retDict.put(
                            new StringValue(category.method_15434().toLowerCase(Locale.ROOT)),
                            ListValue.of(
                                    new NumericValue(mobcounts.getInt(category)),
                                    new NumericValue(currentCap))
                    );
                }
                return MapValue.wrap(retDict);
            }
            String catString = lv.get(0).getString();
            class_1311 cat = MOB_CATEGORY_MAP.get(catString.toLowerCase(Locale.ROOT));
            if (cat == null)
            {
                throw new InternalExpressionException("Unreconized mob category: " + catString);
            }
            return ListValue.of(
                    new NumericValue(mobcounts.getInt(cat)),
                    new NumericValue((long) cat.method_6134() * chunks / Vanilla.NaturalSpawner_MAGIC_NUMBER())
            );
        });
    }
}
