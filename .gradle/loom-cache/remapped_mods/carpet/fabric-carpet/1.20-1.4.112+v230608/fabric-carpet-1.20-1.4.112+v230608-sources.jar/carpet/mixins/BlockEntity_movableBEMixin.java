package carpet.mixins;

import carpet.fakes.BlockEntityInterface;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2586.class)
public abstract class BlockEntity_movableBEMixin implements BlockEntityInterface
{
    @Mutable
    @Shadow @Final protected class_2338 worldPosition;

    public void setCMPos(class_2338 newPos)
    {
        worldPosition = newPos;
    };
}
