package carpet.patches;

import carpet.CarpetServer;
import carpet.fakes.MinecraftServerInterface;
import carpet.helpers.ServerTickRateManager;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2780;
import net.minecraft.class_2784;
import net.minecraft.class_2784.class_2787;
import net.minecraft.class_2789;
import net.minecraft.class_3532;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

/**
 * This class is essentially a copy of {@link net.minecraft.class_2784.class_2786}
 * but instead of using real time to lerp the border
 * this class uses the in game ticks.
 */
@SuppressWarnings("JavadocReference")
public class TickSyncedBorderExtent implements class_2784.class_2785
{
    private final class_2784 border;
    private final long realDuration;
    private final double tickDuration;
    private final double from;
    private final double to;

    private int ticks;

    public TickSyncedBorderExtent(class_2784 border, long realDuration, double from, double to)
    {
        this.border = border;
        this.realDuration = realDuration;
        this.tickDuration = realDuration / 50.0;
        this.from = from;
        this.to = to;
        this.ticks = 0;
    }

    @Override
    public double method_11994()
    {
        int maxSize = this.border.method_11959();
        return class_3532.method_15350(this.border.method_11964() - this.method_11984() / 2.0, -maxSize, maxSize);
    }

    @Override
    public double method_11991()
    {
        int maxSize = this.border.method_11959();
        return class_3532.method_15350(this.border.method_11964() + this.method_11984() / 2.0, -maxSize, maxSize);
    }

    @Override
    public double method_11992()
    {
        int maxSize = this.border.method_11959();
        return class_3532.method_15350(this.border.method_11980() - this.method_11984() / 2.0, -maxSize, maxSize);
    }

    @Override
    public double method_11985()
    {
        int maxSize = this.border.method_11959();
        return class_3532.method_15350(this.border.method_11980() + this.method_11984() / 2.0, -maxSize, maxSize);
    }

    @Override
    public double method_11984()
    {
        double progress = this.ticks / this.tickDuration;
        return progress < 1.0 ? class_3532.method_16436(progress, this.from, this.to) : this.to;
    }

    @Override
    public double method_11987()
    {
        return Math.abs(this.from - this.to) / this.realDuration;
    }

    @Override
    public long method_11993()
    {
        // Rough estimation
        MinecraftServer server = CarpetServer.minecraft_server;
        double ms;
        if (server == null)
        {
            // can this even happen?
            ms = 50.0;
        }
        else
        {
             ms = Arrays.stream(server.field_4573).average().orElseThrow(IllegalStateException::new) * 1.0E-6D;
             ServerTickRateManager trm = ((MinecraftServerInterface)server).getTickRateManager();
             if (!trm.isInWarpSpeed())
             {
                 ms = Math.max(ms, trm.mspt());
             }
        }
        double tps = 1_000.0D / ms;
        return (long) ((this.tickDuration - this.ticks) / tps * 1_000);
    }

    @Override
    public double method_11988()
    {
        return this.to;
    }

    @NotNull
    @Override
    public class_2789 method_11995()
    {
        return this.to < this.from ? class_2789.field_12756 : class_2789.field_12754;
    }

    @Override
    public void method_11989()
    {

    }

    @Override
    public void method_11990()
    {

    }

    @NotNull
    @Override
    public class_2784.class_2785 method_11986()
    {
        if (this.ticks++ % 20 == 0)
        {
            // We need to update any listeners
            // Most importantly those that send updates to the client
            // This is because the client logic uses real time
            // So if the tick speed has changed we need to tell the client
            for (class_2780 listener : this.border.method_11970())
            {
                // We do not want to update DelegateBorderChangeListener
                // This updates borders in other dimensions
                if (!(listener instanceof class_2780.class_3976))
                {
                    listener.method_11931(this.border, this.from, this.to, this.realDuration);
                }
            }
        }

        return this.ticks >= this.tickDuration ? this.border.new class_2787(this.to) : this;
    }

    @NotNull
    @Override
    public class_265 method_17906()
    {
        return class_259.method_1072(
            class_259.field_17669,
            class_259.method_1081(
                Math.floor(this.method_11994()),
                Double.NEGATIVE_INFINITY,
                Math.floor(this.method_11992()),
                Math.ceil(this.method_11991()),
                Double.POSITIVE_INFINITY,
                Math.ceil(this.method_11985())
            ),
            class_247.field_16886
        );
    }
}
