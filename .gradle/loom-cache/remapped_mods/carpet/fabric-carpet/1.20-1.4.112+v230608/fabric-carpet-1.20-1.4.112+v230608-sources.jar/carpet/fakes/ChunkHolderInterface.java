package carpet.fakes;

import com.mojang.datafixers.util.Either;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1255;
import net.minecraft.class_1923;
import net.minecraft.class_2791;
import net.minecraft.class_3193;
import net.minecraft.class_3218;

public interface ChunkHolderInterface
{
    CompletableFuture<Either<class_2791, class_3193.class_3724>> setDefaultProtoChunk(class_1923 chpos, class_1255<Runnable> executor, class_3218 world);
}
