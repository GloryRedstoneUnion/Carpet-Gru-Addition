package carpet.mixins;

import carpet.CarpetSettings;
import carpet.helpers.FertilizableCoral;
import net.minecraft.class_2297;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2297.class)
public class CoralFanBlock_renewableCoralMixin implements FertilizableCoral
{
    @Override
    public boolean isEnabled() {
        return CarpetSettings.renewableCoral == CarpetSettings.RenewableCoralMode.EXPANDED;
    }
    // Logic in FertilizableCoral
}
