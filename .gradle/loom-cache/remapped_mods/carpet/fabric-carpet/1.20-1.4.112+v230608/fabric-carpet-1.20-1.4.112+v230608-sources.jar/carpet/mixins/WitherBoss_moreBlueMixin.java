package carpet.mixins;


import carpet.CarpetSettings;
import net.minecraft.class_1528;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1528.class)
public class WitherBoss_moreBlueMixin
{
    @Redirect(method = "performRangedAttack(ILnet/minecraft/world/entity/LivingEntity;)V", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/util/RandomSource;nextFloat()F")
    )
    private float nextFloatAmplfied(class_5819 random)
    {
        if (CarpetSettings.moreBlueSkulls) return random.method_43057()/100;
        return random.method_43057();
    }

}
