package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2530;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2530.class)
public abstract class TntBlock_noUpdateMixin
{
    // Add carpet rule check for tntDoNotUpdate to an if statement.
    @Redirect(method = "onPlace", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/level/Level;hasNeighborSignal(Lnet/minecraft/core/BlockPos;)Z"))
    private boolean isTNTDoNotUpdate(class_1937 world, class_2338 blockPos)
    {
        return !CarpetSettings.tntDoNotUpdate && world.method_49803(blockPos);
    }
}
