package carpet.mixins;

import carpet.fakes.LevelInterface;
import com.google.common.collect.Lists;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1508;
import net.minecraft.class_1510;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_3695;
import net.minecraft.class_5577;

@Mixin(class_1937.class)
public abstract class Level_getOtherEntitiesLimited implements LevelInterface {

    private static final RuntimeException CONTROL_FLOW_EXCEPTION = new RuntimeException("Should be caught for control flow in World_getOtherEntitiesLimited!");

    @Override
    public List<class_1297> getOtherEntitiesLimited(@Nullable class_1297 except, class_238 box, Predicate<? super class_1297> predicate, int limit) {
        this.getProfiler().method_39278("getEntities"); // visit
        AtomicInteger checkedEntities = new AtomicInteger();
        List<class_1297> list = Lists.newArrayList();
        try {
            this.getEntities().method_31807(box, (entity) -> {
                if (checkedEntities.getAndIncrement() > limit) {
                    throw CONTROL_FLOW_EXCEPTION;
                }

                if (entity != except && predicate.test(entity)) {
                    list.add(entity);
                }

                if (entity instanceof class_1510) {
                    class_1508[] var4 = ((class_1510) entity).method_5690();

                    for (class_1508 enderDragonPart : var4) {
                        if (entity != except && predicate.test(enderDragonPart)) {
                            list.add(enderDragonPart);
                        }
                    }
                }
            });
        } catch (RuntimeException e) {
            if (e != CONTROL_FLOW_EXCEPTION)
                // If it wasn't the exception we were watching, rethrow it
                throw e;
        }
        return list;
    }

    @Shadow
    public abstract class_3695 getProfiler();

    @Shadow
    protected abstract class_5577<class_1297> getEntities();
}
