package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.WorldChunkInterface;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2667;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2843;
import net.minecraft.class_2902;
import net.minecraft.class_5539;
import net.minecraft.class_6749;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2818.class)
public abstract class LevelChunk_movableBEMixin extends class_2791 implements WorldChunkInterface
{
    @Shadow
    @Final
    class_1937 level;

    public LevelChunk_movableBEMixin(class_1923 pos, class_2843 upgradeData, class_5539 heightLimitView, class_2378<class_1959> biome, long inhabitedTime, @Nullable class_2826[] sectionArrayInitializer, @Nullable class_6749 blendingData) {
        super(pos, upgradeData, heightLimitView, biome, inhabitedTime, sectionArrayInitializer, blendingData);
    }

    @Shadow
    /* @Nullable */
    public abstract class_2586 getBlockEntity(class_2338 blockPos_1, class_2818.class_2819 worldChunk$CreationType_1);

    @Shadow protected abstract <T extends class_2586> void updateBlockEntityTicker(T blockEntity);

    @Shadow public abstract void addAndRegisterBlockEntity(class_2586 blockEntity);

    // Fix Failure: If a moving BlockEntity is placed while BlockEntities are ticking, this will not find it and then replace it with a new TileEntity!
    // blockEntity_2 = this.getBlockEntity(blockPos_1, WorldChunk.CreationType.CHECK);
    // question is - with the changes in the BE handling this might not be a case anymore
    @Redirect(method = "setBlockState", at = @At(value = "INVOKE", ordinal = 0,
            target = "Lnet/minecraft/world/level/chunk/LevelChunk;getBlockEntity(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/chunk/LevelChunk$EntityCreationType;)Lnet/minecraft/world/level/block/entity/BlockEntity;"))
    private class_2586 ifGetBlockEntity(class_2818 worldChunk, class_2338 blockPos_1,
            class_2818.class_2819 worldChunk$CreationType_1)
    {
        if (!CarpetSettings.movableBlockEntities)
        {
            return this.getBlockEntity(blockPos_1, class_2818.class_2819.field_12859);
        }
        else
        {
            return this.level.method_8321(blockPos_1);
        }
    }
    
    
    /**
     * Sets the Blockstate and the BlockEntity.
     * Only sets BlockEntity if Block is BlockEntityProvider, but doesn't check if it actually matches (e.g. can assign beacon to chest entity).
     *
     * @author 2No2Name
     */
    /* @Nullable */
    // todo update me to the new version
    public class_2680 setBlockStateWithBlockEntity(class_2338 blockPos_1, class_2680 newBlockState, class_2586 newBlockEntity,
            boolean boolean_1)
    {
        int x = blockPos_1.method_10263() & 15;
        int y = blockPos_1.method_10264();
        int z = blockPos_1.method_10260() & 15;
        class_2826 chunkSection = this.method_38259(this.method_31602(y));
        if (chunkSection.method_38292())
        {
            if (newBlockState.method_26215())
            {
                return null;
            }
        }
        
        boolean boolean_2 = chunkSection.method_38292();
        class_2680 oldBlockState = chunkSection.method_16675(x, y & 15, z, newBlockState);
        if (oldBlockState == newBlockState)
        {
            return null;
        }
        else
        {
            class_2248 newBlock = newBlockState.method_26204();
            class_2248 oldBlock = oldBlockState.method_26204();
            ((class_2902) this.field_34541.get(class_2902.class_2903.field_13197)).method_12597(x, y, z, newBlockState);
            ((class_2902) this.field_34541.get(class_2902.class_2903.field_13203)).method_12597(x, y, z, newBlockState);
            ((class_2902) this.field_34541.get(class_2902.class_2903.field_13200)).method_12597(x, y, z, newBlockState);
            ((class_2902) this.field_34541.get(class_2902.class_2903.field_13202)).method_12597(x, y, z, newBlockState);
            boolean boolean_3 = chunkSection.method_38292();
            if (boolean_2 != boolean_3)
            {
                this.level.method_8398().method_12130().method_15552(blockPos_1, boolean_3);
            }
            
            if (!this.level.field_9236)
            {
                if (!(oldBlock instanceof class_2667))//this is a movableTE special case, if condition wasn't there it would remove the blockentity that was carried for some reason
                    oldBlockState.method_26197(this.level, blockPos_1, newBlockState, boolean_1);//this kills it
            }
            else if (oldBlock != newBlock && oldBlock instanceof class_2343)
            {
                this.level.method_8544(blockPos_1);
            }
            
            if (chunkSection.method_12254(x, y & 15, z).method_26204() != newBlock)
            {
                return null;
            }
            else
            {
                class_2586 oldBlockEntity = null;
                if (oldBlockState.method_31709())
                {
                    oldBlockEntity = this.getBlockEntity(blockPos_1, class_2818.class_2819.field_12859);
                    if (oldBlockEntity != null)
                    {
                        oldBlockEntity.method_31664(oldBlockState);
                        updateBlockEntityTicker(oldBlockEntity);
                    }
                }

                if (oldBlockState.method_31709())
                {
                    if (newBlockEntity == null)
                    {
                        newBlockEntity = ((class_2343) newBlock).method_10123(blockPos_1, newBlockState);
                    }
                    if (newBlockEntity != oldBlockEntity && newBlockEntity != null)
                    {
                        newBlockEntity.method_10996();
                        this.level.method_8438(newBlockEntity);
                        newBlockEntity.method_31664(newBlockState);
                        updateBlockEntityTicker(newBlockEntity);
                    }
                }

                if (!this.level.field_9236)
                {
                    newBlockState.method_26182(this.level, blockPos_1, oldBlockState, boolean_1); //This can call setblockstate! (e.g. hopper does)
                }
                
                this.field_34537 = true; // shouldSave
                return oldBlockState;
            }
        }
    }
}
