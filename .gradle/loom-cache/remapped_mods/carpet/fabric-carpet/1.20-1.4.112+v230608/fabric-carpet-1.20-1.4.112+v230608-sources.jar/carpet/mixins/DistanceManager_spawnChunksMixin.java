package carpet.mixins;

import carpet.fakes.ChunkTicketManagerInterface;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Iterator;
import net.minecraft.class_1923;
import net.minecraft.class_3204;
import net.minecraft.class_3228;
import net.minecraft.class_3230;
import net.minecraft.class_3902;
import net.minecraft.class_4706;

@Mixin(class_3204.class)
public abstract class DistanceManager_spawnChunksMixin implements ChunkTicketManagerInterface
{
    @Shadow @Final private Long2ObjectOpenHashMap<class_4706<class_3228<?>>> tickets;

    @Shadow protected abstract void removeTicket(long pos, class_3228<?> ticket);

    @Shadow public abstract <T> void addRegionTicket(class_3230<T> type, class_1923 pos, int radius, T argument);

    @Override
    public void changeSpawnChunks(class_1923 chunkPos,  int distance)
    {
        long pos = chunkPos.method_8324();
        class_4706<class_3228<?>> set = tickets.get(pos);
        class_3228<?> existingTicket = null;
        if (set != null)
        {
            Iterator<class_3228<?>> iter = set.iterator();
            while(iter.hasNext())
            {
                class_3228<?> ticket = iter.next();
                if (ticket.method_14281() == class_3230.field_14030)
                {
                    existingTicket = ticket;
                    iter.remove();
                }
            }
            set.add(existingTicket);
        }
        // the reason we are removing the ticket this way is that there are sideeffects of removal
        if (existingTicket != null)
        {
            removeTicket(pos, existingTicket);
        }
        // set optionally new spawn ticket
        if (distance > 0)
            addRegionTicket(class_3230.field_14030, chunkPos, distance, class_3902.field_17274);
    }
}
