package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2275;
import net.minecraft.class_2338;
import net.minecraft.class_2480;
import net.minecraft.class_2680;
import net.minecraft.class_5620;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2275.class)
public class AbstractCauldronBlock_stackableSBoxesMixin
{
    @Redirect(method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/cauldron/CauldronInteraction;interact(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/InteractionResult;"))
    private class_1269 wrapInteractor(class_5620 cauldronBehavior, class_2680 blockState, class_1937 world, class_2338 blockPos, class_1657 playerEntity, class_1268 hand, class_1799 itemStack)
    {
        int count = -1;
        if (CarpetSettings.shulkerBoxStackSize > 1 && itemStack.method_7909() instanceof class_1747 && ((class_1747)itemStack.method_7909()).method_7711() instanceof class_2480)
            count = itemStack.method_7947();
        class_1269 result = cauldronBehavior.interact(blockState, world, blockPos, playerEntity, hand, itemStack);
        if (count > 0 && result.method_23665())
        {
            class_1799 current = playerEntity.method_5998(hand);
            if (current.method_7909() instanceof class_1747 && ((class_1747)itemStack.method_7909()).method_7711() instanceof class_2480)
                current.method_7939(count);
        }
        return result;
    }
}
