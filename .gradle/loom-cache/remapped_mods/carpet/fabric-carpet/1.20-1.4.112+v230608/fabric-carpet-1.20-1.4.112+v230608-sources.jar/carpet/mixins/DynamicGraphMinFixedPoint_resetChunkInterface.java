package carpet.mixins;

import net.minecraft.class_3554;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3554.class)
public interface DynamicGraphMinFixedPoint_resetChunkInterface
{
    @Invoker("checkEdge")
    void cmInvokeUpdateLevel(long sourceId, long id, int level, boolean decrease);

    @Invoker("computeLevelFromNeighbor")
    int cmCallGetPropagatedLevel(long sourceId, long targetId, int level);
}
