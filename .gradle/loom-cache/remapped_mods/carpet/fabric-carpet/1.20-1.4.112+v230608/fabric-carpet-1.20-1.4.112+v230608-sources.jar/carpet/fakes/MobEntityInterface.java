package carpet.fakes;

import java.util.Map;
import net.minecraft.class_1352;
import net.minecraft.class_1355;

public interface MobEntityInterface
{
    class_1355 getAI(boolean target);

    Map<String, class_1352> getTemporaryTasks();

    void setPersistence(boolean what);
}
