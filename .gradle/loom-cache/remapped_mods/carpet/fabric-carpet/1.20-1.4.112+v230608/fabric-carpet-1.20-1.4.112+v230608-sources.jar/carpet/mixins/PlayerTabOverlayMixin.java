package carpet.mixins;
import carpet.fakes.PlayerListHudInterface;
import net.minecraft.class_2561;
import net.minecraft.class_355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_355.class)
public abstract class PlayerTabOverlayMixin implements PlayerListHudInterface
{
    @Shadow private class_2561 footer;

    @Shadow private class_2561 header;

    @Override
    public boolean hasFooterOrHeader()
    {
        return footer != null || header != null;
    }
}