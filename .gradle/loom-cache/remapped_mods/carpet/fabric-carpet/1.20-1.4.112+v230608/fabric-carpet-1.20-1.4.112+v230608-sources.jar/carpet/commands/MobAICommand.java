package carpet.commands;

import carpet.CarpetSettings;
import carpet.utils.CommandHelper;
import carpet.utils.MobAI;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2168;
import net.minecraft.class_7157;
import net.minecraft.class_7924;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2172.method_35510;
import static net.minecraft.class_7733.method_45610;
import static net.minecraft.class_7733.method_45603;

public class MobAICommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, final class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> command = method_9247("track").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandTrackAI)).
                then(method_9244("entity type", method_45603(commandBuildContext, class_7924.field_41266)).

                        suggests( (c, b) -> method_9265(MobAI.availbleTypes(c.getSource()), b)).
                        then(method_9247("clear").executes( (c) ->
                                {
                                    MobAI.clearTracking(c.getSource().method_9211(), method_45610(c, "entity type").comp_349());
                                    return 1;
                                }
                        )).
                        then(method_9244("aspect", StringArgumentType.word()).
                                suggests( (c, b) -> method_9265(MobAI.availableFor(method_45610(c, "entity type").comp_349()),b)).
                                executes( (c) -> {
                                    MobAI.startTracking(
                                            method_45610(c, "entity type").comp_349(),
                                            MobAI.TrackingType.valueOf(StringArgumentType.getString(c, "aspect").toUpperCase())
                                    );
                                    return 1;
                                })));
        dispatcher.register(command);
    }
}
