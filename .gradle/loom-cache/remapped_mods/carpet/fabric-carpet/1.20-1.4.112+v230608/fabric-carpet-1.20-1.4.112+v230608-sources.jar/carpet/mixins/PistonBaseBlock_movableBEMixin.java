package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.PistonBlockEntityInterface;
import com.google.common.collect.Lists;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2288;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2665;
import net.minecraft.class_2667;
import net.minecraft.class_2674;
import net.minecraft.class_2680;
import net.minecraft.class_3619;

@Mixin(class_2665.class)
public abstract class PistonBaseBlock_movableBEMixin extends class_2318
{
    protected PistonBaseBlock_movableBEMixin(class_2251 block$Settings_1)
    {
        super(block$Settings_1);
    }
    
    private ThreadLocal<List<class_2586>> list1_BlockEntities = new ThreadLocal<>(); //Unneccessary ThreadLocal if client and server use different PistonBlock instances

    @Inject(method = "isPushable", cancellable = true, at = @At(value = "RETURN", ordinal = 3, shift = At.Shift.BEFORE))
    private static void movableCMD(class_2680 blockState_1, class_1937 world_1, class_2338 blockPos_1,
            class_2350 direction_1, boolean boolean_1, class_2350 direction_2, CallbackInfoReturnable<Boolean> cir)
    {
        class_2248 block_1 = blockState_1.method_26204();
        //Make CommandBlocks movable, either use instanceof CommandBlock or the 3 cmd block objects,
        if (CarpetSettings.movableBlockEntities && block_1 instanceof class_2288)
        {
            cir.setReturnValue(true);
        }
    }
    
    private static boolean isPushableBlockEntity(class_2248 block)
    {
        //Making PISTON_EXTENSION (BlockPistonMoving) pushable would not work as its createNewTileEntity()-method returns null
        return block != class_2246.field_10443 && block != class_2246.field_10485 &&
                       block != class_2246.field_10613 && block != class_2246.field_10027 && block != class_2246.field_10008  &&
                       block != class_2246.field_10260;
    }
    
    @Redirect(method = "isPushable", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;hasBlockEntity()Z"))
    private static boolean ifHasBlockEntity(class_2680 blockState)
    {
        if (!blockState.method_31709())
        {
            return false;
        }
        else
        {
            return !(CarpetSettings.movableBlockEntities && isPushableBlockEntity(blockState.method_26204()));
        }
    }

    @Redirect(method = "isPushable", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/state/BlockState;getPistonPushReaction()Lnet/minecraft/world/level/material/PushReaction;"
    ))
    private static class_3619 moveGrindstones(class_2680 blockState)
    {
        if (CarpetSettings.movableBlockEntities && blockState.method_26204() == class_2246.field_16337) return class_3619.field_15974;
        return blockState.method_26223();
    }

    @Inject(method = "moveBlocks", at = @At(value = "INVOKE", shift = At.Shift.BEFORE,
            target = "Ljava/util/List;size()I", ordinal = 4),locals = LocalCapture.CAPTURE_FAILHARD)
    private void onMove(class_1937 world_1, class_2338 blockPos_1, class_2350 direction_1, boolean boolean_1,
                        CallbackInfoReturnable<Boolean> cir, class_2338 blockPos_2, class_2674 pistonHandler_1, Map<?, ?> map_1,
                        List<class_2338> list_1, List<class_2680> list_2, List<?> list_3, class_2680[] blockStates_1,
                        class_2350 direction_2, int int_2)
    {
        //Get the blockEntities and remove them from the world before any magic starts to happen
        if (CarpetSettings.movableBlockEntities)
        {
            list1_BlockEntities.set(Lists.newArrayList());
            for (int i = 0; i < list_1.size(); ++i)
            {
                class_2338 blockpos = list_1.get(i);
                class_2586 blockEntity = (list_2.get(i).method_31709()) ? world_1.method_8321(blockpos) : null;
                list1_BlockEntities.get().add(blockEntity);
                if (blockEntity != null)
                {
                    //hopefully this call won't have any side effects in the future, such as dropping all the BlockEntity's items
                    //we want to place this same(!) BlockEntity object into the world later when the movement stops again
                    world_1.method_8544(blockpos);
                    blockEntity.method_5431();
                }
            }
        }
    }
    
    @Inject(method = "moveBlocks", at = @At(value = "INVOKE", shift = At.Shift.BEFORE,
            target = "Lnet/minecraft/world/level/Level;setBlockEntity(Lnet/minecraft/world/level/block/entity/BlockEntity;)V", ordinal = 0),
            locals = LocalCapture.CAPTURE_FAILHARD)
    private void setBlockEntityWithCarried(class_1937 world_1, class_2338 blockPos_1, class_2350 direction_1, boolean boolean_1,
                                           CallbackInfoReturnable<Boolean> cir, class_2338 blockPos_2, class_2674 pistonHandler_1, Map<?, ?> map_1, List<?> list_1,
                                           List<class_2680> list_2, List<?> list_3, class_2680[] blockStates_1, class_2350 direction_2, int int_2,
                                           int int_3, class_2338 blockPos_4, class_2680 blockState9, class_2680 blockState4)
    {
        class_2586 blockEntityPiston = class_2667.method_11489(blockPos_4, blockState4, list_2.get(int_3),
                direction_1, boolean_1, false);
        if (CarpetSettings.movableBlockEntities)
            ((PistonBlockEntityInterface) blockEntityPiston).setCarriedBlockEntity(list1_BlockEntities.get().get(int_3));
        world_1.method_8438(blockEntityPiston);
        //world_1.setBlockEntity(blockPos_4, blockEntityPiston);
    }
    
    @Redirect(method = "moveBlocks", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/level/Level;setBlockEntity(Lnet/minecraft/world/level/block/entity/BlockEntity;)V",
            ordinal = 0))
    private void dontDoAnything(class_1937 world, class_2586 blockEntity)
    {
    }
    
    @Redirect(method = "moveBlocks", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/piston/MovingPistonBlock;newMovingBlockEntity(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;ZZ)Lnet/minecraft/world/level/block/entity/BlockEntity;",
            ordinal = 0))
    private class_2586 returnNull(class_2338 blockPos, class_2680 blockState, class_2680 blockState2, class_2350 direction, boolean bl, boolean bl2)
    {
        return null;
    }
}
