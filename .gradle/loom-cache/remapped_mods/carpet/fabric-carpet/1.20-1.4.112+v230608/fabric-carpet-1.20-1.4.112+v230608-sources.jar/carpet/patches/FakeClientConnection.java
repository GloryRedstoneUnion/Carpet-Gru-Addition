package carpet.patches;

import carpet.fakes.ClientConnectionInterface;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.class_2535;
import net.minecraft.class_2598;

public class FakeClientConnection extends class_2535
{
    public FakeClientConnection(class_2598 p)
    {
        super(p);
        // compat with adventure-platform-fabric. This does NOT trigger other vanilla handlers for establishing a channel
        // also makes #isOpen return true, allowing enderpearls to teleport fake players
        ((ClientConnectionInterface)this).setChannel(new EmbeddedChannel());
    }

    @Override
    public void method_10757()
    {
    }

    @Override
    public void method_10768()
    {
    }
}