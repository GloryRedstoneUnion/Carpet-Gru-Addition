package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.PistonBlockEntityInterface;
import net.minecraft.class_2586;
import net.minecraft.class_2669;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.minecraft.class_835;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_835.class)
public abstract class PistonHeadRenderer_movableBEMixin implements class_827<class_2669>
{
    class_824 dispatcher;
    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInitCM(class_5614.class_5615 arguments, CallbackInfo ci)
    {
        dispatcher = arguments.method_32139();
    }

    @Inject(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/blockentity/PistonHeadRenderer;renderBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/level/Level;ZI)V", ordinal = 3))
    private void updateRenderBool(class_2669 pistonBlockEntity_1, float float_1, class_4587 matrixStack_1, class_4597 layeredVertexConsumerStorage_1, int int_1, int int_2, CallbackInfo ci)
    //private void updateRenderBool(PistonBlockEntity pistonBlockEntity_1, double double_1, double double_2, double double_3, float float_1, class_4587 class_4587_1, class_4597 class_4597_1, int int_1, CallbackInfo ci)
    {
        if (!((PistonBlockEntityInterface) pistonBlockEntity_1).isRenderModeSet())
            ((PistonBlockEntityInterface) pistonBlockEntity_1).setRenderCarriedBlockEntity(CarpetSettings.movableBlockEntities && ((PistonBlockEntityInterface) pistonBlockEntity_1).getCarriedBlockEntity() != null);
    }


    @Inject(method = "render", at = @At("RETURN"), locals = LocalCapture.NO_CAPTURE)
    private void endMethod3576(class_2669 pistonBlockEntity_1, float partialTicks, class_4587 matrixStack_1, class_4597 layeredVertexConsumerStorage_1, int int_1, int init_2, CallbackInfo ci)
    {
        if (((PistonBlockEntityInterface) pistonBlockEntity_1).getRenderCarriedBlockEntity())
        {
            class_2586 carriedBlockEntity = ((PistonBlockEntityInterface) pistonBlockEntity_1).getCarriedBlockEntity();
            if (carriedBlockEntity != null)
            {
                // maybe ??? carriedBlockEntity.setPos(pistonBlockEntity_1.getPos());
                //((BlockEntityRenderDispatcherInterface) BlockEntityRenderDispatcher.INSTANCE).renderBlockEntityOffset(carriedBlockEntity, float_1, int_1, BlockRenderLayer.field_20799, bufferBuilder_1, pistonBlockEntity_1.getRenderOffsetX(float_1), pistonBlockEntity_1.getRenderOffsetY(float_1), pistonBlockEntity_1.getRenderOffsetZ(float_1));
                matrixStack_1.method_46416(
                        pistonBlockEntity_1.method_11494(partialTicks),
                        pistonBlockEntity_1.method_11511(partialTicks),
                        pistonBlockEntity_1.method_11507(partialTicks)
                );
                dispatcher.method_3555(carriedBlockEntity, partialTicks, matrixStack_1, layeredVertexConsumerStorage_1);

            }
        }
    }
}
