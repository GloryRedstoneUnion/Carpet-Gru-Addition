package carpet.mixins;

import carpet.network.CarpetClient;
import carpet.network.ClientNetworkHandler;
import net.minecraft.class_2561;
import net.minecraft.class_2658;
import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListener_customPacketsMixin
{
    @Final @Shadow private class_310 minecraft;

    @Inject(method = "handleCustomPayload", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/protocol/game/ClientboundCustomPayloadPacket;getIdentifier()Lnet/minecraft/resources/ResourceLocation;"), cancellable = true)
    private void onOnCustomPayload(class_2658 packet, CallbackInfo ci)
    {
        if (CarpetClient.CARPET_CHANNEL.equals(packet.method_11456()))
        {
            ClientNetworkHandler.handleData(packet.method_11458(), minecraft.field_1724);
            ci.cancel();
        }
    }

    @Inject(method = "handleLogin", at = @At("RETURN"))
    private void onGameJoined(class_2678 packet, CallbackInfo info)
    {
        CarpetClient.gameJoined(minecraft.field_1724);
    }

    @Inject(method = "onDisconnect", at = @At("HEAD"))
    private void onCMDisconnected(class_2561 reason, CallbackInfo ci)
    {
        CarpetClient.disconnect();
    }
}
