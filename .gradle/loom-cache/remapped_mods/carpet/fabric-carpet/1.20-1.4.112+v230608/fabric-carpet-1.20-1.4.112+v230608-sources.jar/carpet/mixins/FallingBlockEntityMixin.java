package carpet.mixins;

import carpet.logging.LoggerRegistry;
import carpet.logging.logHelpers.TrajectoryLogHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1540;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1540.class)
public abstract class FallingBlockEntityMixin extends class_1297
{
    private TrajectoryLogHelper logHelper;
    public FallingBlockEntityMixin(class_1299<?> entityType_1, class_1937 world_1) { super(entityType_1, world_1); }

    @Inject(method = "<init>(Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V", at = @At("RETURN"))
    private void addLogger(class_1299<? extends class_1676> entityType_1, class_1937 world_1, CallbackInfo ci)
    {
        if (LoggerRegistry.__fallingBlocks && !world_1.field_9236)
            logHelper = new TrajectoryLogHelper("fallingBlocks");
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void tickCheck(CallbackInfo ci)
    {
        if (LoggerRegistry.__fallingBlocks && logHelper != null)
            logHelper.onTick(method_23317(), method_23318(), method_23321(), method_18798());
    }

    @Override
    public void method_5650(class_1297.class_5529 arg) // reason
    {
        super.method_5650(arg);
        if (LoggerRegistry.__fallingBlocks && logHelper != null)
            logHelper.onFinish();
    }
}
