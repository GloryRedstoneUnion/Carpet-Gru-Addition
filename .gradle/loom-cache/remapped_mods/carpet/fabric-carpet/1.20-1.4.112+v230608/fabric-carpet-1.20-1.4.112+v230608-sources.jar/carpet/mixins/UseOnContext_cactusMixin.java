package carpet.mixins;

import carpet.helpers.BlockRotator;
import net.minecraft.class_1657;
import net.minecraft.class_1838;
import net.minecraft.class_2350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1838.class)
public class UseOnContext_cactusMixin
{
    @Redirect(method = "getHorizontalDirection", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;getDirection()Lnet/minecraft/core/Direction;"
    ))
    private class_2350 getPlayerFacing(class_1657 playerEntity)
    {
        class_2350 dir = playerEntity.method_5735();
        if (BlockRotator.flippinEligibility(playerEntity))
        {
            dir = dir.method_10153();
        }
        return dir;
    }
}
