package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1827;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1827.class)
public class StandingAndWallBlockItem_creativeNoClipMixin
{
    @Redirect(method = "getPlacementState", at = @At(
                value = "INVOKE",
                target = "Lnet/minecraft/world/level/LevelReader;isUnobstructed(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Z"
    ))
    private boolean canCreativePlayerPlace(
            class_4538 worldView, class_2680 state, class_2338 pos, class_3726 context,
            class_1750 itemcontext
    )
    {
        class_1657 player = itemcontext.method_8036();
        if (CarpetSettings.creativeNoClip && player != null && player.method_7337() && player.method_31549().field_7479)
        {
            // copy from canPlace
            class_265 voxelShape = state.method_26194(worldView, pos, context);
            return voxelShape.method_1110() || worldView.method_8611(player, voxelShape.method_1096(pos.method_10263(), pos.method_10264(), pos.method_10260()));

        }
        return worldView.method_8628(state, pos, context);
    }
}
