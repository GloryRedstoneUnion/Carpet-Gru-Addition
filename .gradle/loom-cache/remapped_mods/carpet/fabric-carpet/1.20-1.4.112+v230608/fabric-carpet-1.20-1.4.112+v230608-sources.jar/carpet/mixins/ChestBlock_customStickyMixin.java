package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;

import carpet.CarpetSettings;
import carpet.fakes.BlockBehaviourInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2745;

import static net.minecraft.class_2281.method_9758;

@Mixin(class_2281.class)
public class ChestBlock_customStickyMixin implements BlockBehaviourInterface {

    @Override
    public boolean isSticky(class_2680 state) {
        return CarpetSettings.movableBlockEntities;
    }

    @Override
    public boolean isStickyToNeighbor(class_1937 level, class_2338 pos, class_2680 state, class_2338 neighborPos, class_2680 neighborState, class_2350 dir, class_2350 moveDir) {
        if (!neighborState.method_27852((class_2248)(Object)this)) {
            return false;
        }

        class_2745 type = state.method_11654(class_2281.field_10770);
        class_2745 neighborType = neighborState.method_11654(class_2281.field_10770);

        if (type == class_2745.field_12569 || neighborType == class_2745.field_12569) {
            return false;
        }
        return method_9758(state) == dir;
    }
}
