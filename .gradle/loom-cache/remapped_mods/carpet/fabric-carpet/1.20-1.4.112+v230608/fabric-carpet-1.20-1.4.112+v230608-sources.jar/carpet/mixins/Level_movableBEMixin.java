package carpet.mixins;

import carpet.fakes.WorldChunkInterface;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3194;
import net.minecraft.class_3695;
import carpet.fakes.LevelInterface;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1937.class)
public abstract class Level_movableBEMixin implements LevelInterface, class_1936
{
    @Shadow
    @Final
    public boolean isClientSide;

    @Shadow
    public abstract class_2818 getChunkAt(class_2338 blockPos_1);
    
    @Shadow
    public abstract class_2680 method_8320(class_2338 blockPos_1);
    
    //@Shadow
    //public abstract ChunkManager getChunkManager();
    
    @Shadow
    public abstract void setBlocksDirty(class_2338 blockPos_1, class_2680 s1, class_2680 s2);
    
    @Shadow
    public abstract void sendBlockUpdated(class_2338 var1, class_2680 var2, class_2680 var3, int var4);
    
    @Shadow
    public abstract void updateNeighborsAt(class_2338 blockPos_1, class_2248 block_1);
    
    @Shadow
    public abstract void onBlockStateChange(class_2338 blockPos_1, class_2680 blockState_1, class_2680 blockState_2);

    @Shadow public abstract class_3695 getProfiler();

    @Shadow public abstract void updateNeighbourForOutputSignal(class_2338 pos, class_2248 block);

    //@Shadow public abstract boolean setBlockState(BlockPos pos, BlockState state, int flags);

    @Shadow public abstract boolean isDebug();

    /**
     * @author 2No2Name
     */
    @Override
    public boolean setBlockStateWithBlockEntity(class_2338 blockPos_1, class_2680 blockState_1, class_2586 newBlockEntity, int int_1)
    {
        if (method_31606(blockPos_1) || !this.isClientSide && isDebug()) return false;
        class_2818 worldChunk_1 = this.getChunkAt(blockPos_1);
        class_2248 block_1 = blockState_1.method_26204();

        class_2680 blockState_2;
        if (newBlockEntity != null && block_1 instanceof class_2343)
        {
            blockState_2 = ((WorldChunkInterface) worldChunk_1).setBlockStateWithBlockEntity(blockPos_1, blockState_1, newBlockEntity, (int_1 & 64) != 0);
            if (newBlockEntity instanceof class_2618)
            {
                method_39279(blockPos_1, block_1, 5);
            }
        }
        else
        {
            blockState_2 = worldChunk_1.method_12010(blockPos_1, blockState_1, (int_1 & 64) != 0);
        }

        if (blockState_2 == null)
        {
            return false;
        }
        else
        {
            class_2680 blockState_3 = this.method_8320(blockPos_1);

            if (blockState_3 != blockState_2 && (blockState_3.method_26193((class_1922) this, blockPos_1) != blockState_2.method_26193((class_1922) this, blockPos_1) || blockState_3.method_26213() != blockState_2.method_26213() || blockState_3.method_26211() || blockState_2.method_26211()))
            {
                class_3695 profiler = getProfiler();
                profiler.method_15396("queueCheckLight");
                this.method_8398().method_12130().method_15513(blockPos_1);
                profiler.method_15407();
            }

            if (blockState_3 == blockState_1)
            {
                if (blockState_2 != blockState_3)
                {
                    this.setBlocksDirty(blockPos_1, blockState_2, blockState_3);
                }

                if ((int_1 & 2) != 0 && (!this.isClientSide || (int_1 & 4) == 0) && (this.isClientSide || worldChunk_1.method_12225() != null && worldChunk_1.method_12225().method_14014(class_3194.field_44856)))
                {
                    this.sendBlockUpdated(blockPos_1, blockState_2, blockState_1, int_1);
                }

                if (!this.isClientSide && (int_1 & 1) != 0)
                {
                    this.updateNeighborsAt(blockPos_1, blockState_2.method_26204());
                    if (blockState_1.method_26221())
                    {
                        updateNeighbourForOutputSignal(blockPos_1, block_1);
                    }
                }

                if ((int_1 & 16) == 0)
                {
                    int int_2 = int_1 & -34;
                    blockState_2.method_30102(this, blockPos_1, int_2); // prepare
                    blockState_1.method_30101(this, blockPos_1, int_2); // updateNeighbours
                    blockState_1.method_30102(this, blockPos_1, int_2); // prepare
                }
                this.onBlockStateChange(blockPos_1, blockState_2, blockState_3);
            }
            return true;
        }
    }
}
