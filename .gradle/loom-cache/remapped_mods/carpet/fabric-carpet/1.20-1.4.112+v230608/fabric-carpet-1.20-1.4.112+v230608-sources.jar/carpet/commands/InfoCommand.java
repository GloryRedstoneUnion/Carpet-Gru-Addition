package carpet.commands;

import carpet.CarpetSettings;
import carpet.utils.BlockInfo;
import carpet.utils.CommandHelper;
import carpet.utils.Messenger;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class InfoCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> command = method_9247("info").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandInfo)).
                then(method_9247("block").
                        then(method_9244("block position", class_2262.method_9698()).
                                executes( (c) -> infoBlock(
                                        c.getSource(),
                                        class_2262.method_9697(c, "block position"), null)).
                                then(method_9247("grep").
                                        then(method_9244("regexp",greedyString()).
                                                executes( (c) -> infoBlock(
                                                        c.getSource(),
                                                        class_2262.method_9697(c, "block position"),
                                                        getString(c, "regexp")))))));

        dispatcher.register(command);
    }

    public static void printBlock(List<class_2561> messages, class_2168 source, String grep)
    {
        Messenger.m(source, "");
        if (grep != null)
        {
            Pattern p = Pattern.compile(grep);
            Messenger.m(source, messages.get(0));
            for (int i = 1; i<messages.size(); i++)
            {
                class_2561 line = messages.get(i);
                Matcher m = p.matcher(line.getString());
                if (m.find())
                {
                    Messenger.m(source, line);
                }
            }
        }
        else
        {
            Messenger.send(source, messages);
        }
    }

    private static int infoBlock(class_2168 source, class_2338 pos, String grep)
    {
        if (!source.method_9259(class_2170.field_31839)) {
            //check id pos is loaded
            if (!source.method_9225().method_22340(pos)) {
                Messenger.m(source, "r Chunk is not loaded");
                return 0;
            }
            // verify it is in world bounds
            if (!source.method_9225().method_24794(pos)) {
                Messenger.m(source, "r Position is outside of world bounds");
                return 0;
            }
        }
        printBlock(BlockInfo.blockInfo(pos, source.method_9225()),source, grep);
        return 1;
    }

}
