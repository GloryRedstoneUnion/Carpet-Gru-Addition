package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1656;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1657.class)
public abstract class Player_portalDelayMixin
{
    @Final @Shadow public class_1656 abilities;

    @Inject(method = "getPortalWaitTime()I", at = @At("HEAD"), cancellable = true)
    private void onMaxNetherPortalTime(CallbackInfoReturnable<Integer> cir) {
        if(CarpetSettings.portalCreativeDelay != 1 && this.abilities.field_7480) cir.setReturnValue(CarpetSettings.portalCreativeDelay);
        else if(CarpetSettings.portalSurvivalDelay != 80 && !this.abilities.field_7480) cir.setReturnValue(CarpetSettings.portalSurvivalDelay);
    }
}
