package carpet.script.utils;

import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

public class EquipmentInventory implements class_1263
{
    private static final List<class_1304> slotToSlot = List.of(
            class_1304.field_6173,
            class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169,
            class_1304.field_6171
    );

    class_1309 mob;

    public EquipmentInventory(class_1309 mob)
    {
        this.mob = mob;
    }

    @Override
    public int method_5439()
    {
        return 6;
    }

    @Override
    public boolean method_5442()
    {
        for (class_1304 slot : slotToSlot)
        {
            if (!mob.method_6118(slot).method_7960())
            {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_5438(int slot)
    {
        class_1304 slotSlot;
        try
        {
            slotSlot = slotToSlot.get(slot);
        }
        catch (IndexOutOfBoundsException ignored)
        {
            //going out of the index should be really exceptional
            return class_1799.field_8037;
        }
        return mob.method_6118(slotSlot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount)
    {
        class_1304 slotSlot;
        try
        {
            slotSlot = slotToSlot.get(slot);
        }
        catch (IndexOutOfBoundsException ignored)
        {
            //going out of the index should be really exceptional
            return class_1799.field_8037;
        }
        return mob.method_6118(slotSlot).method_7971(amount);
    }

    @Override
    public class_1799 method_5441(int slot)
    {
        class_1304 slotSlot;
        try
        {
            slotSlot = slotToSlot.get(slot);
        }
        catch (IndexOutOfBoundsException ignored)
        {
            //going out of the index should be really exceptional
            return class_1799.field_8037;
        }
        class_1799 previous = mob.method_6118(slotSlot);
        mob.method_5673(slotSlot, class_1799.field_8037);
        return previous;
    }

    @Override
    public void method_5447(int slot, class_1799 stack)
    {
        class_1304 slotSlot;
        try
        {
            slotSlot = slotToSlot.get(slot);
        }
        catch (IndexOutOfBoundsException ignored)
        {
            //going out of the index should be really exceptional
            return;
        }
        mob.method_5673(slotSlot, stack);
    }

    @Override
    public void method_5431()
    {

    }

    @Override
    public boolean method_5443(class_1657 player)
    {
        return false;
    }

    @Override
    public void method_5448()
    {
        for (class_1304 slot : slotToSlot)
        {
            mob.method_5673(slot, class_1799.field_8037);
        }
    }
}
