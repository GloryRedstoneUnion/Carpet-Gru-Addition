package carpet.commands;

import carpet.CarpetSettings;
import carpet.helpers.HopperCounter;
import carpet.utils.Messenger;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_1767;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9247;

/**
 * Class for the /counter command which allows to use hoppers pointing into wool
 */
public class CounterCommand
{
    /**
     * The method used to register the command and make it available for the players to use.
     */
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> commandBuilder = method_9247("counter")
                .requires(c -> CarpetSettings.hopperCounters)
                .executes(c -> listAllCounters(c.getSource(), false))
                .then(method_9247("reset")
                        .executes(c -> resetCounters(c.getSource())));

        for (class_1767 dyeColor : class_1767.values())
        {
            commandBuilder.then(
                    method_9247(dyeColor.toString())
                            .executes(c -> displayCounter(c.getSource(), dyeColor, false))
                            .then(method_9247("reset")
                                    .executes(c -> resetCounter(c.getSource(), dyeColor)))
                            .then(method_9247("realtime")
                                    .executes(c -> displayCounter(c.getSource(), dyeColor, true)))
                    );
        }
        dispatcher.register(commandBuilder);
    }

    /**
     * A method to prettily display the contents of a counter to the player
     * @param color The counter colour whose contents we are querying.
     * @param realtime Whether or not to display it as in-game time or IRL time, which accounts for less than 20TPS which
     *                would make it slower than IRL
     */

    private static int displayCounter(class_2168 source, class_1767 color, boolean realtime)
    {
        HopperCounter counter = HopperCounter.getCounter(color);

        for (class_2561 message: counter.format(source.method_9211(), realtime, false))
        {
            source.method_9226(() -> message, false);
        }
        return 1;
    }

    private static int resetCounters(class_2168 source)
    {
        HopperCounter.resetAll(source.method_9211(), false);
        Messenger.m(source, "w Restarted all counters");
        return 1;
    }

    /**
     * A method to reset the counter's timer to 0 and empty its items
     * 
     * @param color The counter whose contents we want to reset
     */
    private static int resetCounter(class_2168 source, class_1767 color)
    {
        HopperCounter.getCounter(color).reset(source.method_9211());
        Messenger.m(source, "w Restarted " + color + " counter");
        return 1;
    }

    /**
     * A method to prettily display all the counters to the player
     * @param realtime Whether or not to display it as in-game time or IRL time, which accounts for less than 20TPS which
     *                would make it slower than IRL
     */
    private static int listAllCounters(class_2168 source, boolean realtime)
    {
        for (class_2561 message: HopperCounter.formatAll(source.method_9211(), realtime))
        {
            source.method_9226(() -> message, false);
        }
        return 1;
    }
}
