package carpet.commands;

import carpet.helpers.EntityPlayerActionPack;
import carpet.helpers.EntityPlayerActionPack.Action;
import carpet.helpers.EntityPlayerActionPack.ActionType;
import carpet.CarpetSettings;
import carpet.fakes.ServerPlayerInterface;
import carpet.patches.EntityPlayerMPFake;
import carpet.utils.CommandHelper;
import carpet.utils.Messenger;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2181;
import net.minecraft.class_2270;
import net.minecraft.class_2277;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7918;
import net.minecraft.server.MinecraftServer;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2172.method_35510;

public class PlayerCommand
{
    // TODO: allow any order like execute
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> command = method_9247("player")
                .requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandPlayer))
                .then(method_9244("player", StringArgumentType.word())
                        .suggests((c, b) -> method_9265(getPlayerSuggestions(c.getSource()), b))
                        .then(method_9247("stop").executes(manipulation(EntityPlayerActionPack::stopAll)))
                        .then(makeActionCommand("use", ActionType.USE))
                        .then(makeActionCommand("jump", ActionType.JUMP))
                        .then(makeActionCommand("attack", ActionType.ATTACK))
                        .then(makeActionCommand("drop", ActionType.DROP_ITEM))
                        .then(makeDropCommand("drop", false))
                        .then(makeActionCommand("dropStack", ActionType.DROP_STACK))
                        .then(makeDropCommand("dropStack", true))
                        .then(makeActionCommand("swapHands", ActionType.SWAP_HANDS))
                        .then(method_9247("hotbar")
                                .then(method_9244("slot", IntegerArgumentType.integer(1, 9))
                                        .executes(c -> manipulate(c, ap -> ap.setSlot(IntegerArgumentType.getInteger(c, "slot"))))))
                        .then(method_9247("kill").executes(PlayerCommand::kill))
                        .then(method_9247("shadow"). executes(PlayerCommand::shadow))
                        .then(method_9247("mount").executes(manipulation(ap -> ap.mount(true)))
                                .then(method_9247("anything").executes(manipulation(ap -> ap.mount(false)))))
                        .then(method_9247("dismount").executes(manipulation(EntityPlayerActionPack::dismount)))
                        .then(method_9247("sneak").executes(manipulation(ap -> ap.setSneaking(true))))
                        .then(method_9247("unsneak").executes(manipulation(ap -> ap.setSneaking(false))))
                        .then(method_9247("sprint").executes(manipulation(ap -> ap.setSprinting(true))))
                        .then(method_9247("unsprint").executes(manipulation(ap -> ap.setSprinting(false))))
                        .then(method_9247("look")
                                .then(method_9247("north").executes(manipulation(ap -> ap.look(class_2350.field_11043))))
                                .then(method_9247("south").executes(manipulation(ap -> ap.look(class_2350.field_11035))))
                                .then(method_9247("east").executes(manipulation(ap -> ap.look(class_2350.field_11034))))
                                .then(method_9247("west").executes(manipulation(ap -> ap.look(class_2350.field_11039))))
                                .then(method_9247("up").executes(manipulation(ap -> ap.look(class_2350.field_11036))))
                                .then(method_9247("down").executes(manipulation(ap -> ap.look(class_2350.field_11033))))
                                .then(method_9247("at").then(method_9244("position", class_2277.method_9737())
                                        .executes(c -> manipulate(c, ap -> ap.lookAt(class_2277.method_9736(c, "position"))))))
                                .then(method_9244("direction", class_2270.method_9717())
                                        .executes(c -> manipulate(c, ap -> ap.look(class_2270.method_9716(c, "direction").method_9709(c.getSource())))))
                        ).then(method_9247("turn")
                                .then(method_9247("left").executes(manipulation(ap -> ap.turn(-90, 0))))
                                .then(method_9247("right").executes(manipulation(ap -> ap.turn(90, 0))))
                                .then(method_9247("back").executes(manipulation(ap -> ap.turn(180, 0))))
                                .then(method_9244("rotation", class_2270.method_9717())
                                        .executes(c -> manipulate(c, ap -> ap.turn(class_2270.method_9716(c, "rotation").method_9709(c.getSource())))))
                        ).then(method_9247("move").executes(manipulation(EntityPlayerActionPack::stopMovement))
                                .then(method_9247("forward").executes(manipulation(ap -> ap.setForward(1))))
                                .then(method_9247("backward").executes(manipulation(ap -> ap.setForward(-1))))
                                .then(method_9247("left").executes(manipulation(ap -> ap.setStrafing(1))))
                                .then(method_9247("right").executes(manipulation(ap -> ap.setStrafing(-1))))
                        ).then(method_9247("spawn").executes(PlayerCommand::spawn)
                                .then(method_9247("in").requires((player) -> player.method_9259(2))
                                        .then(method_9244("gamemode", class_7918.method_47383())
                                        .executes(PlayerCommand::spawn)))
                                .then(method_9247("at").then(method_9244("position", class_2277.method_9737()).executes(PlayerCommand::spawn)
                                        .then(method_9247("facing").then(method_9244("direction", class_2270.method_9717()).executes(PlayerCommand::spawn)
                                                .then(method_9247("in").then(method_9244("dimension", class_2181.method_9288()).executes(PlayerCommand::spawn)
                                                        .then(method_9247("in").requires((player) -> player.method_9259(2))
                                                                .then(method_9244("gamemode", class_7918.method_47383())
                                                                .executes(PlayerCommand::spawn)
                                                        )))
                                        )))
                                ))
                        )
                );
        dispatcher.register(command);
    }

    private static LiteralArgumentBuilder<class_2168> makeActionCommand(String actionName, ActionType type)
    {
        return method_9247(actionName)
                .executes(manipulation(ap -> ap.start(type, Action.once())))
                .then(method_9247("once").executes(manipulation(ap -> ap.start(type, Action.once()))))
                .then(method_9247("continuous").executes(manipulation(ap -> ap.start(type, Action.continuous()))))
                .then(method_9247("interval").then(method_9244("ticks", IntegerArgumentType.integer(1))
                        .executes(c -> manipulate(c, ap -> ap.start(type, Action.interval(IntegerArgumentType.getInteger(c, "ticks")))))));
    }

    private static LiteralArgumentBuilder<class_2168> makeDropCommand(String actionName, boolean dropAll)
    {
        return method_9247(actionName)
                .then(method_9247("all").executes(manipulation(ap -> ap.drop(-2, dropAll))))
                .then(method_9247("mainhand").executes(manipulation(ap -> ap.drop(-1, dropAll))))
                .then(method_9247("offhand").executes(manipulation(ap -> ap.drop(40, dropAll))))
                .then(method_9244("slot", IntegerArgumentType.integer(0, 40)).
                        executes(c -> manipulate(c, ap -> ap.drop(IntegerArgumentType.getInteger(c, "slot"), dropAll))));
    }

    private static Collection<String> getPlayerSuggestions(class_2168 source)
    {
        Set<String> players = new LinkedHashSet<>(List.of("Steve", "Alex"));
        players.addAll(source.method_9262());
        return players;
    }

    private static class_3222 getPlayer(CommandContext<class_2168> context)
    {
        String playerName = StringArgumentType.getString(context, "player");
        MinecraftServer server = context.getSource().method_9211();
        return server.method_3760().method_14566(playerName);
    }

    private static boolean cantManipulate(CommandContext<class_2168> context)
    {
        class_1657 player = getPlayer(context);
        class_2168 source = context.getSource();
        if (player == null)
        {
            Messenger.m(source, "r Can only manipulate existing players");
            return true;
        }
        class_1657 sender = source.method_44023();
        if (sender == null)
        {
            return false;
        }

        if (!source.method_9211().method_3760().method_14569(sender.method_7334()))
        {
            if (sender != player && !(player instanceof EntityPlayerMPFake))
            {
                Messenger.m(source, "r Non OP players can't control other real players");
                return true;
            }
        }
        return false;
    }

    private static boolean cantReMove(CommandContext<class_2168> context)
    {
        if (cantManipulate(context)) return true;
        class_1657 player = getPlayer(context);
        if (player instanceof EntityPlayerMPFake) return false;
        Messenger.m(context.getSource(), "r Only fake players can be moved or killed");
        return true;
    }

    private static boolean cantSpawn(CommandContext<class_2168> context)
    {
        String playerName = StringArgumentType.getString(context, "player");
        MinecraftServer server = context.getSource().method_9211();
        class_3324 manager = server.method_3760();

        if (manager.method_14566(playerName) != null)
        {
            Messenger.m(context.getSource(), "r Player ", "rb " + playerName, "r  is already logged on");
            return true;
        }
        GameProfile profile = server.method_3793().method_14515(playerName).orElse(null);
        if (profile == null)
        {
            if (!CarpetSettings.allowSpawningOfflinePlayers)
            {
                Messenger.m(context.getSource(), "r Player "+playerName+" is either banned by Mojang, or auth servers are down. " +
                        "Banned players can only be summoned in Singleplayer and in servers in off-line mode.");
                return true;
            } else {
                profile = new GameProfile(class_4844.method_43344(playerName), playerName);
            }
        }
        if (manager.method_14563().method_14650(profile))
        {
            Messenger.m(context.getSource(), "r Player ", "rb " + playerName, "r  is banned on this server");
            return true;
        }
        if (manager.method_14614() && manager.method_14587(profile) && !context.getSource().method_9259(2))
        {
            Messenger.m(context.getSource(), "r Whitelisted players can only be spawned by operators");
            return true;
        }
        return false;
    }

    private static int kill(CommandContext<class_2168> context)
    {
        if (cantReMove(context)) return 0;
        getPlayer(context).method_5768();
        return 1;
    }

    @FunctionalInterface
    interface SupplierWithCSE<T>
    {
        T get() throws CommandSyntaxException;
    }

    private static <T> T getArgOrDefault(SupplierWithCSE<T> getter, T defaultValue) throws CommandSyntaxException
    {
        try
        {
            return getter.get();
        }
        catch (IllegalArgumentException e)
        {
            return defaultValue;
        }
    }

    private static int spawn(CommandContext<class_2168> context) throws CommandSyntaxException
    {
        if (cantSpawn(context)) return 0;

        class_2168 source = context.getSource();
        class_243 pos = getArgOrDefault(
                () -> class_2277.method_9736(context, "position"),
                source.method_9222()
        );
        class_241 facing = getArgOrDefault(
                () -> class_2270.method_9716(context, "direction").method_9709(source),
                source.method_9210()
        );
        class_5321<class_1937> dimType = getArgOrDefault(
                () -> class_2181.method_9289(context, "dimension").method_27983(),
                source.method_9225().method_27983()
        );
        class_1934 mode = class_1934.field_9220;
        boolean flying = false;
        if (source.method_9228() instanceof class_3222 sender)
        {
            mode = sender.field_13974.method_14257();
            flying = sender.method_31549().field_7479;
        }
        try {
            mode = class_7918.method_47385(context, "gamemode");
        } catch (IllegalArgumentException notPresent) {}

        if (mode == class_1934.field_9219)
        {
            // Force override flying to true for spectator players, or they will fell out of the world.
            flying = true;
        } else if (mode.method_8388())
        {
            // Force override flying to false for survival-like players, or they will fly too
            flying = false;
        }
        String playerName = StringArgumentType.getString(context, "player");
        if (playerName.length() > maxNameLength(source.method_9211()))
        {
            Messenger.m(source, "rb Player name: " + playerName + " is too long");
            return 0;
        }

        if (!class_1937.method_25953(class_2338.method_49638(pos)))
        {
            Messenger.m(source, "rb Player " + playerName + " cannot be placed outside of the world");
            return 0;
        }
        class_1657 player = EntityPlayerMPFake.createFake(playerName, source.method_9211(), pos, facing.field_1342, facing.field_1343, dimType, mode, flying);
        if (player == null)
        {
            Messenger.m(source, "rb Player " + playerName + " doesn't exist and cannot spawn in online mode. " +
                    "Turn the server offline to spawn non-existing players");
            return 0;
        }
        return 1;
    }

    private static int maxNameLength(MinecraftServer server)
    {
        return server.method_3756() >= 0 ? class_1657.field_30643 : 40;
    }

    private static int manipulate(CommandContext<class_2168> context, Consumer<EntityPlayerActionPack> action)
    {
        if (cantManipulate(context)) return 0;
        class_3222 player = getPlayer(context);
        action.accept(((ServerPlayerInterface) player).getActionPack());
        return 1;
    }

    private static Command<class_2168> manipulation(Consumer<EntityPlayerActionPack> action)
    {
        return c -> manipulate(c, action);
    }

    private static int shadow(CommandContext<class_2168> context)
    {
        if (cantManipulate(context)) return 0;

        class_3222 player = getPlayer(context);
        if (player instanceof EntityPlayerMPFake)
        {
            Messenger.m(context.getSource(), "r Cannot shadow fake players");
            return 0;
        }
        if (player.method_5682().method_19466(player.method_7334())) {
            Messenger.m(context.getSource(), "r Cannot shadow single-player server owner");
            return 0;
        }

        EntityPlayerMPFake.createShadow(player.field_13995, player);
        return 1;
    }
}
