package carpet.commands;

import carpet.CarpetSettings;
import carpet.utils.CommandHelper;
import carpet.utils.Messenger;
import carpet.utils.PerimeterDiagnostics;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_2168;
import net.minecraft.class_2262;
import net.minecraft.class_2321;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_7157;
import net.minecraft.class_7924;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_7733.method_45610;
import static net.minecraft.class_7733.method_45603;

public class PerimeterInfoCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> command = method_9247("perimeterinfo").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandPerimeterInfo)).
                executes( (c) -> perimeterDiagnose(
                        c.getSource(),
                        class_2338.method_49638(c.getSource().method_9222()),
                        null)).
                then(method_9244("center position", class_2262.method_9698()).
                        executes( (c) -> perimeterDiagnose(
                                c.getSource(),
                                class_2262.method_9697(c, "center position"),
                                null)).
                        then(method_9244("mob", method_45603(commandBuildContext, class_7924.field_41266)).
                                suggests(class_2321.field_10935).
                                executes( (c) -> perimeterDiagnose(
                                        c.getSource(),
                                        class_2262.method_9697(c, "center position"),
                                        method_45610(c, "mob").method_40237().method_29177().toString()
                                ))));
        dispatcher.register(command);
    }

    private static int perimeterDiagnose(class_2168 source, class_2338 pos, String mobId)
    {
        class_2487 nbttagcompound = new class_2487();
        class_1308 entityliving = null;
        if (mobId != null)
        {
            nbttagcompound.method_10582("id", mobId);
            class_1297 baseEntity = class_1299.method_17842(nbttagcompound, source.method_9225(), (entity_1x) -> {
                entity_1x.method_5725(new class_2338(pos.method_10263(), source.method_9225().method_31607()-10, pos.method_10260()), entity_1x.method_36454(), entity_1x. method_36455());
                return !source.method_9225().method_18768(entity_1x) ? null : entity_1x;
            });
            if (!(baseEntity instanceof  class_1308))
            {
                Messenger.m(source, "r /perimeterinfo requires a mob entity to test against.");
                if (baseEntity != null) baseEntity.method_31472();
                return 0;
            }
            entityliving = (class_1308) baseEntity;
        }
        PerimeterDiagnostics.Result res = PerimeterDiagnostics.countSpots(source.method_9225(), pos, entityliving);

        Messenger.m(source, "w Spawning spaces around ",Messenger.tp("c",pos), "w :");
        Messenger.m(source, "w   potential in-liquid: ","wb "+res.liquid);
        Messenger.m(source, "w   potential on-ground: ","wb "+res.ground);
        if (entityliving != null)
        {
            Messenger.m(source, "w   ", entityliving.method_5476() ,"w : ","wb "+res.specific);
            res.samples.forEach(bp -> Messenger.m(source, "w   ", Messenger.tp("c", bp)));
            entityliving.method_31472(); // dicard // remove();
        }
        return 1;
    }
}
