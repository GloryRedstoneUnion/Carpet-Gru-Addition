package carpet.fakes;

import net.minecraft.class_1263;

public interface InventoryBearerInterface
{
    class_1263 getCMInventory(); // can be removed in 1.17 due to class_6067
}
