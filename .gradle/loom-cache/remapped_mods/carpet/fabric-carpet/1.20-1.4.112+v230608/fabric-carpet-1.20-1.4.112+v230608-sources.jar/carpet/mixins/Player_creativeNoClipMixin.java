package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1657.class)
public abstract class Player_creativeNoClipMixin extends class_1309
{
    protected Player_creativeNoClipMixin(class_1299<? extends class_1309> type, class_1937 world)
    {
        super(type, world);
    }

    @Redirect(method = "tick", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;isSpectator()Z")
    )
    private boolean canClipTroughWorld(class_1657 playerEntity)
    {
        return playerEntity.method_7325() || (CarpetSettings.creativeNoClip && playerEntity.method_7337() && playerEntity.method_31549().field_7479);

    }

    @Redirect(method = "aiStep", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;isSpectator()Z")
    )
    private boolean collidesWithEntities(class_1657 playerEntity)
    {
        return playerEntity.method_7325() || (CarpetSettings.creativeNoClip && playerEntity.method_7337() && playerEntity.method_31549().field_7479);
    }

    @Redirect(method = "updatePlayerPose", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;isSpectator()Z")
    )
    private boolean spectatorsDontPose(class_1657 playerEntity)
    {
        return playerEntity.method_7325() || (CarpetSettings.creativeNoClip && playerEntity.method_7337() && playerEntity.method_31549().field_7479);
    }
}
