package carpet.mixins;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import static carpet.script.CarpetEventServer.Event.PLAYER_PICKS_UP_ITEM;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

@Mixin(class_1661.class)
public abstract class Inventory_scarpetEventMixin
{
    @Shadow @Final public class_1657 player;

    @Redirect(method = "add(Lnet/minecraft/world/item/ItemStack;)Z", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Inventory;add(ILnet/minecraft/world/item/ItemStack;)Z"
    ))
    private boolean onItemAcquired(class_1661 playerInventory, int slot, class_1799 stack)
    {
        if (!PLAYER_PICKS_UP_ITEM.isNeeded() || !(player instanceof class_3222))
            return playerInventory.method_7367(-1, stack);
        class_1792 item = stack.method_7909();
        int count = stack.method_7947();
        boolean res = playerInventory.method_7367(-1, stack);
        if (count != stack.method_7947()) // res returns false for larger item adding to a almost full ineventory
        {
            class_1799 diffStack = new class_1799(item, count - stack.method_7947());
            diffStack.method_7980(stack.method_7969());
            PLAYER_PICKS_UP_ITEM.onItemAction((class_3222) player, null, diffStack);
        }
        return res;
    }

}
