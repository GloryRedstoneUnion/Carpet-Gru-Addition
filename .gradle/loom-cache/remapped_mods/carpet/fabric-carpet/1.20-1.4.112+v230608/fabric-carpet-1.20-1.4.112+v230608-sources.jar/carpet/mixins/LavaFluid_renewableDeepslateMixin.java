package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3616;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3616.class)
public abstract class LavaFluid_renewableDeepslateMixin {
    @Shadow protected abstract void fizz(class_1936 world, class_2338 pos);

    @Inject(method = "spreadTo", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;defaultBlockState()Lnet/minecraft/world/level/block/state/BlockState;"), cancellable = true)
    private void generateDeepslate(class_1936 world, class_2338 pos, class_2680 state, class_2350 direction, class_3610 fluidState, CallbackInfo ci)
    {
        if(CarpetSettings.renewableDeepslate && ((class_1937)world).method_27983() == class_1937.field_25179 && pos.method_10264() < 0)
        {
            world.method_8652(pos, class_2246.field_28888.method_9564(), 3);
            this.fizz(world, pos);
            ci.cancel();
        }
    }
}
