package carpet.script.value;

import carpet.script.CarpetContext;
import carpet.script.exception.InternalExpressionException;
import carpet.script.exception.ThrowStatement;
import carpet.script.exception.Throwables;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.class_1268;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2259;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_4208;
import net.minecraft.class_7924;

import static carpet.script.value.NBTSerializableValue.nameFromRegistryId;
import static carpet.script.value.NBTSerializableValue.nameFromResource;

public class BlockValue extends Value
{
    private class_2680 blockState;
    private final class_2338 pos;
    private final class_3218 world;
    private class_2487 data;

    // we only care for null values a few times, most of the time we would assume its all present
    public static final BlockValue NONE = new BlockValue(class_2246.field_10124.method_9564(), null, class_2338.field_10980, null);

    public static BlockValue fromCoords(CarpetContext c, int x, int y, int z)
    {
        class_2338 pos = locateBlockPos(c, x, y, z);
        return new BlockValue(null, c.level(), pos);
    }

    private static final Map<String, BlockValue> bvCache = new HashMap<>();

    public static BlockValue fromString(String str, class_3218 level)
    {
        try
        {
            BlockValue bv = bvCache.get(str); // [SCARY SHIT] persistent caches over server reloads
            if (bv != null)
            {
                return bv;
            }
            class_2259.class_7211 foo = class_2259.method_41955(level.method_30349().method_46762(class_7924.field_41254), new StringReader(str), true);
            if (foo.comp_622() != null)
            {
                class_2487 bd = foo.comp_624();
                if (bd == null)
                {
                    bd = new class_2487();
                }
                bv = new BlockValue(foo.comp_622(), level, null, bd);
                if (bvCache.size() > 10000)
                {
                    bvCache.clear();
                }
                bvCache.put(str, bv);
                return bv;
            }
        }
        catch (CommandSyntaxException ignored)
        {
        }
        throw new ThrowStatement(str, Throwables.UNKNOWN_BLOCK);
    }

    public static class_2338 locateBlockPos(CarpetContext c, int xpos, int ypos, int zpos)
    {
        class_2338 pos = c.origin();
        return new class_2338(pos.method_10263() + xpos, pos.method_10264() + ypos, pos.method_10260() + zpos);
    }

    public class_2680 getBlockState()
    {
        if (blockState != null)
        {
            return blockState;
        }
        if (pos != null)
        {
            blockState = world.method_8320(pos);
            return blockState;
        }
        throw new InternalExpressionException("Attempted to fetch block state without world or stored block state");
    }

    public static class_2586 getBlockEntity(class_1937 level, class_2338 pos)
    {
        if (level instanceof final class_3218 serverLevel)
        {
            return serverLevel.method_8503().method_18854()
                    ? serverLevel.method_8321(pos)
                    : serverLevel.method_8500(pos).method_12201(pos, class_2818.class_2819.field_12860);
        }
        return null;
    }


    public class_2487 getData()
    {
        if (data != null)
        {
            return data.method_33133() ? null : data;
        }
        if (pos != null)
        {
            class_2586 be = getBlockEntity(world, pos);
            if (be == null)
            {
                data = new class_2487();
                return null;
            }
            data = be.method_38244();
            return data;
        }
        return null;
    }


    public BlockValue(class_2680 state, class_3218 world, class_2338 position)
    {
        this.world = world;
        blockState = state;
        pos = position;
        data = null;
    }

    public BlockValue(class_2680 state)
    {
        this.world = null;
        blockState = state;
        pos = null;
        data = null;
    }

    public BlockValue(class_3218 world, class_2338 position)
    {
        this.world = world;
        blockState = null;
        pos = position;
        data = null;
    }

    public BlockValue(class_2680 state, class_2487 nbt)
    {
        this.world = null;
        blockState = state;
        pos = null;
        data = nbt;
    }

    public BlockValue(class_2680 state, class_3218 world, class_2487 nbt)
    {
        this.world = world;
        blockState = state;
        pos = null;
        data = nbt;
    }

    private BlockValue(@Nullable class_2680 state, @Nullable class_3218 world, @Nullable class_2338 position, @Nullable class_2487 nbt)
    {
        this.world = world;
        blockState = state;
        pos = position;
        data = nbt;
    }


    @Override
    public String getString()
    {
        class_2378<class_2248> blockRegistry = world.method_30349().method_30530(class_7924.field_41254);
        return nameFromResource(blockRegistry.method_10221(getBlockState().method_26204()));
    }

    @Override
    public boolean getBoolean()
    {
        return !getBlockState().method_26215();
    }

    @Override
    public String getTypeString()
    {
        return "block";
    }

    @Override
    public Value clone()
    {
        return new BlockValue(blockState, world, pos, data);
    }

    @Override
    public int hashCode()
    {
        return pos != null
                ? class_4208.method_19443(world.method_27983(), pos).hashCode()
                : ("b" + getString()).hashCode();
    }

    public class_2338 getPos()
    {
        return pos;
    }

    public class_1937 getWorld()
    {
        return world;
    }

    @Override
    public class_2520 toTag(boolean force)
    {
        if (!force)
        {
            throw new NBTSerializableValue.IncompatibleTypeException(this);
        }
        // follows falling block convertion
        class_2487 tag = new class_2487();
        class_2487 state = new class_2487();
        class_2680 s = getBlockState();
        state.method_10566("Name", class_2519.method_23256(world.method_30349().method_30530(class_7924.field_41254).method_10221(s.method_26204()).toString()));
        Collection<class_2769<?>> properties = s.method_28501();
        if (!properties.isEmpty())
        {
            class_2487 props = new class_2487();
            for (class_2769<?> p : properties)
            {
                props.method_10566(p.method_11899(), class_2519.method_23256(s.method_11654(p).toString().toLowerCase(Locale.ROOT)));
            }
            state.method_10566("Properties", props);
        }
        tag.method_10566("BlockState", state);
        class_2487 dataTag = getData();
        if (dataTag != null)
        {
            tag.method_10566("TileEntityData", dataTag);
        }
        return tag;
    }

    public enum SpecificDirection
    {
        UP("up", 0.5, 0.0, 0.5, class_2350.field_11036),

        UPNORTH("up-north", 0.5, 0.0, 0.4, class_2350.field_11036),
        UPSOUTH("up-south", 0.5, 0.0, 0.6, class_2350.field_11036),
        UPEAST("up-east", 0.6, 0.0, 0.5, class_2350.field_11036),
        UPWEST("up-west", 0.4, 0.0, 0.5, class_2350.field_11036),

        DOWN("down", 0.5, 1.0, 0.5, class_2350.field_11033),

        DOWNNORTH("down-north", 0.5, 1.0, 0.4, class_2350.field_11033),
        DOWNSOUTH("down-south", 0.5, 1.0, 0.6, class_2350.field_11033),
        DOWNEAST("down-east", 0.6, 1.0, 0.5, class_2350.field_11033),
        DOWNWEST("down-west", 0.4, 1.0, 0.5, class_2350.field_11033),


        NORTH("north", 0.5, 0.4, 1.0, class_2350.field_11043),
        SOUTH("south", 0.5, 0.4, 0.0, class_2350.field_11035),
        EAST("east", 0.0, 0.4, 0.5, class_2350.field_11034),
        WEST("west", 1.0, 0.4, 0.5, class_2350.field_11039),

        NORTHUP("north-up", 0.5, 0.6, 1.0, class_2350.field_11043),
        SOUTHUP("south-up", 0.5, 0.6, 0.0, class_2350.field_11035),
        EASTUP("east-up", 0.0, 0.6, 0.5, class_2350.field_11034),
        WESTUP("west-up", 1.0, 0.6, 0.5, class_2350.field_11039);

        public final String name;
        public final class_243 hitOffset;
        public final class_2350 facing;

        private static final Map<String, SpecificDirection> DIRECTION_MAP = Arrays.stream(values()).collect(Collectors.toMap(SpecificDirection::getName, d -> d));


        SpecificDirection(String name, double hitx, double hity, double hitz, class_2350 blockFacing)
        {
            this.name = name;
            this.hitOffset = new class_243(hitx, hity, hitz);
            this.facing = blockFacing;
        }

        private String getName()
        {
            return name;
        }
    }

    public static class PlacementContext extends class_1750
    {
        private final class_2350 facing;
        private final boolean sneakPlace;

        public static PlacementContext from(class_1937 world, class_2338 pos, String direction, boolean sneakPlace, class_1799 itemStack)
        {
            SpecificDirection dir = SpecificDirection.DIRECTION_MAP.get(direction);
            if (dir == null)
            {
                throw new InternalExpressionException("unknown block placement direction: " + direction);
            }
            class_3965 hitres = new class_3965(class_243.method_24954(pos).method_1019(dir.hitOffset), dir.facing, pos, false);
            return new PlacementContext(world, dir.facing, sneakPlace, itemStack, hitres);
        }

        private PlacementContext(class_1937 world_1, class_2350 direction_1, boolean sneakPlace, class_1799 itemStack_1, class_3965 hitres)
        {
            super(world_1, null, class_1268.field_5808, itemStack_1, hitres);
            this.facing = direction_1;
            this.sneakPlace = sneakPlace;
        }

        @Override
        public class_2338 method_8037()
        {
            boolean prevcanReplaceExisting = field_7904;
            field_7904 = true;
            class_2338 ret = super.method_8037();
            field_7904 = prevcanReplaceExisting;
            return ret;
        }

        @Override
        public class_2350 method_7715()
        {
            return facing.method_10153();
        }

        @Override
        public class_2350[] method_7718()
        {
            return switch (this.facing)
            {
                case field_11033 -> new class_2350[]{class_2350.field_11033, class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039, class_2350.field_11036};
                case field_11036 -> new class_2350[]{class_2350.field_11033, class_2350.field_11036, class_2350.field_11043, class_2350.field_11034, class_2350.field_11035, class_2350.field_11039};
                case field_11043 -> new class_2350[]{class_2350.field_11033, class_2350.field_11043, class_2350.field_11034, class_2350.field_11039, class_2350.field_11036, class_2350.field_11035};
                case field_11035 -> new class_2350[]{class_2350.field_11033, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039, class_2350.field_11036, class_2350.field_11043};
                case field_11039 -> new class_2350[]{class_2350.field_11033, class_2350.field_11039, class_2350.field_11035, class_2350.field_11036, class_2350.field_11043, class_2350.field_11034};
                case field_11034 -> new class_2350[]{class_2350.field_11033, class_2350.field_11034, class_2350.field_11035, class_2350.field_11036, class_2350.field_11043, class_2350.field_11039};
            };
        }

        @Override
        public class_2350 method_8042()
        {
            return this.facing.method_10166() == class_2350.class_2351.field_11052 ? class_2350.field_11043 : this.facing;
        }

        @Override
        public class_2350 method_32760()
        {
            return facing.method_10166() == class_2351.field_11052 ? facing : class_2350.field_11036;
        }

        @Override
        public boolean method_8046()
        {
            return sneakPlace;
        }

        @Override
        public float method_8044()
        {
            return (float) (this.facing.method_10161() * 90);
        }
    }
}
