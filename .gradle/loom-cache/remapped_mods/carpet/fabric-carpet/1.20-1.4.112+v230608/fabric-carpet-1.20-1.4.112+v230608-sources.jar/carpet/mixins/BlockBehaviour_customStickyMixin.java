package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;

import carpet.fakes.BlockBehaviourInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

@Mixin(class_4970.class)
public class BlockBehaviour_customStickyMixin implements BlockBehaviourInterface {

    @Override
    public boolean isSticky(class_2680 state) {
        return false;
    }

    @Override
    public boolean isStickyToNeighbor(class_1937 level, class_2338 pos, class_2680 state, class_2338 neighborPos, class_2680 neighborState, class_2350 dir, class_2350 moveDir) {
        return false;
    }
}
