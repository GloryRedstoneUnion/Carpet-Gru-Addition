package carpet.mixins;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5362;

import static carpet.script.CarpetEventServer.Event.EXPLOSION_OUTCOME;

@Mixin(value = class_1927.class, priority = 990)
public abstract class Explosion_scarpetEventMixin
{
    @Shadow @Final private class_1937 level;
    @Shadow @Final private double x;
    @Shadow @Final private double y;
    @Shadow @Final private double z;
    @Shadow @Final private float radius;
    @Shadow @Final private boolean fire;
    @Shadow @Final private ObjectArrayList<class_2338> toBlow;
    @Shadow @Final private class_1927.class_4179 blockInteraction;
    @Shadow @Final private @Nullable class_1297 source;

    @Shadow /*@Nullable*/ public abstract /*@Nullable*/ class_1309 getIndirectSourceEntity();

    @Shadow public static float getSeenPercent(class_243 source, class_1297 entity) {return 0.0f;}

    private List<class_1297> affectedEntities;

    @Inject(method = "<init>(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;Lnet/minecraft/world/level/ExplosionDamageCalculator;DDDFZLnet/minecraft/world/level/Explosion$BlockInteraction;)V",
            at = @At(value = "RETURN"))
    private void onExplosionCreated(class_1937 world, class_1297 entity, class_1282 damageSource, class_5362 explosionBehavior, double x, double y, double z, float power, boolean createFire, class_1927.class_4179 destructionType, CallbackInfo ci)
    {
        if (EXPLOSION_OUTCOME.isNeeded() && !world.method_8608())
        {
            affectedEntities = new ArrayList<>();
        }
    }

    @Redirect(method = "explode", at=@At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/Explosion;getSeenPercent(Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/entity/Entity;)F")
    )
    private float onExplosion(class_243 source, class_1297 entity)
    {
        if (affectedEntities != null)
        {
            affectedEntities.add(entity);
        }
        return getSeenPercent(source, entity);
    }

    @Inject(method = "finalizeExplosion", at = @At("HEAD"))
    private void onExplosion(boolean spawnParticles, CallbackInfo ci)
    {
        if (EXPLOSION_OUTCOME.isNeeded() && !level.method_8608())
        {
            EXPLOSION_OUTCOME.onExplosion((class_3218) level, source, this::getIndirectSourceEntity, x, y, z, radius, fire, toBlow, affectedEntities, blockInteraction);
        }
    }
}
