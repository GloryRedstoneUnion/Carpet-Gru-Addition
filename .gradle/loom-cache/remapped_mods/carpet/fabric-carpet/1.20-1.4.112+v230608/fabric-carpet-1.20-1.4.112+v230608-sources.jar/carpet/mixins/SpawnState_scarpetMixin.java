package carpet.mixins;

import carpet.fakes.SpawnHelperInnerInterface;
import net.minecraft.class_1948;
import net.minecraft.class_5263;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1948.class_5262.class)
public class SpawnState_scarpetMixin implements SpawnHelperInnerInterface
{
    @Shadow @Final private class_5263 spawnPotential;

    @Override
    public class_5263 getPotentialCalculator()
    {
        return spawnPotential;
    }
}
