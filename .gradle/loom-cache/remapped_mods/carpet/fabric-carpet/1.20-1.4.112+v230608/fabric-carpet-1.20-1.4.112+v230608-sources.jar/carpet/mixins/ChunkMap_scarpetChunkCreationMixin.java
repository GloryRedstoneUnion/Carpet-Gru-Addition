package carpet.mixins;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.function.IntFunction;
import java.util.stream.Collectors;

import carpet.fakes.SimpleEntityLookupInterface;
import carpet.fakes.ServerWorldInterface;
import net.minecraft.class_1255;
import net.minecraft.class_1297;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1923;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_2861;
import net.minecraft.class_3193;
import net.minecraft.class_3193.class_3724;
import net.minecraft.class_3218;
import net.minecraft.class_3227;
import net.minecraft.class_3230;
import net.minecraft.class_3738;
import net.minecraft.class_3898;
import net.minecraft.class_3898.class_3216;
import net.minecraft.class_3900;
import net.minecraft.class_3949;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.tuple.Pair;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.mojang.datafixers.util.Either;

import carpet.fakes.ChunkHolderInterface;
import carpet.fakes.ChunkTicketManagerInterface;
import carpet.fakes.ServerLightingProviderInterface;
import carpet.fakes.ThreadedAnvilChunkStorageInterface;
import carpet.script.utils.WorldTools;
import it.unimi.dsi.fastutil.longs.Long2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;

import static carpet.script.CarpetEventServer.Event.CHUNK_GENERATED;
import static carpet.script.CarpetEventServer.Event.CHUNK_LOADED;

@Mixin(class_3898.class)
public abstract class ChunkMap_scarpetChunkCreationMixin implements ThreadedAnvilChunkStorageInterface
{
    @Shadow
    @Final
    private class_3218 level;

    @Shadow
    @Final
    private LongSet entitiesInLevel;

    @Shadow
    @Final
    private Long2ObjectLinkedOpenHashMap<class_3193> updatingChunkMap;

    @Shadow
    private boolean modified;

    @Shadow
    @Final
    private class_3227 lightEngine;

    @Shadow
    @Final
    private class_3900 queueSorter;

    @Shadow
    @Final
    private class_1255<Runnable> mainThreadExecutor;

    @Shadow
    @Final
    private class_3949 progressListener;

    @Shadow
    @Final
    private class_3216 distanceManager;

    @Shadow
    protected abstract boolean promoteChunkMap();

    @Shadow
    protected abstract Iterable<class_3193> getChunks();


    @Shadow protected abstract CompletableFuture<Either<List<class_2791>, class_3724>> getChunkRangeFuture(final class_3193 chunkHolder, final int i, final IntFunction<class_2806> intFunction);

    //@Shadow protected abstract void postLoadProtoChunk(final ServerLevel serverLevel, final List<CompoundTag> list);

    ThreadLocal<Boolean> generated = ThreadLocal.withInitial(() -> null);

    // in protoChunkToFullChunk
    // fancier version of the one below, ensuring that the event is triggered when the chunk is actually loaded.
    @Inject(method = "method_20460", at = @At("HEAD"), remap = false)
    private void onChunkGeneratedStart(class_3193 chunkHolder, Either<class_2791, class_3724> chunk, CallbackInfoReturnable<CompletableFuture<Either<class_2791, class_3724>>> cir)
    {
        if (CHUNK_GENERATED.isNeeded() || CHUNK_LOADED.isNeeded())
        {
            generated.set(chunkHolder.method_14010().method_12009() != class_2806.field_12803);
        }
        else
        {
            generated.set(null);
        }
    }

    @Inject(method = "method_20460", at = @At("RETURN"), remap = false)
    private void onChunkGeneratedEnd(class_3193 chunkHolder, Either<class_2791, class_3724> chunk, CallbackInfoReturnable<CompletableFuture<Either<class_2791, class_3724>>> cir)
    {
        Boolean localGenerated= generated.get();
        if (localGenerated != null)
        {
            MinecraftServer server =  this.level.method_8503();
            int ticks = server.method_3780();
            class_1923 chpos = chunkHolder.method_13994();
            // need to send these because if an app does something with that event, it may lock the thread
            // so better be safe and schedule it for later, aSaP
            if (CHUNK_GENERATED.isNeeded() && localGenerated)
               server.method_18858(new class_3738(ticks, () -> CHUNK_GENERATED.onChunkEvent(this.level, chpos, true)));
            if (CHUNK_LOADED.isNeeded())
               server.method_18858(new class_3738(ticks, () -> CHUNK_LOADED.onChunkEvent(this.level, chpos, localGenerated)));
        }
    }

    /* simple but a version that doesn't guarantee that the chunk is actually loaded
    @Inject(method = "convertToFullChunk", at = @At("HEAD"))
    private void onChunkGeneratedEnd(ChunkHolder chunkHolder, CallbackInfoReturnable<CompletableFuture<Either<Chunk, Unloaded>>> cir)
    {
        if (CHUNK_GENERATED.isNeeded() && chunkHolder.getCurrentChunk().getStatus() != ChunkStatus.FULL)
        {
            ChunkPos chpos = chunkHolder.getPos();
            this.world.getServer().execute(() -> CHUNK_GENERATED.onChunkEvent(this.world, chpos, true));
        }
        if (CHUNK_LOADED.isNeeded())
        {
            boolean generated = chunkHolder.getCurrentChunk().getStatus() != ChunkStatus.FULL;
            ChunkPos chpos = chunkHolder.getPos();
            this.world.getServer().execute(() -> CHUNK_LOADED.onChunkEvent(this.world, chpos, generated));
        }
    }
     */

    @Unique
    private void addTicket(final class_1923 pos, final class_2806 status)
    {  // UNKNOWN
        this.distanceManager.method_17290(class_3230.field_14032, pos, 33 + class_2806.method_12175(status), pos);
    }

    @Unique
    private void addTicket(final class_1923 pos)
    {
        this.addTicket(pos, class_2806.field_12798);
    }

    @Unique
    private void addRelightTicket(final class_1923 pos)
    {
        this.distanceManager.method_17291(class_3230.field_19270, pos, 1, pos);
    }

    @Override
    public void releaseRelightTicket(final class_1923 pos)
    {
        this.mainThreadExecutor.method_18858(class_156.method_18839(
            () -> this.distanceManager.method_17292(class_3230.field_19270, pos, 1, pos),
            () -> "release relight ticket " + pos
        ));
    }

    @Unique
    private void tickTicketManager()
    {
        this.distanceManager.method_15892((class_3898) (Object) this);
    }

    @Unique
    private Set<class_1923> getExistingChunks(final Set<class_1923> requestedChunks)
    {
        final Map<String, class_2861> regionCache = new HashMap<>();
        final Set<class_1923> ret = new HashSet<>();

        for (final class_1923 pos : requestedChunks)
            if (WorldTools.canHasChunk(this.level, pos, regionCache, true))
                ret.add(pos);

        return ret;
    }

    @Unique
    private Set<class_1923> loadExistingChunksFromDisk(final Set<class_1923> requestedChunks)
    {
        final Set<class_1923> existingChunks = this.getExistingChunks(requestedChunks);
        for (final class_1923 pos : existingChunks)
            this.updatingChunkMap.get(pos.method_8324()).method_13993(class_2806.field_12798, (class_3898) (Object) this);

        return existingChunks;
    }

    @Unique
    private Set<class_1923> loadExistingChunks(final Set<class_1923> requestedChunks, final Object2IntMap<String> report)
    {
        if (report != null)
            report.put("requested_chunks", requestedChunks.size());

        // Load all relevant ChunkHolders into this.currentChunkHolders
        // This will not trigger loading from disk yet

        for (final class_1923 pos : requestedChunks)
            this.addTicket(pos);

        this.tickTicketManager();

        // Fetch all currently loaded chunks

        final Set<class_1923> loadedChunks = requestedChunks.stream().filter(
            pos -> this.updatingChunkMap.get(pos.method_8324()).method_14010() != null // all relevant ChunkHolders exist
        ).collect(Collectors.toSet());

        if (report != null)
            report.put("loaded_chunks", loadedChunks.size());

        // Load remaining chunks from disk

        final Set<class_1923> unloadedChunks = new HashSet<>(requestedChunks);
        unloadedChunks.removeAll(loadedChunks);

        final Set<class_1923> existingChunks = this.loadExistingChunksFromDisk(unloadedChunks);

        existingChunks.addAll(loadedChunks);

        return existingChunks;
    }

    @Unique
    private Set<class_1923> loadExistingChunks(final Set<class_1923> requestedChunks)
    {
        return this.loadExistingChunks(requestedChunks, null);
    }

    @Unique
    private void waitFor(final Future<?> future)
    {
        this.mainThreadExecutor.method_18857(future::isDone);
    }

    @Unique
    private void waitFor(final List<? extends CompletableFuture<?>> futures)
    {
        this.waitFor(class_156.method_652(futures));
    }

    @Unique
    private class_2791 getCurrentChunk(final class_1923 pos)
    {
        final CompletableFuture<class_2791> future = this.updatingChunkMap.get(pos.method_8324()).method_14000();
        this.waitFor(future);

        return future.join();
    }

    @Override
    public void relightChunk(class_1923 pos)
    {
        this.addTicket(pos);
        this.tickTicketManager();
        if (this.updatingChunkMap.get(pos.method_8324()).method_14010() == null) // chunk unloaded
            if (WorldTools.canHasChunk(this.level, pos, null, true))
                this.updatingChunkMap.get(pos.method_8324()).method_13993(class_2806.field_12798, (class_3898) (Object) this);
        final class_2791 chunk = this.getCurrentChunk(pos);
        if (!(chunk.method_12009().method_12165(class_2806.field_12805.method_16560()))) return;
        ((ServerLightingProviderInterface) this.lightEngine).removeLightData(chunk);
        this.addRelightTicket(pos);
        class_3193 chunkHolder = this.updatingChunkMap.get(pos.method_8324());
        final CompletableFuture<?> lightFuture = this.getChunkRangeFuture(chunkHolder, 1, (pos_) -> class_2806.field_12805)
                .thenCompose(
                    either -> either.map(
                            list -> ((ServerLightingProviderInterface) this.lightEngine).relight(chunk),
                            unloaded -> {
                                this.releaseRelightTicket(pos);
                                return CompletableFuture.completedFuture(null);
                            }
                    )
                );
        this.waitFor(lightFuture);
    }

    @Override
    public Map<String, Integer> regenerateChunkRegion(final List<class_1923> requestedChunksList)
    {
        final Object2IntMap<String> report = new Object2IntOpenHashMap<>();
        final Set<class_1923> requestedChunks = new HashSet<>(requestedChunksList);

        // Load requested chunks

        final Set<class_1923> existingChunks = this.loadExistingChunks(requestedChunks, report);

        // Finish pending generation stages
        // This ensures that no generation events will be put back on the main thread after the chunks have been deleted

        final Set<class_2791> affectedChunks = new HashSet<>();

        for (final class_1923 pos : existingChunks)
            affectedChunks.add(this.getCurrentChunk(pos));

        report.put("affected_chunks", affectedChunks.size());

        // Load neighbors for light removal

        final Set<class_1923> neighbors = new HashSet<>();

        for (final class_2791 chunk : affectedChunks)
        {
            final class_1923 pos = chunk.method_12004();

            for (int x = -1; x <= 1; ++x)
                for (int z = -1; z <= 1; ++z)
                    if (x != 0 || z != 0)
                    {
                        final class_1923 nPos = new class_1923(pos.field_9181 + x, pos.field_9180 + z);
                        if (!requestedChunks.contains(nPos))
                            neighbors.add(nPos);
                    }
        }

        this.loadExistingChunks(neighbors);

        // Determine affected neighbors

        final Set<class_2791> affectedNeighbors = new HashSet<>();

        for (final class_1923 pos : neighbors)
        {
            final class_2791 chunk = this.getCurrentChunk(pos);

            if (chunk.method_12009().method_12165(class_2806.field_12805.method_16560()))
                affectedNeighbors.add(chunk);
        }

        // Unload affected chunks

        for (final class_2791 chunk : affectedChunks)
        {
            final class_1923 pos = chunk.method_12004();

            // remove entities
            long longPos = pos.method_8324();
            if (this.entitiesInLevel.contains(longPos) && chunk instanceof class_2818)
                ((SimpleEntityLookupInterface<class_1297>)((ServerWorldInterface)level).getEntityLookupCMPublic()).getChunkEntities(pos).forEach(entity -> { if (!(entity instanceof class_1657)) entity.method_31472();});


            if (chunk instanceof class_2818)
                ((class_2818) chunk).method_12226(false);

            if (this.entitiesInLevel.remove(pos.method_8324()) && chunk instanceof class_2818)
                this.level.method_18764((class_2818) chunk); // block entities only

            ((ServerLightingProviderInterface) this.lightEngine).invokeUpdateChunkStatus(pos);
            ((ServerLightingProviderInterface) this.lightEngine).removeLightData(chunk);

            this.progressListener.method_17670(pos, null);
        }

        // Replace ChunkHolders

        for (final class_2791 chunk : affectedChunks)
        {
            final class_1923 cPos = chunk.method_12004();
            final long pos = cPos.method_8324();

            final class_3193 oldHolder = this.updatingChunkMap.remove(pos);
            final class_3193 newHolder = new class_3193(cPos, oldHolder.method_14005(), level, this.lightEngine, this.queueSorter, (class_3193.class_3897) this);
            ((ChunkHolderInterface) newHolder).setDefaultProtoChunk(cPos, this.mainThreadExecutor, level); // enable chunk blending?
            this.updatingChunkMap.put(pos, newHolder);

            ((ChunkTicketManagerInterface) this.distanceManager).replaceHolder(oldHolder, newHolder);
        }

        this.modified = true;
        this.promoteChunkMap();




        // Force generation to previous states
        // This ensures that the world is in a consistent state after this method
        // Also, this is needed to ensure chunks are saved to disk

        final Map<class_1923, class_2806> targetGenerationStatus = affectedChunks.stream().collect(
            Collectors.toMap(class_2791::method_12004, class_2791::method_12009)
        );

        for (final Entry<class_1923, class_2806> entry : targetGenerationStatus.entrySet())
            this.addTicket(entry.getKey(), entry.getValue());

        this.tickTicketManager();

        final List<Pair<class_2806, CompletableFuture<?>>> targetGenerationFutures = new ArrayList<>();

        for (final Entry<class_1923, class_2806> entry : targetGenerationStatus.entrySet())
            targetGenerationFutures.add(Pair.of(
                entry.getValue(),
                this.updatingChunkMap.get(entry.getKey().method_8324()).method_13993(entry.getValue(), (class_3898) (Object) this)
            ));

        final Map<class_2806, List<CompletableFuture<?>>> targetGenerationFuturesGrouped = targetGenerationFutures.stream().collect(
            Collectors.groupingBy(
                Pair::getKey,
                Collectors.mapping(
                    Entry::getValue,
                    Collectors.toList()
                )
            )
        );

        for (final class_2806 status : class_2806.method_16558())
        {
            final List<CompletableFuture<?>> futures = targetGenerationFuturesGrouped.get(status);

            if (futures == null)
                continue;

            String statusName = class_7923.field_41184.method_10221(status).method_12832();

            report.put("layer_count_" + statusName, futures.size());
            final long start = System.currentTimeMillis();

            this.waitFor(futures);

            report.put("layer_time_" + statusName, (int) (System.currentTimeMillis() - start));
        }





        report.put("relight_count", affectedNeighbors.size());

        // Remove light for affected neighbors

        for (final class_2791 chunk : affectedNeighbors)
            ((ServerLightingProviderInterface) this.lightEngine).removeLightData(chunk);

        // Schedule relighting of neighbors

        for (final class_2791 chunk : affectedNeighbors)
            this.addRelightTicket(chunk.method_12004());

        this.tickTicketManager();

        final List<CompletableFuture<?>> lightFutures = new ArrayList<>();

        for (final class_2791 chunk : affectedNeighbors)
        {
            final class_1923 pos = chunk.method_12004();

            lightFutures.add(this.getChunkRangeFuture (this.updatingChunkMap.get(pos.method_8324()), 1, (pos_) -> class_2806.field_12805).thenCompose(
                    either -> either.map(
                            list -> ((ServerLightingProviderInterface) this.lightEngine).relight(chunk),
                            unloaded -> {
                                this.releaseRelightTicket(pos);
                                return CompletableFuture.completedFuture(null);
                            }
                    )
            ));
        }


        final long relightStart = System.currentTimeMillis();

        this.waitFor(lightFutures);

        report.put("relight_time", (int) (System.currentTimeMillis() - relightStart));

        return report;
    }

    @Override
    public Iterable<class_3193> getChunksCM() {
        return getChunks();
    }
}
