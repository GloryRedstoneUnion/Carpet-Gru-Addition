package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntity_creativeFlyMixin extends class_1297
{
    @Shadow protected abstract float getFlyingSpeed();

    public LivingEntity_creativeFlyMixin(class_1299<?> type, class_1937 world)
    {
        super(type, world);
    }

    @ModifyConstant(method = "travel", constant = @Constant(floatValue = 0.91F), expect = 2)
    private float drag(float original)
    {
        if (CarpetSettings.creativeFlyDrag != 0.09 && (Object)this instanceof class_1657)
        {
            class_1657 self = (class_1657)(Object)(this);
            if (self.method_31549().field_7479 && ! method_24828() )
                return (float)(1.0-CarpetSettings.creativeFlyDrag);
        }
        return original;
    }


    @Inject(method = "getFrictionInfluencedSpeed(F)F", at = @At("HEAD"), cancellable = true)
    private void flyingAltSpeed(float slipperiness, CallbackInfoReturnable<Float> cir)
    {
        if (CarpetSettings.creativeFlySpeed != 1.0D && (Object)this instanceof class_1657)
        {
            class_1657 self = (class_1657)(Object)(this);
            if (self.method_31549().field_7479 && !method_24828())
                cir.setReturnValue( getFlyingSpeed() * (float)CarpetSettings.creativeFlySpeed);
        }
    }
}
