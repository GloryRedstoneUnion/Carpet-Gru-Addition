package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2561;
import net.minecraft.class_2926;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2926.class)
public class ServerStatus_motdMixin
{
    @Inject(method = "description", at = @At("HEAD"), cancellable = true)
    private void getDescriptionAlternative(CallbackInfoReturnable<class_2561> cir)
    {
        if (!CarpetSettings.customMOTD.equals("_"))
        {
            cir.setReturnValue(class_2561.method_43470(CarpetSettings.customMOTD));
            cir.cancel();
        }
    }
}
