package carpet.fakes;

import net.minecraft.class_1657;
import net.minecraft.class_1860;
import net.minecraft.class_3222;
import net.minecraft.class_3915;

public interface AbstractContainerMenuInterface
{
    class_3915 getDataSlot(int index);
    boolean callButtonClickListener(int button, class_1657 player);
    boolean callSelectRecipeListener(class_3222 player, class_1860<?> recipe, boolean craftAll);
}
