package carpet.mixins;

import carpet.fakes.ServerPlayerInterface;
import carpet.script.external.Vanilla;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static carpet.script.CarpetEventServer.Event.PLAYER_RESPAWNS;

@Mixin(class_3324.class)
public class PlayerList_scarpetEventsMixin
{
    @Shadow @Final private MinecraftServer server;

    @Inject(method = "respawn", at = @At("HEAD"))
    private void onRespawn(class_3222 player, boolean olive, CallbackInfoReturnable<class_3222> cir)
    {
        PLAYER_RESPAWNS.onPlayerEvent(player);
    }

    @Inject(method = "respawn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;initInventoryMenu()V"
    ))
    private void invalidatePreviousInstance(class_3222 player, boolean alive, CallbackInfoReturnable<class_3222> cir)
    {
        ((ServerPlayerInterface)player).invalidateEntityObjectReference();
    }

    @Inject(method = "reloadResources", at = @At("HEAD"))
    private void reloadCommands(CallbackInfo ci)
    {
        Vanilla.MinecraftServer_getScriptServer(server).reAddCommands();
    }
}
