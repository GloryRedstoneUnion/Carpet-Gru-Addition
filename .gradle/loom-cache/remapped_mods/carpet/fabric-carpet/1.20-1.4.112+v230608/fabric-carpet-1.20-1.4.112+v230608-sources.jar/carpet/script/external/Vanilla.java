package carpet.script.external;

import carpet.CarpetSettings;
import carpet.fakes.BiomeInterface;
import carpet.fakes.BlockPredicateInterface;
import carpet.fakes.BlockStateArgumentInterface;
import carpet.fakes.ChunkTicketManagerInterface;
import carpet.fakes.CommandDispatcherInterface;
import carpet.fakes.EntityInterface;
import carpet.fakes.IngredientInterface;
import carpet.fakes.InventoryBearerInterface;
import carpet.fakes.ItemEntityInterface;
import carpet.fakes.LivingEntityInterface;
import carpet.fakes.MinecraftServerInterface;
import carpet.fakes.MobEntityInterface;
import carpet.fakes.RandomStateVisitorAccessor;
import carpet.fakes.RecipeManagerInterface;
import carpet.fakes.AbstractContainerMenuInterface;
import carpet.fakes.ServerPlayerInterface;
import carpet.fakes.ServerPlayerInteractionManagerInterface;
import carpet.fakes.ServerWorldInterface;
import carpet.fakes.SpawnHelperInnerInterface;
import carpet.fakes.ThreadedAnvilChunkStorageInterface;
import carpet.mixins.Objective_scarpetMixin;
import carpet.mixins.PoiRecord_scarpetMixin;
import carpet.mixins.Scoreboard_scarpetMixin;
import carpet.network.ServerNetworkHandler;
import carpet.script.CarpetScriptServer;
import carpet.script.EntityEventsGroup;
import carpet.script.value.MapValue;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import carpet.utils.CommandHelper;
import carpet.utils.SpawnReporter;
import com.mojang.brigadier.CommandDispatcher;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1355;
import net.minecraft.class_1496;
import net.minecraft.class_1542;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1923;
import net.minecraft.class_1928;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2168;
import net.minecraft.class_2247;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_266;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_2694;
import net.minecraft.class_274;
import net.minecraft.class_2960;
import net.minecraft.class_32;
import net.minecraft.class_3204;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3228;
import net.minecraft.class_3898;
import net.minecraft.class_3915;
import net.minecraft.class_3956;
import net.minecraft.class_4156;
import net.minecraft.class_4706;
import net.minecraft.class_5263;
import net.minecraft.class_5268;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6910;
import net.minecraft.class_7138;
import net.minecraft.server.MinecraftServer;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Predicate;

public class Vanilla
{
    public static void MinecraftServer_forceTick(MinecraftServer server, BooleanSupplier sup)
    {
        ((MinecraftServerInterface) server).forceTick(sup);
    }

    public static void ChunkMap_relightChunk(class_3898 chunkMap, class_1923 pos)
    {
        ((ThreadedAnvilChunkStorageInterface) chunkMap).relightChunk(pos);
    }

    public static Map<String, Integer> ChunkMap_regenerateChunkRegion(class_3898 chunkMap, List<class_1923> requestedChunks)
    {
        return ((ThreadedAnvilChunkStorageInterface) chunkMap).regenerateChunkRegion(requestedChunks);
    }

    public static List<Collection<class_1799>> Ingredient_getRecipeStacks(class_1856 ingredient)
    {
        return ((IngredientInterface) (Object) ingredient).getRecipeStacks();
    }

    public static List<class_1860<?>> RecipeManager_getAllMatching(class_1863 recipeManager, class_3956<?> type, class_2960 output, class_5455 registryAccess)
    {
        return ((RecipeManagerInterface) recipeManager).getAllMatching(type, output, registryAccess);
    }

    public static int NaturalSpawner_MAGIC_NUMBER()
    {
        return SpawnReporter.MAGIC_NUMBER;
    }

    public static class_5263 SpawnState_getPotentialCalculator(class_1948.class_5262 spawnState)
    {
        return ((SpawnHelperInnerInterface) spawnState).getPotentialCalculator();
    }

    public static void Objective_setCriterion(class_266 objective, class_274 criterion)
    {
        ((Objective_scarpetMixin) objective).setCriterion(criterion);
    }

    public static Map<class_274, List<class_266>> Scoreboard_getObjectivesByCriterion(class_269 scoreboard)
    {
        return ((Scoreboard_scarpetMixin) scoreboard).getObjectivesByCriterion();
    }

    public static class_5268 ServerLevel_getWorldProperties(class_3218 world)
    {
        return ((ServerWorldInterface) world).getWorldPropertiesCM();
    }

    public static Long2ObjectOpenHashMap<class_4706<class_3228<?>>> ChunkTicketManager_getTicketsByPosition(class_3204 ticketManager)
    {
        return ((ChunkTicketManagerInterface) ticketManager).getTicketsByPosition();
    }

    public static class_6910.class_6915 RandomState_getVisitor(class_7138 randomState)
    {
        return ((RandomStateVisitorAccessor) (Object) randomState).getVisitor();
    }

    public static class_2487 BlockInput_getTag(class_2247 blockInput)
    {
        return ((BlockStateArgumentInterface) blockInput).getCMTag();
    }

    public static CarpetScriptServer MinecraftServer_getScriptServer(MinecraftServer server)
    {
        return ((MinecraftServerInterface) server).getScriptServer();
    }

    public static class_1959.class_5482 Biome_getClimateSettings(class_1959 biome)
    {
        return ((BiomeInterface) (Object) biome).getClimateSettings();
    }

    public static ThreadLocal<Boolean> skipGenerationChecks(class_3218 level)
    { // not sure does vanilla care at all - needs checking
        return CarpetSettings.skipGenerationChecks;
    }

    public static void sendScarpetShapesDataToPlayer(class_3222 player, class_2520 data)
    { // dont forget to add the packet to vanilla packed handler and call ShapesRenderer.addShape to handle on client
        ServerNetworkHandler.sendCustomCommand(player, "scShapes", data);
    }

    public static int MinecraftServer_getRunPermissionLevel(MinecraftServer server)
    {
        return CarpetSettings.runPermissionLevel;
    }

    public static String MinecraftServer_getReleaseTarget(MinecraftServer server)
    {
        return CarpetSettings.releaseTarget;
    }

    public static boolean isDevelopmentEnvironment()
    {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    public static MapValue getServerMods(MinecraftServer server)
    {
        Map<Value, Value> ret = new HashMap<>();
        for (ModContainer mod : FabricLoader.getInstance().getAllMods())
        {
            ret.put(new StringValue(mod.getMetadata().getId()), new StringValue(mod.getMetadata().getVersion().getFriendlyString()));
        }
        return MapValue.wrap(ret);
    }

    public static class_32.class_5143 MinecraftServer_storageSource(MinecraftServer server)
    {
        return ((MinecraftServerInterface) server).getCMSession();
    }

    public static class_2338 ServerPlayerGameMode_getCurrentBlockPosition(class_3225 gameMode)
    {
        return ((ServerPlayerInteractionManagerInterface) gameMode).getCurrentBreakingBlock();
    }

    public static int ServerPlayerGameMode_getCurrentBlockBreakingProgress(class_3225 gameMode)
    {
        return ((ServerPlayerInteractionManagerInterface) gameMode).getCurrentBlockBreakingProgress();
    }

    public static void ServerPlayerGameMode_setBlockBreakingProgress(class_3225 gameMode, int progress)
    {
        ((ServerPlayerInteractionManagerInterface) gameMode).setBlockBreakingProgress(progress);
    }

    public static boolean ServerPlayer_isInvalidEntityObject(class_3222 player)
    {
        return ((ServerPlayerInterface) player).isInvalidEntityObject();
    }

    public static String ServerPlayer_getLanguage(class_3222 player)
    {
        return ((ServerPlayerInterface) player).getLanguage();
    }

    public static class_1355 Mob_getAI(class_1308 mob, boolean target)
    {
        return ((MobEntityInterface) mob).getAI(target);
    }

    public static Map<String, class_1352> Mob_getTemporaryTasks(class_1308 mob)
    {
        return ((MobEntityInterface) mob).getTemporaryTasks();
    }

    public static void Mob_setPersistence(class_1308 mob, boolean what)
    {
        ((MobEntityInterface) mob).setPersistence(what);
    }

    public static EntityEventsGroup Entity_getEventContainer(class_1297 entity)
    {
        return ((EntityInterface) entity).getEventContainer();
    }

    public static boolean Entity_isPermanentVehicle(class_1297 entity)
    {
        return ((EntityInterface) entity).isPermanentVehicle();
    }

    public static void Entity_setPermanentVehicle(class_1297 entity, boolean permanent)
    {
        ((EntityInterface) entity).setPermanentVehicle(permanent);
    }

    public static int Entity_getPortalTimer(class_1297 entity)
    {
        return ((EntityInterface) entity).getPortalTimer();
    }

    public static void Entity_setPortalTimer(class_1297 entity, int amount)
    {
        ((EntityInterface) entity).setPortalTimer(amount);
    }

    public static int Entity_getPublicNetherPortalCooldown(class_1297 entity)
    {
        return ((EntityInterface) entity).getPublicNetherPortalCooldown();
    }

    public static void Entity_setPublicNetherPortalCooldown(class_1297 entity, int what)
    {
        ((EntityInterface) entity).setPublicNetherPortalCooldown(what);
    }

    public static int ItemEntity_getPickupDelay(class_1542 entity)
    {
        return ((ItemEntityInterface) entity).getPickupDelayCM();
    }

    public static boolean LivingEntity_isJumping(class_1309 entity)
    {
        return ((LivingEntityInterface) entity).isJumpingCM();
    }

    public static void LivingEntity_setJumping(class_1309 entity)
    {
        ((LivingEntityInterface) entity).doJumpCM();
    }

    public static class_1263 AbstractHorse_getInventory(class_1496 horse)
    {
        return ((InventoryBearerInterface) horse).getCMInventory();
    }

    public static class_3915 AbstractContainerMenu_getDataSlot(class_1703 handler, int index)
    {
        return ((AbstractContainerMenuInterface) handler).getDataSlot(index);
    }

    public static void CommandDispatcher_unregisterCommand(CommandDispatcher<class_2168> dispatcher, String name)
    {
        ((CommandDispatcherInterface) dispatcher).carpet$unregister(name);
    }

    public static boolean MinecraftServer_doScriptsAutoload(MinecraftServer server)
    {
        return CarpetSettings.scriptsAutoload;
    }

    public static void MinecraftServer_notifyPlayersCommandsChanged(MinecraftServer server)
    {
        CommandHelper.notifyPlayersCommandsChanged(server);
    }

    public static boolean ScriptServer_scriptOptimizations(MinecraftServer scriptServer)
    {
        return CarpetSettings.scriptsOptimization;
    }

    public static boolean ScriptServer_scriptDebugging(MinecraftServer server)
    {
        return CarpetSettings.scriptsDebugging;
    }

    public static boolean ServerPlayer_canScriptACE(class_2168 player)
    {
        return CommandHelper.canUseCommand(player, CarpetSettings.commandScriptACE);
    }

    public static boolean ServerPlayer_canScriptGeneral(class_2168 player)
    {
        return CommandHelper.canUseCommand(player, CarpetSettings.commandScript);
    }

    public static int MinecraftServer_getFillLimit(MinecraftServer server)
    {
        return Math.max(server.method_3767().method_8356(class_1928.field_41766), CarpetSettings.fillLimit);
    }

    public static int PoiRecord_getFreeTickets(class_4156 record)
    {
        return ((PoiRecord_scarpetMixin) record).getFreeTickets();
    }

    public static void PoiRecord_callAcquireTicket(class_4156 record)
    {
        ((PoiRecord_scarpetMixin) record).callAcquireTicket();
    }

    public record BlockPredicatePayload(class_2680 state, class_6862<class_2248> tagKey, Map<Value, Value> properties, class_2487 tag) {
        public static BlockPredicatePayload of(Predicate<class_2694> blockPredicate)
        {
            BlockPredicateInterface predicateData = (BlockPredicateInterface) blockPredicate;
            return new BlockPredicatePayload(predicateData.getCMBlockState(), predicateData.getCMBlockTagKey(), predicateData.getCMProperties(), predicateData.getCMDataTag());
        }
    }

}
