package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(class_3218.class)
public class ServerLevel_spawnChunksMixin
{
    @ModifyConstant(method = "setDefaultSpawnPos", constant = @Constant(intValue = 11), expect = 2)
    private int pushLimit(int original)
    {
        return CarpetSettings.spawnChunksSize;
    }
}
