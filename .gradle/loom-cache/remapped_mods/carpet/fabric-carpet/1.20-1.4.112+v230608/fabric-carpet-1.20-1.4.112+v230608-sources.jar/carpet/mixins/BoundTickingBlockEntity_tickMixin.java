package carpet.mixins;

import carpet.fakes.LevelInterface;
import carpet.helpers.TickRateManager;
import carpet.utils.CarpetProfiler;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity")
public class BoundTickingBlockEntity_tickMixin<T extends class_2586>
{
    @Shadow @Final private T blockEntity;
    CarpetProfiler.ProfilerToken entitySection;


    @Inject(method = "tick()V", at = @At("HEAD"))
    private void startTileEntitySection(CallbackInfo ci)
    {
        entitySection = CarpetProfiler.start_block_entity_section(blockEntity.method_10997(), blockEntity, CarpetProfiler.TYPE.TILEENTITY);
    }

    @Redirect(method = "tick()V", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/entity/BlockEntityTicker;tick(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/entity/BlockEntity;)V"
    ))
    private void checkProcessBEs(class_5558<T> blockEntityTicker, class_1937 world, class_2338 pos, class_2680 state, T blockEntity)
    {
        TickRateManager tickRateManager = ((LevelInterface)world).tickRateManager();
        if (tickRateManager.runsNormally())
        {
            blockEntityTicker.tick(world, pos, state, blockEntity);
        }
    }

    @Inject(method = "tick()V", at = @At("RETURN"))
    private void endTileEntitySection(CallbackInfo ci)
    {
        CarpetProfiler.end_current_entity_section(entitySection);
    }

}
