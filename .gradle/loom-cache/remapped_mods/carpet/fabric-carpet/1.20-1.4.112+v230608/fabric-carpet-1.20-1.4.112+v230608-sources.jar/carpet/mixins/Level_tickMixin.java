package carpet.mixins;

import carpet.fakes.LevelInterface;
import carpet.helpers.TickRateManager;
import carpet.utils.CarpetProfiler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_7165;

@Mixin(class_1937.class)
public abstract class Level_tickMixin implements LevelInterface
{
    @Shadow @Final public boolean isClientSide;
    @Shadow @Final protected class_7165 neighborUpdater;
    CarpetProfiler.ProfilerToken currentSection;
    CarpetProfiler.ProfilerToken entitySection;

    Map<class_1299<?>, class_1297> precookedMobs = new HashMap<>();

    @Override
    @Unique
    public class_7165 getNeighborUpdater() {
        return this.neighborUpdater;
    }

    @Override
    public Map<class_1299<?>, class_1297> getPrecookedMobs()
    {
        return precookedMobs;
    }

    @Inject(method = "tickBlockEntities", at = @At("HEAD"))
    private void startBlockEntities(CallbackInfo ci) {
        currentSection = CarpetProfiler.start_section((class_1937) (Object) this, "Block Entities", CarpetProfiler.TYPE.GENERAL);
    }

    @Inject(method = "tickBlockEntities", at = @At("TAIL"))
    private void endBlockEntities(CallbackInfo ci) {
        CarpetProfiler.end_current_section(currentSection);
    }

    @Inject(method = "guardEntityTick", at = @At("HEAD"), cancellable = true)
    private void startEntity(Consumer<class_1297> consumer_1, class_1297 e, CallbackInfo ci)
    {
        TickRateManager trm = tickRateManager();
        if (!trm.shouldEntityTick(e))
        {
            ci.cancel();
        }

        entitySection =  CarpetProfiler.start_entity_section((class_1937) (Object) this, e, CarpetProfiler.TYPE.ENTITY);
    }

    @Inject(method = "guardEntityTick", at = @At("TAIL"))
    private void endEntity(Consumer<class_1297> call, class_1297 e, CallbackInfo ci) {
        CarpetProfiler.end_current_entity_section(entitySection);
    }


}
