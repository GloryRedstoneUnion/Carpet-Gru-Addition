package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3023;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3023.class)
public abstract class CloneCommands_fillUpdatesMixin
{
    @Redirect(method = "clone", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerLevel;blockUpdated(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V"
    ))
    private static void conditionalUpdating(class_3218 serverWorld, class_2338 blockPos_1, class_2248 block_1)
    {
        if (CarpetSettings.fillUpdates) serverWorld.method_8408(blockPos_1, block_1);
    }
}
