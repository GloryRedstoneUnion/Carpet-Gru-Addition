package carpet.helpers;

import carpet.fakes.CoralFeatureInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2230;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2972;
import net.minecraft.class_2977;
import net.minecraft.class_2978;
import net.minecraft.class_2979;
import net.minecraft.class_3111;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3620;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7924;

/**
 * Deduplicates logic for the different behaviors of the {@code renewableCoral} rule
 */
public interface FertilizableCoral extends class_2256 {
    /**
     * @return Whether the rule for this behavior is enabled
     */
    boolean isEnabled();

    @Override
    public default boolean method_9651(class_4538 world, class_2338 pos, class_2680 state, boolean var4)
    {
        return isEnabled()
                && state.method_11654(class_2230.field_9940)
                && world.method_8316(pos.method_10084()).method_15767(class_3486.field_15517);
    }

    @Override
    public default boolean method_9650(class_1937 world, class_5819 random, class_2338 pos, class_2680 state)
    {
        return random.method_43057() < 0.15D;
    }

    @Override
    public default void method_9652(class_3218 worldIn, class_5819 random, class_2338 pos, class_2680 blockUnder)
    {
        int variant = random.method_43048(3);
        class_2978 coral = switch (variant) {
            case 0 -> new class_2972(class_3111.field_24893);
            case 1 -> new class_2979(class_3111.field_24893);
            default -> new class_2977(class_3111.field_24893);
        };

        class_3620 color = blockUnder.method_26205(worldIn, pos);
        class_2680 properBlock = blockUnder;
        class_6885.class_6888<class_2248> coralBlocks = worldIn.method_30349().method_30530(class_7924.field_41254).method_40266(class_3481.field_15461).orElseThrow();
        for (class_6880<class_2248> block: coralBlocks)
        {
            properBlock = block.comp_349().method_9564();
            if (properBlock.method_26205(worldIn, pos) == color)
            {
                break;
            }
        }
        worldIn.method_8652(pos, class_2246.field_10382.method_9564(), class_2248.field_31035);

        if (!((CoralFeatureInterface)coral).growSpecific(worldIn, random, pos, properBlock))
        {
            worldIn.method_8652(pos, blockUnder, 3);
        }
        else
        {
            if (worldIn.field_9229.method_43048(10) == 0)
            {
                class_2338 randomPos = pos.method_10069(worldIn.field_9229.method_43048(16) - 8, worldIn.field_9229.method_43048(8), worldIn.field_9229.method_43048(16) - 8);
                if (coralBlocks.method_40241(worldIn.method_8320(randomPos).method_41520()))
                {
                    worldIn.method_8652(randomPos, class_2246.field_10562.method_9564(), class_2248.field_31036);
                }
            }
        }
    }
}
