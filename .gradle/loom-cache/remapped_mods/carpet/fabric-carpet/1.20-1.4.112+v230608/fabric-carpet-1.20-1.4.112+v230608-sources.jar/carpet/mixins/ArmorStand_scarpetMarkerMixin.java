package carpet.mixins;

import carpet.CarpetServer;
import carpet.script.api.Auxiliary;
import org.apache.commons.lang3.StringUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1937;

@Mixin(class_1531.class)
public abstract class ArmorStand_scarpetMarkerMixin extends class_1309
{
    protected ArmorStand_scarpetMarkerMixin(class_1299<? extends class_1309> entityType_1, class_1937 world_1)
    {
        super(entityType_1, world_1);
    }

    /**
     * Remove all markers that do not belong to any script host and not part of the global one when loaded
     * @param ci
     */
    @Inject(method = "readAdditionalSaveData", at = @At("HEAD"))
    private void checkScarpetMarkerUnloaded(CallbackInfo ci)
    {
        if (!method_37908().field_9236)
        {
            if (method_5752().contains(Auxiliary.MARKER_STRING))
            {
                String prefix = Auxiliary.MARKER_STRING+"_";
                Optional<String> owner = method_5752().stream().filter(s -> s.startsWith(prefix)).findFirst();
                if (owner.isPresent())
                {
                    String hostName = StringUtils.removeStart(owner.get(),prefix);
                    if (!hostName.isEmpty() && CarpetServer.scriptServer.getAppHostByName(hostName) == null)
                    {
                        method_31472();  //discard
                    }

                }
                else
                {
                    method_31472(); // discard
                }
            }
        }
    }
}
