package carpet.fakes;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface RedstoneWireBlockInterface {
    class_2680 updateLogicPublic(class_1937 world_1, class_2338 blockPos_1, class_2680 blockState_1);
    void setWiresGivePower(boolean wiresGivePower);
    boolean getWiresGivePower();
}
