package carpet.fakes;

import net.minecraft.class_2586;

public interface PistonBlockEntityInterface
{
    void setCarriedBlockEntity(class_2586 blockEntity);
    class_2586 getCarriedBlockEntity();
    void setRenderCarriedBlockEntity(boolean b);
    boolean getRenderCarriedBlockEntity();
    boolean isRenderModeSet();
}
