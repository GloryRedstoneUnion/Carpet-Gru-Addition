package carpet.mixins;

import carpet.fakes.AbstractContainerMenuInterface;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1718;
import net.minecraft.class_1726;
import net.minecraft.class_3916;
import net.minecraft.class_3917;
import net.minecraft.class_3971;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;


//classes that override onButtonClick
@Mixin({class_1718.class, class_3916.class, class_1726.class, class_3971.class})
public abstract class AbstractContainerMenuSubclasses_scarpetMixin extends class_1703 {
    protected AbstractContainerMenuSubclasses_scarpetMixin(class_3917<?> type, int syncId) {
        super(type, syncId);
    }

    @Inject(method = "clickMenuButton", at = @At("HEAD"), cancellable = true)
    private void buttonClickCallback(class_1657 player, int id, CallbackInfoReturnable<Boolean> cir) {
        if(((AbstractContainerMenuInterface) this).callButtonClickListener(id,player))
            cir.cancel();
    }
}
