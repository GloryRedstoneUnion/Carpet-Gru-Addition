package carpet.utils;

import carpet.fakes.ChunkTicketManagerInterface;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_3204;
import net.minecraft.class_3218;

public class SpawnChunks
{
    public static void changeSpawnSize(class_3218 overworld, int size)
    {
        class_1923 centerChunk = new class_1923(new class_2338(
                overworld.method_8401().method_215(),
                overworld.method_8401().method_144(),
                overworld.method_8401().method_166()
        ));
        class_3204 ticketManager = overworld.method_14178().field_17254.method_17263();
        ((ChunkTicketManagerInterface)ticketManager).changeSpawnChunks(centerChunk, size);
    }
}
