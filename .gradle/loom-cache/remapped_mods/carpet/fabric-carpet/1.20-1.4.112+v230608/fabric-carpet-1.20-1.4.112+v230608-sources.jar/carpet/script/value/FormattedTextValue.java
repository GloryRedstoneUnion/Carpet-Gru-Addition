package carpet.script.value;

import com.google.gson.JsonElement;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class FormattedTextValue extends StringValue
{
    class_2561 text;

    public FormattedTextValue(class_2561 text)
    {
        super(null);
        this.text = text;
    }

    public static Value combine(Value left, Value right)
    {
        class_5250 text;
        if (left instanceof final FormattedTextValue ftv)
        {
            text = ftv.getText().method_27661();
        }
        else
        {
            if (left.isNull())
            {
                return right;
            }
            text = class_2561.method_43470(left.getString());
        }

        if (right instanceof final FormattedTextValue ftv)
        {
            text.method_10852(ftv.getText().method_27661());
            return new FormattedTextValue(text);
        }
        if (right.isNull())
        {
            return left;
        }
        text.method_27693(right.getString());
        return new FormattedTextValue(text);
    }

    public static Value of(class_2561 text)
    {
        return text == null ? Value.NULL : new FormattedTextValue(text);
    }

    @Override
    public String getString()
    {
        return text.getString();
    }

    @Override
    public boolean getBoolean()
    {
        return !text.getString().isEmpty();
    }

    @Override
    public Value clone()
    {
        return new FormattedTextValue(text);
    }

    @Override
    public String getTypeString()
    {
        return "text";
    }

    public class_2561 getText()
    {
        return text;
    }

    @Override
    public class_2520 toTag(boolean force)
    {
        if (!force)
        {
            throw new NBTSerializableValue.IncompatibleTypeException(this);
        }
        return class_2519.method_23256(class_2561.class_2562.method_10867(text));
    }

    @Override
    public JsonElement toJson()
    {
        return class_2561.class_2562.method_10868(text);
    }

    @Override
    public Value add(Value o)
    {
        return combine(this, o);
    }

    public String serialize()
    {
        return class_2561.class_2562.method_10867(text);
    }

    public static FormattedTextValue deserialize(String serialized)
    {
        return new FormattedTextValue(class_2561.class_2562.method_10877(serialized));
    }

    public static class_2561 getTextByValue(Value value)
    {
        return (value instanceof final FormattedTextValue ftv) ? ftv.getText() : class_2561.method_43470(value.getString());
    }

}
