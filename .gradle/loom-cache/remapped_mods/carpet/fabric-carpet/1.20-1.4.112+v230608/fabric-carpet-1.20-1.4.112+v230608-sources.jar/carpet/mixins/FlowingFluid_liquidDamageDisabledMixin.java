package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3609.class)
public class FlowingFluid_liquidDamageDisabledMixin
{
    @Inject(
            method = "canHoldFluid",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;blocksMotion()Z"
            ),
            cancellable = true
    )
    private void stopBreakingBlock(class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid, CallbackInfoReturnable<Boolean> cir)
    {
        if (CarpetSettings.liquidDamageDisabled)
        {
            cir.setReturnValue(state.method_26215() || state.method_27852(class_2246.field_10382) || state.method_27852(class_2246.field_10164));
        }
    }
}
