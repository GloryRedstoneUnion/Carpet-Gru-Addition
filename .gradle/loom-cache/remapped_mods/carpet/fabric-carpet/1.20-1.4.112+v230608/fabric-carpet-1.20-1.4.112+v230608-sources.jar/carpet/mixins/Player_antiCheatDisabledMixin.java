package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1770;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class Player_antiCheatDisabledMixin
{
    @Shadow public abstract class_1799 getItemBySlot(class_1304 equipmentSlot_1);

    @Shadow public abstract void startFallFlying();

    @Inject(method = "tryToStartFallFlying", at = @At("HEAD"), cancellable = true)
    private void allowDeploys(CallbackInfoReturnable<Boolean> cir)
    {
        if (CarpetSettings.antiCheatDisabled && (Object)this instanceof class_3222 sp && sp.method_5682().method_3816())
        {
            class_1799 itemStack_1 = getItemBySlot(class_1304.field_6174);
            if (itemStack_1.method_7909() == class_1802.field_8833 && class_1770.method_7804(itemStack_1)) {
                startFallFlying();
                cir.setReturnValue(true);
            }
        }
    }
}
