package carpet.utils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1379;
import net.minecraft.class_1590;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5532;
import net.minecraft.class_7924;
import carpet.script.utils.Colors;

public class BlockInfo
{
    public static List<class_2561> blockInfo(class_2338 pos, class_3218 world)
    {
        class_2680 state = world.method_8320(pos);
        class_2248 block = state.method_26204();
        String metastring = "";
        final class_2378<class_2248> blocks = world.method_30349().method_30530(class_7924.field_41254);
        for (net.minecraft.class_2769<?> iproperty : state.method_28501())
        {
            metastring += ", "+iproperty.method_11899() + '='+state.method_11654(iproperty);
        }
        List<class_2561> lst = new ArrayList<>();
        lst.add(Messenger.s(""));
        lst.add(Messenger.s("====================================="));
        lst.add(Messenger.s(String.format("Block info for %s%s (id %d%s):", blocks.method_10221(block),metastring, blocks.method_10206(block), metastring )));
        lst.add(Messenger.s(String.format(" - Map colour: %s", Colors.mapColourName.get(state.method_26205(world, pos)))));
        lst.add(Messenger.s(String.format(" - Sound type: %s", Colors.soundName.get(block.method_9573(state)))));
        lst.add(Messenger.s(""));
        lst.add(Messenger.s(String.format(" - Full block: %s", state.method_26234(world, pos)))); //  isFullCube() )));
        lst.add(Messenger.s(String.format(" - Normal cube: %s", state.method_26212(world, pos)))); //isNormalCube()))); isSimpleFullBlock
        lst.add(Messenger.s(String.format(" - Is liquid: %s", state.method_27852(class_2246.field_10382) || state.method_27852(class_2246.field_10164))));
        lst.add(Messenger.s(""));
        lst.add(Messenger.s(String.format(" - Light in: %d, above: %d",
                Math.max(world.method_8314(class_1944.field_9282, pos),world.method_8314(class_1944.field_9284, pos)) ,
                Math.max(world.method_8314(class_1944.field_9282, pos.method_10084()),world.method_8314(class_1944.field_9284, pos.method_10084())))));
        lst.add(Messenger.s(String.format(" - Brightness in: %.2f, above: %.2f", world.method_22349(pos), world.method_22349(pos.method_10084()))));
        lst.add(Messenger.s(String.format(" - Is opaque: %s", state.method_51367() )));
        //lst.add(Messenger.s(String.format(" - Light opacity: %d", state.getOpacity(world,pos))));
        //lst.add(Messenger.s(String.format(" - Emitted light: %d", state.getLightValue())));
        //lst.add(Messenger.s(String.format(" - Picks neighbour light value: %s", state.useNeighborBrightness(world, pos))));
        lst.add(Messenger.s(""));
        lst.add(Messenger.s(String.format(" - Causes suffocation: %s", state.method_26228(world, pos)))); //canSuffocate
        lst.add(Messenger.s(String.format(" - Blocks movement on land: %s", !state.method_26171(world,pos, class_10.field_50))));
        lst.add(Messenger.s(String.format(" - Blocks movement in air: %s", !state.method_26171(world,pos, class_10.field_51))));
        lst.add(Messenger.s(String.format(" - Blocks movement in liquids: %s", !state.method_26171(world,pos, class_10.field_48))));
        lst.add(Messenger.s(String.format(" - Can burn: %s", state.method_50011())));
        lst.add(Messenger.s(String.format(" - Hardness: %.2f", state.method_26214(world, pos))));
        lst.add(Messenger.s(String.format(" - Blast resistance: %.2f", block.method_9520())));
        lst.add(Messenger.s(String.format(" - Ticks randomly: %s", block.method_9542(state))));
        lst.add(Messenger.s(""));
        lst.add(Messenger.s(String.format(" - Can provide power: %s", state.method_26219())));
        lst.add(Messenger.s(String.format(" - Strong power level: %d", world.method_49809(pos))));
        lst.add(Messenger.s(String.format(" - Redstone power level: %d", world.method_49804(pos))));
        lst.add(Messenger.s(""));
        lst.add(wander_chances(pos.method_10084(), world));

        return lst;
    }

    private static class_2561 wander_chances(class_2338 pos, class_3218 worldIn)
    {
        class_1314 creature = new class_1590(class_1299.field_6050, worldIn);
        creature.method_5943(worldIn, worldIn.method_8404(pos), class_3730.field_16459, null, null);
        creature.method_5725(pos, 0.0F, 0.0F);
        class_1379 wander = new class_1379(creature, 0.8D);
        int success = 0;
        for (int i=0; i<1000; i++)
        {

            class_243 vec = class_5532.method_31510(creature, 10, 7); // TargetFinder.findTarget(creature, 10, 7);
            if (vec == null)
            {
                continue;
            }
            success++;
        }
        long total_ticks = 0;
        for (int trie=0; trie<1000; trie++)
        {
            int i;
            for (i=1;i<30*20*60; i++) //*60 used to be 5 hours, limited to 30 mins
            {
                if (wander.method_6264())
                {
                    break;
                }
            }
            total_ticks += 3*i;
        }
        creature.method_31472(); // discarded // remove(Entity.RemovalReason.field_26999); // 2nd option - DISCARDED
        long total_time = (total_ticks)/1000/20;
        return Messenger.s(String.format(" - Wander chance above: %.1f%%\n - Average standby above: %s",
                (100.0F*success)/1000,
                ((total_time>5000)?"INFINITY":(total_time +" s"))
        ));
    }
}
