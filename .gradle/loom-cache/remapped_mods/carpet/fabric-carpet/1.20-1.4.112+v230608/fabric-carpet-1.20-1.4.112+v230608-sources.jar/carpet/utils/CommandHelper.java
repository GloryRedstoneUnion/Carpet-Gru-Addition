package carpet.utils;

import carpet.CarpetSettings;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import net.minecraft.class_3738;
import net.minecraft.server.MinecraftServer;

/**
 * A few helpful methods to work with settings and commands.
 * 
 * This is not any kind of API, but it's unlikely to change
 *
 */
public final class CommandHelper {
    private CommandHelper() {}
    /**
     * Notifies all players that the commands changed by resending the command tree.
     */
    public static void notifyPlayersCommandsChanged(MinecraftServer server)
    {
        if (server == null || server.method_3760() == null)
        {
            return;
        }
        server.method_18858(new class_3738(server.method_3780(), () ->
        {
            try {
                for (class_3222 player : server.method_3760().method_14571()) {
                    server.method_3734().method_9241(player);
                }
            }
            catch (NullPointerException e)
            {
                CarpetSettings.LOG.warn("Exception while refreshing commands, please report this to Carpet", e);
            }
        }));
    }
    
    /**
     * Whether the given source has enough permission level to run a command that requires the given commandLevel
     */
    public static boolean canUseCommand(class_2168 source, Object commandLevel)
    {
        if (commandLevel instanceof Boolean) return (Boolean) commandLevel;
        String commandLevelString = commandLevel.toString();
        return switch (commandLevelString)
        {
            case "true"  -> true;
            case "false" -> false;
            case "ops"   -> source.method_9259(2); // typical for other cheaty commands
            case "0", "1", "2", "3", "4" -> source.method_9259(Integer.parseInt(commandLevelString));
            default -> false;
        };
    }
}
