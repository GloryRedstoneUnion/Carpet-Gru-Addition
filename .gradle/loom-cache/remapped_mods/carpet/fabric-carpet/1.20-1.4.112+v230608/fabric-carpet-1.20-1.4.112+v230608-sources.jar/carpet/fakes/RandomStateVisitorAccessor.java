package carpet.fakes;

import net.minecraft.class_6910;

public interface RandomStateVisitorAccessor {
    class_6910.class_6915 getVisitor();
}
