package carpet.mixins;

import carpet.fakes.ServerLightingProviderInterface;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_2791;
import net.minecraft.class_2804;
import net.minecraft.class_2823;
import net.minecraft.class_3227;
import net.minecraft.class_3568;
import net.minecraft.class_4076;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_3227.class)
public abstract class ThreadedLevelLightEngine_scarpetMixin extends class_3568 implements ServerLightingProviderInterface
{
    //@Shadow public abstract void checkBlock(BlockPos pos);

    //@Shadow public abstract void setLightEnabled(final ChunkPos chunkPos, final boolean bl);

    //@Shadow public abstract void propagateLightSources(final ChunkPos chunkPos);

    public ThreadedLevelLightEngine_scarpetMixin(class_2823 chunkProvider, boolean hasBlockLight, boolean hasSkyLight)
    {
        super(chunkProvider, hasBlockLight, hasSkyLight);
    }

    @Override
    public void resetLight(class_2791 chunk, class_1923 pos)
    {
        //super.setRetainData(pos, false);
        //super.setLightEnabled(pos, false);
        //for (int x = chpos.x-1; x <= chpos.x+1; x++ )
        //    for (int z = chpos.z-1; z <= chpos.z+1; z++ )
            {
                //ChunkPos pos = new ChunkPos(x, z);
                int j;
                for(j = -1; j < 17; ++j) {                                                                 // skip some recomp
                    super.method_15558(class_1944.field_9282, class_4076.method_18681(pos, j), new class_2804());
                    super.method_15558(class_1944.field_9284, class_4076.method_18681(pos, j), new class_2804());
                }
                for(j = 0; j < 16; ++j) {
                    super.method_15551(class_4076.method_18681(pos, j), true);
                }

                method_15512(pos, true);

                method_51471(pos);
                //    chunk.getLights().forEach((blockPos) -> {
                //        super.onBlockEmissionIncrease(blockPos, chunk.getLightEmission(blockPos));
                //    });

            }




    }
}
