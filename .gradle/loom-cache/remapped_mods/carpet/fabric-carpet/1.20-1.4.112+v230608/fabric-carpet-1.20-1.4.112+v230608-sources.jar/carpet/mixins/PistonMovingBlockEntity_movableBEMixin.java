package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.BlockEntityInterface;
import carpet.fakes.PistonBlockEntityInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2669;
import net.minecraft.class_2680;
import carpet.fakes.LevelInterface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2669.class)
public abstract class PistonMovingBlockEntity_movableBEMixin extends class_2586 implements PistonBlockEntityInterface
{
    @Shadow
    private boolean isSourcePiston;
    @Shadow
    private class_2680 movedState;
    
    private class_2586 carriedBlockEntity;
    private boolean renderCarriedBlockEntity = false;
    private boolean renderSet = false;

    public PistonMovingBlockEntity_movableBEMixin(class_2591<?> blockEntityType, class_2338 blockPos, class_2680 blockState) {
        super(blockEntityType, blockPos, blockState);
    }


    /**
     * @author 2No2Name
     */
    public class_2586 getCarriedBlockEntity()
    {
        return carriedBlockEntity;
    }

    @Override
    public void method_31662(class_1937 world) {
        super.method_31662(world);
        if (carriedBlockEntity != null) carriedBlockEntity.method_31662(world);
    }

    public void setCarriedBlockEntity(class_2586 blockEntity)
    {
        this.carriedBlockEntity = blockEntity;
        if (this.carriedBlockEntity != null)
        {
            ((BlockEntityInterface)carriedBlockEntity).setCMPos(field_11867);
            // this might be little dangerous since pos is final for a hashing reason?
            if (field_11863 != null) carriedBlockEntity.method_31662(field_11863);
        }
        //    this.carriedBlockEntity.setPos(this.pos);
    }
    
    public boolean isRenderModeSet()
    {
        return renderSet;
    }
    
    public boolean getRenderCarriedBlockEntity()
    {
        return renderCarriedBlockEntity;
    }
    
    public void setRenderCarriedBlockEntity(boolean b)
    {
        renderCarriedBlockEntity = b;
        renderSet = true;
    }
    
    /**
     * @author 2No2Name
     */
    @Redirect(method = "tick", at = @At(value = "INVOKE",
              target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
    private static boolean movableTEsetBlockState0(
            class_1937 world, class_2338 blockPos_1, class_2680 blockAState_2, int int_1,
            class_1937 world2, class_2338 blockPos, class_2680 blockState, class_2669 pistonBlockEntity)
    {
        if (!CarpetSettings.movableBlockEntities)
            return world.method_8652(blockPos_1, blockAState_2, int_1);
        else
            return ((LevelInterface) (world)).setBlockStateWithBlockEntity(blockPos_1, blockAState_2, ((PistonBlockEntityInterface)pistonBlockEntity).getCarriedBlockEntity(), int_1);
    }
    
    @Redirect(method = "finalTick", at = @At(value = "INVOKE",
              target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
    private boolean movableTEsetBlockState1(class_1937 world, class_2338 blockPos_1, class_2680 blockState_2, int int_1)
    {
        if (!CarpetSettings.movableBlockEntities)
            return world.method_8652(blockPos_1, blockState_2, int_1);
        else
        {
            boolean ret = ((LevelInterface) (world)).setBlockStateWithBlockEntity(blockPos_1, blockState_2, this.carriedBlockEntity, int_1);
            this.carriedBlockEntity = null; //this will cancel the finishHandleBroken
            return ret;
        }
    }
    
    @Inject(method = "finalTick", at = @At(value = "RETURN"))
    private void finishHandleBroken(CallbackInfo cir)
    {
        //Handle TNT Explosions or other ways the moving Block is broken
        //Also /setblock will cause this to be called, and drop e.g. a moving chest's contents.
        // This is MC-40380 (BlockEntities that aren't Inventories drop stuff when setblock is called )
        if (CarpetSettings.movableBlockEntities && this.carriedBlockEntity != null && !this.field_11863.field_9236 && this.field_11863.method_8320(this.field_11867).method_26204() == class_2246.field_10124)
        {
            class_2680 blockState_2;
            if (this.isSourcePiston)
                blockState_2 = class_2246.field_10124.method_9564();
            else
                blockState_2 = class_2248.method_9510(this.movedState, this.field_11863, this.field_11867);
            ((LevelInterface) (this.field_11863)).setBlockStateWithBlockEntity(this.field_11867, blockState_2, this.carriedBlockEntity, 3);
            this.field_11863.method_8651(this.field_11867, false, null);
        }
    }
    
    @Inject(method = "load", at = @At(value = "TAIL"))
    private void onFromTag(class_2487 NbtCompound_1, CallbackInfo ci)
    {
        if (CarpetSettings.movableBlockEntities && NbtCompound_1.method_10573("carriedTileEntityCM", 10))
        {
            if (this.movedState.method_26204() instanceof class_2343)
                this.carriedBlockEntity = ((class_2343) (this.movedState.method_26204())).method_10123(field_11867, movedState);//   this.world);
            if (carriedBlockEntity != null) //Can actually be null, as BlockPistonMoving.createNewTileEntity(...) returns null
                this.carriedBlockEntity.method_11014(NbtCompound_1.method_10562("carriedTileEntityCM"));
            setCarriedBlockEntity(carriedBlockEntity);
        }
    }
    
    @Inject(method = "saveAdditional", at = @At(value = "RETURN", shift = At.Shift.BEFORE))
    private void onToTag(class_2487 NbtCompound_1, CallbackInfo ci)
    {
        if (CarpetSettings.movableBlockEntities && this.carriedBlockEntity != null)
        {
            //Leave name "carriedTileEntityCM" instead of "carriedBlockEntityCM" for upgrade compatibility with 1.13.2 movable TE
            NbtCompound_1.method_10566("carriedTileEntityCM", this.carriedBlockEntity.method_38244());
        }
    }
}
