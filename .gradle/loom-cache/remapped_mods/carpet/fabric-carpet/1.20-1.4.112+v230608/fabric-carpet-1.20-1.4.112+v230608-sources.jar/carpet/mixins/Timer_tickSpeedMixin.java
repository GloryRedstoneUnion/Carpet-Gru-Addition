package carpet.mixins;

import carpet.fakes.MinecraftInterface;
import carpet.helpers.TickRateManager;
import carpet.CarpetSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_317;

@Mixin(class_317.class)
public class Timer_tickSpeedMixin {
    @Redirect(method = "advanceTime", at = @At(
            value = "FIELD",
            target = "Lnet/minecraft/client/Timer;msPerTick:F"
    ))
    private float adjustTickSpeed(class_317 counter) {
        if (CarpetSettings.smoothClientAnimations)
        {
            Optional<TickRateManager> trm = ((MinecraftInterface)class_310.method_1551()).getTickRateManager();
            if (trm.isPresent() && trm.get().runsNormally())
            {
                return Math.max(50.0f, trm.get().mspt());
            }
        }
        return 50f;
    }
}