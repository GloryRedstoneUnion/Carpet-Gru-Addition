package carpet.mixins;

import carpet.fakes.AbstractContainerMenuInterface;
import net.minecraft.class_1729;
import net.minecraft.class_1860;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1729.class)
public class RecipeBookMenu_scarpetMixin {
    @Inject(method = "handlePlacement",at = @At("HEAD"), cancellable = true)
    private void selectRecipeCallback(boolean craftAll, class_1860<?> recipe, class_3222 player, CallbackInfo ci) {
        if(((AbstractContainerMenuInterface) this).callSelectRecipeListener(player,recipe,craftAll))
            ci.cancel();
    }
}
