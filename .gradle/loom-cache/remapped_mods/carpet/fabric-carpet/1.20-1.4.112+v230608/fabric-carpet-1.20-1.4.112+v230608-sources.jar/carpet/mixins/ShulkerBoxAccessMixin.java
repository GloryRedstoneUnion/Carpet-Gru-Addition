package carpet.mixins;
import net.minecraft.class_602;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(net.minecraft.class_834.class)
public interface ShulkerBoxAccessMixin {
    @Accessor("model")
    class_602 getModel();
}