package carpet.mixins;

import carpet.fakes.MinecraftClientInferface;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_310.class)
public class Minecraft_pausedShakeMixin implements MinecraftClientInferface
{
    @Shadow private float pausePartialTick;

    @Override
    public float getPausedTickDelta()
    {
        return pausePartialTick;
    }
}
