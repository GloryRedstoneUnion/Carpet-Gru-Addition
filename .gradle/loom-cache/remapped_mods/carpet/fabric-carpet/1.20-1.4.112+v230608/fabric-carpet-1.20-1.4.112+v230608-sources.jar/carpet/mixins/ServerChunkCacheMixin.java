package carpet.mixins;

import carpet.utils.SpawnReporter;
import org.apache.commons.lang3.tuple.Pair;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashMap;
import java.util.HashSet;
import net.minecraft.class_1311;
import net.minecraft.class_1937;
import net.minecraft.class_3204;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_5217;
import net.minecraft.class_5321;

@Mixin(class_3215.class)
public abstract class ServerChunkCacheMixin
{
    @Shadow @Final private class_3218 level;

    @Shadow @Final private class_3204 distanceManager;

    @Redirect(method = "tickChunks", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/DistanceManager;getNaturalSpawnChunkCount()I"
    ))
    //this runs once per world spawning cycle. Allows to grab mob counts and count spawn ticks
    private int setupTracking(class_3204 chunkTicketManager)
    {
        int j = chunkTicketManager.method_14052();
        class_5321<class_1937> dim = this.level.method_27983(); // getDimensionType;
        //((WorldInterface)world).getPrecookedMobs().clear(); not needed because mobs are compared with predefined BBs
        SpawnReporter.chunkCounts.put(dim, j);

        if (SpawnReporter.track_spawns > 0L)
        {
            //local spawns now need to be tracked globally cause each calll is just for chunk
            SpawnReporter.local_spawns = new HashMap<>();
            SpawnReporter.first_chunk_marker = new HashSet<>();
            for (class_1311 cat : class_1311.values())
            {
                Pair<class_5321<class_1937>, class_1311> key = Pair.of(dim, cat);
                SpawnReporter.overall_spawn_ticks.put(key,
                        SpawnReporter.overall_spawn_ticks.get(key)+
                        SpawnReporter.spawn_tries.get(cat));
            }
        }
        return j;
    }


    @Inject(method = "tickChunks", at = @At("RETURN"))
    private void onFinishSpawnWorldCycle(CallbackInfo ci)
    {
        class_5217 levelProperties_1 = this.level.method_8401(); // levelProperies class
        boolean boolean_3 = levelProperties_1.method_188() % 400L == 0L;
        if (SpawnReporter.track_spawns > 0L && SpawnReporter.local_spawns != null)
        {
            for (class_1311 cat: class_1311.values())
            {
                class_5321<class_1937> dim = level.method_27983(); // getDimensionType;
                Pair<class_5321<class_1937>, class_1311> key = Pair.of(dim, cat);
                int spawnTries = SpawnReporter.spawn_tries.get(cat);
                if (!SpawnReporter.local_spawns.containsKey(cat))
                {
                    if (!cat.method_6135() || boolean_3) // isAnimal
                    {
                        // fill mobcaps for that category so spawn got cancelled
                        SpawnReporter.spawn_ticks_full.put(key,
                                SpawnReporter.spawn_ticks_full.get(key)+ spawnTries);
                    }

                }
                else if (SpawnReporter.local_spawns.get(cat) > 0)
                {
                    // tick spawned mobs for that type
                    SpawnReporter.spawn_ticks_succ.put(key,
                        SpawnReporter.spawn_ticks_succ.get(key)+spawnTries);
                    SpawnReporter.spawn_ticks_spawns.put(key,
                        SpawnReporter.spawn_ticks_spawns.get(key)+
                        SpawnReporter.local_spawns.get(cat));
                        // this will be off comparing to 1.13 as that would succeed if
                        // ANY tries in that round were successful.
                        // there will be much more difficult to mix in
                        // considering spawn tries to remove, as with warp
                        // there is little need for them anyways.
                }
                else // spawn no mobs despite trying
                {
                    //tick didn's spawn mobs of that type
                    SpawnReporter.spawn_ticks_fail.put(key,
                        SpawnReporter.spawn_ticks_fail.get(key)+spawnTries);
                }
            }
        }
        SpawnReporter.local_spawns = null;
    }



}
