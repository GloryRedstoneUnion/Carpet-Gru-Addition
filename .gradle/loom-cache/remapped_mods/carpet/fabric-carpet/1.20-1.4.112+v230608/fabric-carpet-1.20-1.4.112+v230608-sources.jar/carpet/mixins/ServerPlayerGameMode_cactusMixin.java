package carpet.mixins;

import carpet.helpers.BlockRotator;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3225;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3225.class)
public class ServerPlayerGameMode_cactusMixin
{

    @Redirect(method = "useItemOn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/state/BlockState;use(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;"
    ))
    private class_1269 activateWithOptionalCactus(class_2680 blockState, class_1937 world_1, class_1657 playerEntity_1, class_1268 hand_1, class_3965 blockHitResult_1)
    {
        boolean flipped = BlockRotator.flipBlockWithCactus(blockState, world_1, playerEntity_1, hand_1, blockHitResult_1);
        if (flipped)
            return class_1269.field_5812;

        return blockState.method_26174(world_1, playerEntity_1, hand_1, blockHitResult_1);
    }
}
