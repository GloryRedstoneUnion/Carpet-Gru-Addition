package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2248;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_5543;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public abstract class BlockBehaviourBlockStateBase_mixin
{
    @Shadow public abstract class_2248 getBlock();

    @Inject(method = "getPistonPushReaction", at = @At("HEAD"), cancellable = true)
    private void onGetPistonPushReaction(CallbackInfoReturnable<class_3619> cir)
    {
        if (CarpetSettings.movableAmethyst && getBlock() instanceof class_5543)
        {
            cir.setReturnValue(class_3619.field_15974);
        }
    }
}
