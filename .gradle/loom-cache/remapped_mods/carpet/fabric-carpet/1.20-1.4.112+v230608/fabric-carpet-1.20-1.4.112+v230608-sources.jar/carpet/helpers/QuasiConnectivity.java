package carpet.helpers;

import carpet.CarpetSettings;
import net.minecraft.class_2338;
import net.minecraft.class_8235;

public class QuasiConnectivity {

    public static boolean hasQuasiSignal(class_8235 level, class_2338 pos) {
        for (int i = 1; i <= CarpetSettings.quasiConnectivity; i++) {
            class_2338 above = pos.method_10086(i);

            if (level.method_31606(above)) {
                break;
            }
            if (level.method_49803(above)) {
                return true;
            }
        }

        return false;
    }
}
