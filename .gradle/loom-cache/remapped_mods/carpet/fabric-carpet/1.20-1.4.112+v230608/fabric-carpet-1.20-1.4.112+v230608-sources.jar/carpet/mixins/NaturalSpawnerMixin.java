package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.LevelInterface;
import carpet.utils.SpawnReporter;
import org.apache.commons.lang3.tuple.Pair;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.class_1266;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1315;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_1948;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_5321;
import net.minecraft.class_5425;

@Mixin(class_1948.class)
public class NaturalSpawnerMixin
{
    @Shadow @Final private static int MAGIC_NUMBER;

    @Shadow @Final private static class_1311[] SPAWNING_CATEGORIES;

    @Redirect(method = "isValidSpawnPostitionForType",
            at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerLevel;noCollision(Lnet/minecraft/world/phys/AABB;)Z"
    ))
    private static boolean doesNotCollide(class_3218 world, class_238 bb)
    {
        //.doesNotCollide is VERY expensive. On the other side - most worlds are not made of trapdoors in
        // various configurations, but solid and 'passable' blocks, like air, water grass, etc.
        // checking if in the BB of the entity are only passable blocks is very cheap and covers most cases
        // in case something more complex happens - we default to full block collision check
        if (!CarpetSettings.lagFreeSpawning)
        {
            return world.method_18026(bb);
        }
        int minX = class_3532.method_15357(bb.field_1323);
        int minY = class_3532.method_15357(bb.field_1322);
        int minZ = class_3532.method_15357(bb.field_1321);
        int maxY = class_3532.method_15384(bb.field_1325)-1;
        class_2338.class_2339 blockpos = new class_2338.class_2339();
        if (bb.method_17939() <= 1) // small mobs
        {
            for (int y=minY; y <= maxY; y++)
            {
                blockpos.method_10103(minX,y,minZ);
                class_265 box = world.method_8320(blockpos).method_26220(world, blockpos);
                if (box != class_259.method_1073())
                {
                    if (box == class_259.method_1077())
                    {
                        return false;
                    }
                    else
                    {
                        return world.method_18026(bb);
                    }
                }
            }
            return true;
        }
        // this code is only applied for mobs larger than 1 block in footprint
        int maxX = class_3532.method_15384(bb.field_1320)-1;
        int maxZ = class_3532.method_15384(bb.field_1324)-1;
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++)
                for (int z = minZ; z <= maxZ; z++)
                {
                    blockpos.method_10103(x, y, z);
                    class_265 box = world.method_8320(blockpos).method_26220(world, blockpos);
                    if (box != class_259.method_1073())
                    {
                        if (box == class_259.method_1077())
                        {
                            return false;
                        }
                        else
                        {
                            return world.method_18026(bb);
                        }
                    }
                }
        int min_below = minY - 1;
        // we need to check blocks below for extended hitbox and in that case call
        // only applies to 'large mobs', slimes, spiders, magmacubes, ghasts, etc.
        for (int x = minX; x <= maxX; x++)
        {
            for (int z = minZ; z <= maxZ; z++)
            {
                blockpos.method_10103(x, min_below, z);
                class_2680 state = world.method_8320(blockpos);
                class_2248 block = state.method_26204();
                if (
                        state.method_26164(class_3481.field_16584) ||
                        state.method_26164(class_3481.field_15504) ||
                        ((block instanceof class_2349) && !state.method_11654(class_2349.field_11026))
                )
                {
                    if (x == minX || x == maxX || z == minZ || z == maxZ) return world.method_18026(bb);
                    return false;
                }
            }
        }
        return true;
    }

    @Redirect(method = "getMobForSpawn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/EntityType;create(Lnet/minecraft/world/level/Level;)Lnet/minecraft/world/entity/Entity;"
    ))
    private static class_1297 create(class_1299<?> entityType, class_1937 world_1)
    {
        if (CarpetSettings.lagFreeSpawning)
        {
            Map<class_1299<?>, class_1297> precookedMobs = ((LevelInterface)world_1).getPrecookedMobs();
            if (precookedMobs.containsKey(entityType))
                //this mob has been <init>'s but not used yet
                return precookedMobs.get(entityType);
            class_1297 e = entityType.method_5883(world_1);
            precookedMobs.put(entityType, e);
            return e;
        }
        return entityType.method_5883(world_1);
    }

    @Redirect(method = "spawnCategoryForPosition(Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/NaturalSpawner$SpawnPredicate;Lnet/minecraft/world/level/NaturalSpawner$AfterSpawnCallback;)V", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerLevel;addFreshEntityWithPassengers(Lnet/minecraft/world/entity/Entity;)V"
    ))
    private static void spawnEntity(class_3218 world, class_1297 entity_1,
                                    class_1311 group, class_3218 world2, class_2791 chunk, class_2338 pos, class_1948.class_5261 checker, class_1948.class_5259 runner)
    {
        if (CarpetSettings.lagFreeSpawning)
            // we used the mob - next time we will create a new one when needed
            ((LevelInterface) world).getPrecookedMobs().remove(entity_1.method_5864());

        if (SpawnReporter.track_spawns > 0L && SpawnReporter.local_spawns != null)
        {
            SpawnReporter.registerSpawn(
                    //world.method_27983(), // getDimensionType //dimension.getType(), // getDimensionType
                    (class_1308) entity_1,
                    group, //entity_1.getType().getSpawnGroup(),
                    entity_1.method_24515());
        }
        if (!SpawnReporter.mock_spawns)
            world.method_30771(entity_1);
            //world.spawnEntity(entity_1);
    }

    @Redirect(method = "spawnCategoryForPosition(Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/NaturalSpawner$SpawnPredicate;Lnet/minecraft/world/level/NaturalSpawner$AfterSpawnCallback;)V", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/Mob;finalizeSpawn(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/world/entity/MobSpawnType;Lnet/minecraft/world/entity/SpawnGroupData;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/entity/SpawnGroupData;"
    ))
    private static class_1315 spawnEntity(class_1308 mobEntity, class_5425 serverWorldAccess, class_1266 difficulty, class_3730 spawnReason, class_1315 entityData, class_2487 entityTag)
    {
        if (!SpawnReporter.mock_spawns) // WorldAccess
            return mobEntity.method_5943(serverWorldAccess, difficulty, spawnReason, entityData, entityTag);
        return null;
    }

    @Redirect(method = "spawnCategoryForPosition(Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/NaturalSpawner$SpawnPredicate;Lnet/minecraft/world/level/NaturalSpawner$AfterSpawnCallback;)V", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;distanceToSqr(DDD)D"
    ))
    private static double getSqDistanceTo(class_1657 playerEntity, double double_1, double double_2, double double_3,
                                          class_1311 entityCategory, class_3218 serverWorld, class_2791 chunk, class_2338 blockPos)
    {
        double distanceTo = playerEntity.method_5649(double_1, double_2, double_3);
        if (CarpetSettings.lagFreeSpawning && distanceTo > 16384.0D && entityCategory != class_1311.field_6294)
            return 0.0;
        return distanceTo;
    }



    ////

    @Redirect(method = "spawnForChunk", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/NaturalSpawner;spawnCategoryForChunk(Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/chunk/LevelChunk;Lnet/minecraft/world/level/NaturalSpawner$SpawnPredicate;Lnet/minecraft/world/level/NaturalSpawner$AfterSpawnCallback;)V"
    ))
    // inject our repeat of spawns if more spawn ticks per tick are chosen.
    private static void spawnMultipleTimes(class_1311 category, class_3218 world, class_2818 chunk, class_1948.class_5261 checker, class_1948.class_5259 runner)
    {
        for (int i = 0; i < SpawnReporter.spawn_tries.get(category); i++)
        {
            class_1948.method_8663(category, world, chunk, checker, runner);
        }
    }

    // shrug - why no inject, no idea. need to inject twice more. Will check with the names next week
/*
    @Redirect(method = "spawn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/SpawnHelper$Info;isBelowCap(Lnet/minecraft/entity/SpawnGroup;)Z"
    ))
    // allows to change mobcaps and captures each category try per dimension before it fails due to full mobcaps.
    private static boolean changeMobcaps(
            SpawnHelper.Info info, SpawnGroup entityCategory,
            ServerWorld serverWorld, WorldChunk chunk, SpawnHelper.Info info_outer, boolean spawnAnimals, boolean spawnMonsters, boolean shouldSpawnAnimals
    )
    {
        DimensionType dim = serverWorld.dimension.getType();
        int newCap = (int) ((double)entityCategory.getSpawnCap()*(Math.pow(2.0,(SpawnReporter.mobcap_exponent/4))));
        if (SpawnReporter.track_spawns > 0L)
        {
            int int_2 = SpawnReporter.chunkCounts.get(dim); // eligible chunks for spawning
            int int_3 = newCap * int_2 / CHUNK_AREA; //current spawning limits
            int mobCount = info.getCategoryToCount().getInt(entityCategory);

            if (SpawnReporter.track_spawns > 0L && !SpawnReporter.first_chunk_marker.contains(entityCategory))
            {
                SpawnReporter.first_chunk_marker.add(entityCategory);
                //first chunk with spawn eligibility for that category
                Pair key = Pair.of(dim, entityCategory);


                int spawnTries = SpawnReporter.spawn_tries.get(entityCategory);

                SpawnReporter.spawn_attempts.put(key,
                        SpawnReporter.spawn_attempts.get(key) + spawnTries);

                SpawnReporter.spawn_cap_count.put(key,
                        SpawnReporter.spawn_cap_count.get(key) + mobCount);
            }

            if (mobCount <= int_3 || SpawnReporter.mock_spawns)
            {
                //place 0 to indicate there were spawn attempts for a category
                //if (entityCategory != EntityCategory.CREATURE || world.getServer().getTicks() % 400 == 0)
                // this will only be called once every 400 ticks anyways
                SpawnReporter.local_spawns.putIfAbsent(entityCategory, 0L);

                //else
                //full mobcaps - and key in local_spawns will be missing
            }
        }
        return SpawnReporter.mock_spawns || info.getCategoryToCount().getInt(entityCategory) < newCap;
    }

*/
    //temporary mixin until naming gets fixed

    @Inject(method = "spawnForChunk", at = @At("HEAD"))
    // allows to change mobcaps and captures each category try per dimension before it fails due to full mobcaps.
    private static void checkSpawns(class_3218 world, class_2818 chunk, class_1948.class_5262 info,
                                    boolean spawnAnimals, boolean spawnMonsters, boolean shouldSpawnAnimals, CallbackInfo ci)
    {
        if (SpawnReporter.track_spawns > 0L)
        {
            class_1311[] var6 = SPAWNING_CATEGORIES;
            int var7 = var6.length;

            for(int var8 = 0; var8 < var7; ++var8) {
                class_1311 entityCategory = var6[var8];
                if ((spawnAnimals || !entityCategory.method_6136()) && (spawnMonsters || entityCategory.method_6136()) && (shouldSpawnAnimals || !entityCategory.method_6135()) )
                {
                    class_5321<class_1937> dim = world.method_27983(); // getDimensionType;
                    int newCap = entityCategory.method_6134();  //(int) ((double)entityCategory.getCapacity()*(Math.pow(2.0,(SpawnReporter.mobcap_exponent/4))));
                    int int_2 = SpawnReporter.chunkCounts.get(dim); // eligible chunks for spawning
                    int int_3 = newCap * int_2 / MAGIC_NUMBER; //current spawning limits
                    int mobCount = info.method_27830().getInt(entityCategory);

                    if (SpawnReporter.track_spawns > 0L && !SpawnReporter.first_chunk_marker.contains(entityCategory))
                    {
                        SpawnReporter.first_chunk_marker.add(entityCategory);
                        //first chunk with spawn eligibility for that category
                        Pair<class_5321<class_1937>, class_1311> key = Pair.of(dim, entityCategory);


                        int spawnTries = SpawnReporter.spawn_tries.get(entityCategory);

                        SpawnReporter.spawn_attempts.put(key,
                                SpawnReporter.spawn_attempts.get(key) + spawnTries);

                        SpawnReporter.spawn_cap_count.put(key,
                                SpawnReporter.spawn_cap_count.get(key) + mobCount);
                    }

                    if (mobCount <= int_3 || SpawnReporter.mock_spawns) //TODO this will not float with player based mobcaps
                    {
                        //place 0 to indicate there were spawn attempts for a category
                        //if (entityCategory != EntityCategory.CREATURE || world.getServer().getTicks() % 400 == 0)
                        // this will only be called once every 400 ticks anyways
                        SpawnReporter.local_spawns.putIfAbsent(entityCategory, 0L);

                        //else
                        //full mobcaps - and key in local_spawns will be missing
                    }
                }
            }
        }
    }

}
