package carpet.network;

import carpet.CarpetServer;
import carpet.CarpetSettings;
import carpet.script.utils.ShapesRenderer;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_746;

public class CarpetClient
{
    public static final int HI = 69;
    public static final int HELLO = 420;
    public static final int DATA = 1;
    public static ShapesRenderer shapes = null;

    private static class_746 clientPlayer = null;
    private static boolean isServerCarpet = false;
    public static String serverCarpetVersion;
    public static final class_2960 CARPET_CHANNEL = new class_2960("carpet:hello");

    public static void gameJoined(class_746 player)
    {
        clientPlayer = player;
    }

    public static void disconnect()
    {
        if (isServerCarpet) // multiplayer connection
        {
            isServerCarpet = false;
            clientPlayer = null;
            CarpetServer.onServerClosed(null);
            CarpetServer.onServerDoneClosing(null);
        }
        else // singleplayer disconnect
        {
            CarpetServer.clientPreClosing();
        }
    }

    public static void setCarpet()
    {
        isServerCarpet = true;
    }

    public static class_746 getPlayer()
    {
        return clientPlayer;
    }

    public static boolean isCarpet()
    {
        return isServerCarpet;
    }

    public static boolean sendClientCommand(String command)
    {
        if (!isServerCarpet && CarpetServer.minecraft_server == null) return false;
        ClientNetworkHandler.clientCommand(command);
        return true;
    }

    public static void onClientCommand(class_2520 t)
    {
        CarpetSettings.LOG.info("Server Response:");
        class_2487 tag = (class_2487)t;
        CarpetSettings.LOG.info(" - id: "+tag.method_10558("id"));
        CarpetSettings.LOG.info(" - code: "+tag.method_10550("code"));
        if (tag.method_10545("error")) CarpetSettings.LOG.warn(" - error: "+tag.method_10558("error"));
        if (tag.method_10545("output"))
        {
            class_2499 outputTag = (class_2499) tag.method_10580("output");
            for (int i = 0; i < outputTag.size(); i++)
                CarpetSettings.LOG.info(" - response: " + class_2561.class_2562.method_10877(outputTag.method_10608(i)).getString());
        }
    }
}
