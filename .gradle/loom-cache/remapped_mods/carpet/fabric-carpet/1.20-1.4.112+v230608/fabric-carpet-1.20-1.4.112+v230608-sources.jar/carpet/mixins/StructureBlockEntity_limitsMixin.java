package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2248;
import net.minecraft.class_2633;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(class_2633.class)
public abstract class StructureBlockEntity_limitsMixin
{
    @ModifyConstant(
            method = "load",
            constant = @Constant(intValue = class_2633.field_31365)
    )
    private int positiveLimit(int original) {
        return CarpetSettings.structureBlockLimit;
    }

    @ModifyConstant(
            method = "load",
            constant = @Constant(intValue = -class_2633.field_31365)
    )
    private int negativeLimit(int original) {
        return -CarpetSettings.structureBlockLimit;
    }

    @ModifyArg(
            method = "saveStructure(Z)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;fillFromWorld(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;ZLnet/minecraft/world/level/block/Block;)V"
            ),
            index = 4
    )
    private class_2248 ignoredBlock(class_2248 original) {
        return CarpetSettings.structureBlockIgnoredBlock;
    }
}
