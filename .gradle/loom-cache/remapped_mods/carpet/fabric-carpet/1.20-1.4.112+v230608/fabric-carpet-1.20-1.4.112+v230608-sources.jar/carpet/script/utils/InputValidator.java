package carpet.script.utils;

import carpet.script.exception.InternalExpressionException;

import java.util.Locale;
import net.minecraft.class_151;
import net.minecraft.class_2960;

public class InputValidator
{
    public static String validateSimpleString(String input, boolean strict)
    {
        String simplified = input.toLowerCase(Locale.ROOT).replaceAll("[^A-Za-z0-9+_]", "");
        if (simplified.isEmpty() || (strict && !simplified.equals(input)))
        {
            throw new InternalExpressionException("simple name can only contain numbers, letter and _");
        }
        return simplified;
    }

    public static class_2960 identifierOf(String string)
    {
        try
        {
            return new class_2960(string);
        }
        catch (class_151 iie)
        {
            throw new InternalExpressionException("Incorrect identifier format '" + string + "': " + iie.getMessage());
        }
    }

}
