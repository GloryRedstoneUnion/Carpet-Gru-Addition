package carpet.mixins;

import carpet.fakes.SimpleEntityLookupInterface;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1923;
import net.minecraft.class_5568;
import net.minecraft.class_5572;
import net.minecraft.class_5573;
import net.minecraft.class_5578;

@Mixin(class_5578.class)
public class LevelEntityGetterAdapter_scarpetMixin<T extends class_5568> implements SimpleEntityLookupInterface<T>
{

    @Shadow @Final private class_5573<T> sectionStorage;

    @Override
    public List<T> getChunkEntities(class_1923 chpos) {
        return this.sectionStorage.method_31782(chpos.method_8324()).flatMap(class_5572::method_31766).collect(Collectors.toList());
    }
}


