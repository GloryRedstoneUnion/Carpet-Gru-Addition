package carpet.mixins;

import carpet.fakes.MinecraftServerInterface;
import carpet.script.CarpetScriptServer;
import net.minecraft.class_156;
import net.minecraft.class_1937;
import net.minecraft.class_2991;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3324;
import net.minecraft.class_3485;
import net.minecraft.class_3738;
import net.minecraft.class_4093;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.function.BooleanSupplier;

import static carpet.script.CarpetEventServer.Event.ENDER_TICK;
import static carpet.script.CarpetEventServer.Event.NETHER_TICK;
import static carpet.script.CarpetEventServer.Event.TICK;

@Mixin(MinecraftServer.class)
public abstract class MinecraftServer_scarpetMixin extends class_4093<class_3738> implements MinecraftServerInterface
{
    private CarpetScriptServer scriptServer;

    public MinecraftServer_scarpetMixin(String string_1)
    {
        super(string_1);
    }

    @Shadow protected abstract void tickServer(BooleanSupplier booleanSupplier_1);

    @Shadow private long nextTickTime;

    @Shadow private long lastOverloadWarning;

    @Shadow public abstract boolean method_16075();

    @Shadow @Final protected class_32.class_5143 storageSource;

    @Shadow @Final private Map<class_5321<class_1937>, class_3218> levels;

    //@Shadow private ServerResources resources;

    @Shadow private MinecraftServer.class_6897 resources;

    @Shadow public abstract class_5455.class_6890 registryAccess();

    @Shadow public abstract class_3324 getPlayerList();

    @Shadow @Final private class_2991 functionManager;

    @Shadow @Final private class_3485 structureTemplateManager;

    @Override
    public void forceTick(BooleanSupplier isAhead)
    {
        nextTickTime = lastOverloadWarning = class_156.method_658();
        tickServer(isAhead);
        while(method_16075()) {Thread.yield();}
    }

    @Override
    public class_32.class_5143 getCMSession()
    {
        return storageSource;
    }

    @Override
    public Map<class_5321<class_1937>, class_3218> getCMWorlds()
    {
        return levels;
    }

    @Inject(method = "tickServer", at = @At(
            value = "CONSTANT",
            args = "stringValue=tallying"
    ))
    public void tickTasks(BooleanSupplier booleanSupplier_1, CallbackInfo ci)
    {
        if (!getTickRateManager().runsNormally())
        {
            return;
        }
        TICK.onTick((MinecraftServer) (Object) this);
        NETHER_TICK.onTick((MinecraftServer) (Object) this);
        ENDER_TICK.onTick((MinecraftServer) (Object) this);
    }

    @Override
    public void reloadAfterReload(class_5455 newRegs)
    {
        resources.comp_353().method_40421(newRegs);
        getPlayerList().method_14617();
        getPlayerList().method_14572();
        functionManager.method_29461(this.resources.comp_353().method_29465());
        structureTemplateManager.method_29300(this.resources.comp_352());
    }

    @Override
    public MinecraftServer.class_6897 getResourceManager()
    {
        return resources;
    }

    @Override
    public void addScriptServer(final CarpetScriptServer scriptServer)
    {
        this.scriptServer = scriptServer;
    }

    @Override
    public CarpetScriptServer getScriptServer()
    {
        return scriptServer;
    }
}
