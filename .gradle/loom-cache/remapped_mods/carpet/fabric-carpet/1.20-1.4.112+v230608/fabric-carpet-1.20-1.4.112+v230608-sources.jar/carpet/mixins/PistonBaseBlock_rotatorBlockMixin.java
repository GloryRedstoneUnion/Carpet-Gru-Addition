package carpet.mixins;

import carpet.fakes.PistonBlockInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2665;
import net.minecraft.class_8235;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2665.class)
public abstract class PistonBaseBlock_rotatorBlockMixin implements PistonBlockInterface
{
    @Shadow protected abstract boolean getNeighborSignal(class_8235 world_1, class_2338 blockPos_1, class_2350 direction_1);

    @Override
    public boolean publicShouldExtend(class_1937 world_1, class_2338 blockPos_1, class_2350 direction_1)
    {
        return getNeighborSignal(world_1, blockPos_1,direction_1);
    }
}
