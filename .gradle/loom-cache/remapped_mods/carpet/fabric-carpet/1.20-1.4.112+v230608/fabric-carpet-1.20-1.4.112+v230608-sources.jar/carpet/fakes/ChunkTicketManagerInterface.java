package carpet.fakes;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.class_1923;
import net.minecraft.class_3193;
import net.minecraft.class_3228;
import net.minecraft.class_4706;

public interface ChunkTicketManagerInterface
{
    void changeSpawnChunks(class_1923 pos, int distance);

    Long2ObjectOpenHashMap<class_4706<class_3228<?>>> getTicketsByPosition();

    void replaceHolder(class_3193 oldHolder, class_3193 newHolder);
}
