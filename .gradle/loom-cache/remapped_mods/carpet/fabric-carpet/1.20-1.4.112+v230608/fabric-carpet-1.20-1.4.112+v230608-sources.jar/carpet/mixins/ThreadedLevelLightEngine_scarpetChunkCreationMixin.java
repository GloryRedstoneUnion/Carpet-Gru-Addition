package carpet.mixins;

import java.util.concurrent.CompletableFuture;
import java.util.function.IntSupplier;
import net.minecraft.class_156;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2791;
import net.minecraft.class_2823;
import net.minecraft.class_3227;
import net.minecraft.class_3227.class_3901;
import net.minecraft.class_3568;
import net.minecraft.class_3898;
import net.minecraft.class_4076;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;

import carpet.fakes.Lighting_scarpetChunkCreationInterface;
import carpet.fakes.ServerLightingProviderInterface;
import carpet.fakes.ThreadedAnvilChunkStorageInterface;

@Mixin(class_3227.class)
public abstract class ThreadedLevelLightEngine_scarpetChunkCreationMixin extends class_3568 implements ServerLightingProviderInterface
{
    private ThreadedLevelLightEngine_scarpetChunkCreationMixin(final class_2823 chunkProvider, final boolean hasBlockLight, final boolean hasSkyLight)
    {
        super(chunkProvider, hasBlockLight, hasSkyLight);
    }

    @Shadow
    protected abstract void addTask(final int x, final int z, final IntSupplier completedLevelSupplier, final class_3901 stage, final Runnable task);

    @Shadow
    @Final
    private class_3898 chunkMap;

    @Override
    @Invoker("updateChunkStatus")
    public abstract void invokeUpdateChunkStatus(class_1923 pos);

    @Override
    public void removeLightData(final class_2791 chunk)
    {
        class_1923 pos = chunk.method_12004();
        chunk.method_12020(false);

        this.addTask(pos.field_9181, pos.field_9180, () -> 0, class_3227.class_3901.field_17261, class_156.method_18839(() -> {
                super.method_15512(pos, false);
                ((Lighting_scarpetChunkCreationInterface) this).removeLightData(class_4076.method_18693(class_4076.method_18685(pos.field_9181, 0, pos.field_9180)));
            },
            () -> "Remove light data " + pos
        ));
    }

    @Override
    public CompletableFuture<Void> relight(class_2791 chunk)
    {
        class_1923 pos = chunk.method_12004();

        this.addTask(pos.field_9181, pos.field_9180, () -> 0, class_3227.class_3901.field_17261, class_156.method_18839(() -> {
                super.method_51471(pos);
                int minY = chunk.method_31607();
                int maxY = chunk.method_31600();
                int minX = pos.method_8326();
                int minZ = pos.method_8328();
                class_2338.class_2339 poss = new class_2338.class_2339();
                for (int x = -1; x < 17; ++x)
                {
                    for (int z = -1; z < 17; ++z)
                    {
                        if (x > 0 && x < 16 && z > 0 && z < 16)
                        {// not really efficient way to do it, but hey, we have bigger problems with this
                            continue;
                        }
                        for (int y = minY; y < maxY; ++y)
                        {
                            poss.method_10103(x + minX, y, z + minZ);
                            super.method_15513(poss);
                        }
                    }
                }
            },
            () -> "Relight chunk " + pos
        ));

        return CompletableFuture.runAsync(
            class_156.method_18839(() -> {
                    chunk.method_12020(true);
                    ((ThreadedAnvilChunkStorageInterface) this.chunkMap).releaseRelightTicket(pos);
                },
                () -> "Release relight ticket " + pos
            ),
            runnable -> this.addTask(pos.field_9181, pos.field_9180, () -> 0, class_3227.class_3901.field_17262, runnable)
        );
    }
}
