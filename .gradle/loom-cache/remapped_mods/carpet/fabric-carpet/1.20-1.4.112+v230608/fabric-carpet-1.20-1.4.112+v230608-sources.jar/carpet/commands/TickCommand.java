package carpet.commands;

import carpet.CarpetSettings;
import carpet.fakes.MinecraftServerInterface;
import carpet.helpers.ServerTickRateManager;
import carpet.network.ServerNetworkHandler;
import carpet.utils.CarpetProfiler;
import carpet.utils.CommandHelper;
import carpet.utils.Messenger;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

import static com.mojang.brigadier.arguments.FloatArgumentType.floatArg;
import static com.mojang.brigadier.arguments.FloatArgumentType.getFloat;
import static com.mojang.brigadier.arguments.IntegerArgumentType.getInteger;
import static com.mojang.brigadier.arguments.IntegerArgumentType.integer;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2172.method_35510;

public class TickCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> literalargumentbuilder = method_9247("tick").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandTick)).
                then(method_9247("rate").
                        executes((c) -> queryTps(c.getSource())).
                        then(method_9244("rate", floatArg(0.1F, 500.0F)).
                                suggests( (c, b) -> method_9253(new String[]{"20.0"},b)).
                                executes((c) -> setTps(c.getSource(), getFloat(c, "rate"))))).
                then(method_9247("warp").
                        executes( (c)-> setWarp(c.getSource(), 0, null)).
                        then(method_9244("ticks", integer(0)).
                                suggests( (c, b) -> method_9253(new String[]{"3600","72000"},b)).
                                executes((c) -> setWarp(c.getSource(), getInteger(c,"ticks"), null)).
                                then(method_9244("tail command", greedyString()).
                                        executes( (c) -> setWarp(
                                                c.getSource(),
                                                getInteger(c,"ticks"),
                                                getString(c, "tail command")))))).
                then(method_9247("freeze").executes( (c)-> toggleFreeze(c.getSource(), false)).
                        then(method_9247("status").executes( (c) -> freezeStatus(c.getSource()))).
                        then(method_9247("deep").executes( (c) -> toggleFreeze(c.getSource(), true))).
                        then(method_9247("on").executes( (c) -> setFreeze(c.getSource(), false, true)).
                            then(method_9247("deep").executes( (c)-> setFreeze(c.getSource(), true, true)))).
                        then(method_9247("off").executes( (c) -> setFreeze(c.getSource(), false, false)))).
                then(method_9247("step").
                        executes((c) -> step(c.getSource(), 1)).
                        then(method_9244("ticks", integer(1,72000)).
                                suggests( (c, b) -> method_9253(new String[]{"20"},b)).
                                executes((c) -> step(c.getSource(), getInteger(c,"ticks"))))).
                then(method_9247("superHot").executes( (c)-> toggleSuperHot(c.getSource()))).
                then(method_9247("health").
                        executes( (c) -> healthReport(c.getSource(), 100)).
                        then(method_9244("ticks", integer(20,24000)).
                                executes( (c) -> healthReport(c.getSource(), getInteger(c, "ticks"))))).
                then(method_9247("entities").
                        executes((c) -> healthEntities(c.getSource(), 100)).
                        then(method_9244("ticks", integer(20,24000)).
                                executes((c) -> healthEntities(c.getSource(), getInteger(c, "ticks")))));


        dispatcher.register(literalargumentbuilder);
    }


    private static int setTps(class_2168 source, float tps)
    {
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();
        trm.setTickRate(tps, true);
        queryTps(source);
        return (int)tps;
    }

    private static int queryTps(class_2168 source)
    {
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();

        Messenger.m(source, "w Current tps is: ",String.format("wb %.1f", trm.tickrate()));
        return (int) trm.tickrate();
    }

    private static int setWarp(class_2168 source, int advance, String tail_command)
    {
        class_3222 player = source.method_44023(); // may be null
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();
        class_2561 message = trm.requestGameToWarpSpeed(player, advance, tail_command, source);
        source.method_9226(() -> message, false);
        return 1;
    }

    private static int freezeStatus(class_2168 source)
    {
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();
        if(trm.gameIsPaused())
        {
            Messenger.m(source, "gi Freeze Status: Game is "+(trm.deeplyFrozen()?"deeply ":"")+"frozen");
        }
        else
        {
            Messenger.m(source, "gi Freeze Status: Game runs normally");
        }
        return 1;
    }

    private static int setFreeze(class_2168 source, boolean isDeep, boolean freeze)
    {
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();
        trm.setFrozenState(freeze, isDeep);
        if (trm.gameIsPaused())
        {
            Messenger.m(source, "gi Game is "+(isDeep?"deeply ":"")+"frozen");
        }
        else
        {
            Messenger.m(source, "gi Game runs normally");
        }
        return 1;
    }

    private static int toggleFreeze(class_2168 source, boolean isDeep)
    {
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();
        return setFreeze(source, isDeep, !trm.gameIsPaused());
    }

    private static int step(class_2168 source, int advance)
    {
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();
        trm.stepGameIfPaused(advance);
        Messenger.m(source, "gi Stepping " + advance + " tick" + (advance != 1 ? "s" : ""));
        return 1;
    }

    private static int toggleSuperHot(class_2168 source)
    {
        ServerTickRateManager trm = ((MinecraftServerInterface)source.method_9211()).getTickRateManager();
        trm.setSuperHot(!trm.isSuperHot());
        ServerNetworkHandler.updateSuperHotStateToConnectedPlayers(source.method_9211());
        if (trm.isSuperHot())
        {
            Messenger.m(source, "gi Superhot enabled");
        }
        else
        {
            Messenger.m(source, "gi Superhot disabled");
        }
        return 1;
    }

    public static int healthReport(class_2168 source, int ticks)
    {
        CarpetProfiler.prepare_tick_report(source, ticks);
        return 1;
    }

    public static int healthEntities(class_2168 source, int ticks)
    {
        CarpetProfiler.prepare_entity_report(source, ticks);
        return 1;
    }

}
