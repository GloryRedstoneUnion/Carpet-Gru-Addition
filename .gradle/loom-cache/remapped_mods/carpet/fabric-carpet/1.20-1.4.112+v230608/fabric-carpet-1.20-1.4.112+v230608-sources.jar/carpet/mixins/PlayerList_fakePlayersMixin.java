package carpet.mixins;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_2487;
import net.minecraft.class_2535;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3324;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import carpet.patches.NetHandlerPlayServerFake;
import carpet.patches.EntityPlayerMPFake;

@Mixin(class_3324.class)
public abstract class PlayerList_fakePlayersMixin
{
    @Shadow
    @Final
    private MinecraftServer server;

    @Inject(method = "load", at = @At(value = "RETURN", shift = At.Shift.BEFORE))
    private void fixStartingPos(class_3222 serverPlayerEntity_1, CallbackInfoReturnable<class_2487> cir)
    {
        if (serverPlayerEntity_1 instanceof EntityPlayerMPFake)
        {
            ((EntityPlayerMPFake) serverPlayerEntity_1).fixStartingPosition.run();
        }
    }

    @Redirect(method = "placeNewPlayer", at = @At(value = "NEW", target = "net/minecraft/server/network/ServerGamePacketListenerImpl"))
    private class_3244 replaceNetworkHandler(MinecraftServer server, class_2535 clientConnection, class_3222 playerIn)
    {
        if (playerIn instanceof EntityPlayerMPFake fake)
        {
            return new NetHandlerPlayServerFake(this.server, clientConnection, fake);
        }
        else
        {
            return new class_3244(this.server, clientConnection, playerIn);
        }
    }

    @Redirect(method = "respawn", at = @At(value = "NEW", target = "net/minecraft/server/level/ServerPlayer"))
    public class_3222 makePlayerForRespawn(MinecraftServer minecraftServer, class_3218 serverLevel, GameProfile gameProfile, class_3222 serverPlayer, boolean bl)
    {
        if (serverPlayer instanceof EntityPlayerMPFake) {
            return EntityPlayerMPFake.respawnFake(minecraftServer, serverLevel, gameProfile);
        }
        return new class_3222(minecraftServer, serverLevel, gameProfile);
    }
}
