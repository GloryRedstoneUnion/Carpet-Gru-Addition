package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1266;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1506;
import net.minecraft.class_1538;
import net.minecraft.class_1928;
import net.minecraft.class_2338;
import net.minecraft.class_3138;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3138.class)
public class SummonCommand_lightningMixin
{
    @Redirect(method = "createEntity", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/Entity;blockPosition()Lnet/minecraft/core/BlockPos;"
    ))
    private static class_2338 addRiders(class_1297 entity)
    {
        // [CM] SummonNaturalLightning - if statement around
        if (CarpetSettings.summonNaturalLightning && entity instanceof class_1538 && !entity.method_5770().field_9236)
        {
            class_3218 world = (class_3218) entity.method_5770();
            class_2338 at = entity.method_24515();
            class_1266 localDifficulty_1 =  world.method_8404(at);
            boolean boolean_2 = world.method_8450().method_8355(class_1928.field_19390) && world.field_9229.method_43058() < (double)localDifficulty_1.method_5457() * 0.01D;
            if (boolean_2) {
                class_1506 skeletonHorseEntity_1 = class_1299.field_6075.method_5883(world);
                skeletonHorseEntity_1.method_6813(true);
                skeletonHorseEntity_1.method_5614(0);
                skeletonHorseEntity_1.method_5814(entity.method_23317(), entity.method_23318(), entity.method_23321());
                world.method_8649(skeletonHorseEntity_1);
            }
        }
        return entity.method_24515();
    }

}
