package carpet.mixins;

import carpet.fakes.ChunkHolderInterface;
import com.mojang.datafixers.util.Either;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReferenceArray;
import net.minecraft.class_1255;
import net.minecraft.class_1923;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2839;
import net.minecraft.class_2843;
import net.minecraft.class_3193;
import net.minecraft.class_3218;
import net.minecraft.class_7924;

@Mixin(class_3193.class)
public abstract class ChunkHolder_scarpetChunkCreationMixin implements ChunkHolderInterface
{
    @Shadow protected abstract void updateChunkToSave(CompletableFuture<? extends Either<? extends class_2791, class_3193.class_3724>> newChunkFuture, String type);

    @Shadow @Final private AtomicReferenceArray<CompletableFuture<Either<class_2791, class_3193.class_3724>>> futures;

    @Override
    public CompletableFuture<Either<class_2791, class_3193.class_3724>> setDefaultProtoChunk(class_1923 chpos, class_1255<Runnable> executor, class_3218 world)
    {
        int i = class_2806.field_12798.method_16559();
        CompletableFuture<Either<class_2791, class_3193.class_3724>> completableFuture2 = CompletableFuture.supplyAsync(
                () -> Either.left(new class_2839(chpos, class_2843.field_12950, world,  world.method_30349().method_30530(class_7924.field_41236), null)), // todo figure out what that does - maybe add an option to reset with blending enabled..?
                executor
        );
        updateChunkToSave(completableFuture2, "unfull"); // possible debug data
        futures.set(i, completableFuture2);
        return completableFuture2;
    }
}
