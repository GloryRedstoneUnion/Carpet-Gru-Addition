package carpet.mixins;

import carpet.fakes.ClientConnectionInterface;
import carpet.logging.logHelpers.PacketCounter;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_7648;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public abstract class Connection_packetCounterMixin implements ClientConnectionInterface
{
    // Add to the packet counter whenever a packet is received.
    @Inject(method = "channelRead0", at = @At("HEAD"))
    private void packetInCount(ChannelHandlerContext channelHandlerContext_1, class_2596<?> packet_1, CallbackInfo ci)
    {
        PacketCounter.totalIn++;
    }
    
    // Add to the packet counter whenever a packet is sent.
    @Inject(method = "sendPacket", at = @At("HEAD"))
    private void packetOutCount(class_2596<?> packet, @Nullable class_7648 packetSendListener, CallbackInfo ci)
    {
        PacketCounter.totalOut++;
    }

    @Override
    @Accessor //Compat with adventure-platform-fabric
    public abstract void setChannel(Channel channel);
}
