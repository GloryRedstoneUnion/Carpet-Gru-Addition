package carpet.mixins;

import carpet.CarpetServer;
import carpet.fakes.ServerGamePacketListenerImplInterface;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public class ServerGamePacketListenerImpl_coreMixin implements ServerGamePacketListenerImplInterface {
    @Shadow
    public class_3222 player;

    @Shadow @Final private class_2535 connection;

    @Inject(method = "onDisconnect", at = @At("HEAD"))
    private void onPlayerDisconnect(class_2561 reason, CallbackInfo ci) {
        CarpetServer.onPlayerLoggedOut(this.player, reason);
    }

    @Override
    public class_2535 getConnection() {
        return connection;
    }
}
