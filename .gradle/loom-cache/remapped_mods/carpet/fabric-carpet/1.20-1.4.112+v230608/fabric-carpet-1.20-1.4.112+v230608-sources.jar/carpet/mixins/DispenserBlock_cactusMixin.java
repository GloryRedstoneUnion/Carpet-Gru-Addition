package carpet.mixins;

import carpet.helpers.BlockRotator;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2315;
import net.minecraft.class_2357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2315.class)
public abstract class DispenserBlock_cactusMixin
{
    @Inject(method = "getDispenseMethod", at = @At("HEAD"), cancellable = true)
    private void registerCarpetBehaviors(class_1799 stack, CallbackInfoReturnable<class_2357> cir)
    {
        class_1792 item = stack.method_7909();
        if (item == class_1802.field_17520)
            cir.setReturnValue(new BlockRotator.CactusDispenserBehaviour());
    }
}
