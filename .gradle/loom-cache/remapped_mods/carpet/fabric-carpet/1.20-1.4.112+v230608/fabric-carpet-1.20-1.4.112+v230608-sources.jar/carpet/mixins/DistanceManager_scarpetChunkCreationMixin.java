package carpet.mixins;

import java.util.Set;
import net.minecraft.class_3193;
import net.minecraft.class_3204;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import carpet.fakes.ChunkTicketManagerInterface;

@Mixin(class_3204.class)
public abstract class DistanceManager_scarpetChunkCreationMixin implements ChunkTicketManagerInterface
{
    @Shadow
    @Final
    private Set<class_3193> chunksToUpdateFutures;

    @Override
    public void replaceHolder(final class_3193 oldHolder, final class_3193 newHolder)
    {
        this.chunksToUpdateFutures.remove(oldHolder);
        this.chunksToUpdateFutures.add(newHolder);
    }
}
