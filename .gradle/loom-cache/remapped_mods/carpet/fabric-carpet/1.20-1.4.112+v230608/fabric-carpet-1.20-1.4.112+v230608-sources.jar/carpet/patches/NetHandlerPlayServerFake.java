package carpet.patches;

import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_2596;
import net.minecraft.class_2709;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import java.util.Set;

public class NetHandlerPlayServerFake extends class_3244
{
    public NetHandlerPlayServerFake(MinecraftServer server, class_2535 cc, EntityPlayerMPFake playerIn)
    {
        super(server, cc, playerIn);
    }

    @Override
    public void method_14364(final class_2596<?> packetIn)
    {
    }

    @Override
    public void method_14367(class_2561 message)
    {
        if (message.method_10851() instanceof class_2588 text && (text.method_11022().equals("multiplayer.disconnect.idling") || text.method_11022().equals("multiplayer.disconnect.duplicate_login")))
        {
            ((EntityPlayerMPFake) field_14140).kill(message);
        }
    }

    @Override
    public void method_14360(double d, double e, double f, float g, float h, Set<class_2709> set)
    {
        super.method_14360(d, e, f, g, h, set);
        if (field_14140.method_51469().method_18470(field_14140.method_5667()) != null) {
            method_14372();
            field_14140.method_51469().method_14178().method_14096(field_14140);
        }
    }

}



