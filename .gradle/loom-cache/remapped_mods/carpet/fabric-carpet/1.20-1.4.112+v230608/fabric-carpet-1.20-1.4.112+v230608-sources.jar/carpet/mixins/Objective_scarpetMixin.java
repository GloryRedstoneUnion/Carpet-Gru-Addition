package carpet.mixins;

import net.minecraft.class_266;
import net.minecraft.class_274;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_266.class)
public interface Objective_scarpetMixin {
    @Mutable @Accessor("criteria")
    void setCriterion(class_274 criterion);
}
