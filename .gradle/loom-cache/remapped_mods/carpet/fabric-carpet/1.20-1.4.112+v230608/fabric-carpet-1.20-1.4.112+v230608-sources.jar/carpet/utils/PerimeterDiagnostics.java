package carpet.utils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1421;
import net.minecraft.class_1480;
import net.minecraft.class_1569;
import net.minecraft.class_1948;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3486;
import net.minecraft.class_3730;
import net.minecraft.class_5483;

public class PerimeterDiagnostics
{
    public static class Result
    {
        public int liquid;
        public int ground;
        public int specific;
        public List<class_2338> samples;
        Result()
        {
            samples = new ArrayList<>();
        }
    }
    private class_5483.class_1964 sle;
    private class_3218 worldServer;
    private class_1311 ctype;
    private class_1308 el;
    private PerimeterDiagnostics(class_3218 server, class_1311 ctype, class_1308 el)
    {
        this.sle = null;
        this.worldServer = server;
        this.ctype = ctype;
        this.el = el;
    }

    public static Result countSpots(class_3218 worldserver, class_2338 epos, class_1308 el)
    {
        class_2338 pos;
        //List<BlockPos> samples = new ArrayList<BlockPos>();
        //if (el != null) CarpetSettings.LOG.error(String.format("Got %s to check",el.toString()));
        int eY = epos.method_10264();
        int eX = epos.method_10263();
        int eZ = epos.method_10260();
        Result result = new Result();

        //int ground_spawns = 0;
        //int liquid_spawns = 0;
        //int specific_spawns = 0;
        boolean add_water = false;
        boolean add_ground = false;
        class_1311 ctype = null;

        if (el != null)
        {
            if (el instanceof class_1480)
            {
                add_water = true;
                ctype = class_1311.field_6300;
            }
            else if (el instanceof class_1296)
            {
                add_ground = true;
                ctype = class_1311.field_6294;
            }
            else if (el instanceof class_1569)
            {
                add_ground = true;
                ctype = class_1311.field_6302;
            }
            else if (el instanceof class_1421)
            {
                ctype = class_1311.field_6303;
            }
        }
        PerimeterDiagnostics diagnostic = new PerimeterDiagnostics(worldserver,ctype,el);
        class_1299<?> type = class_1299.field_6051;
        if (el != null) type = el.method_5864();
        int minY = worldserver.method_31607();
        int maxY = worldserver.method_31600();
        for (int x = -128; x <= 128; ++x)
        {
            for (int z = -128; z <= 128; ++z)
            {
                if (x*x + z*z > 128*128) // cut out a cyllinder first
                {
                    continue;
                }
                for (int y= minY; y < maxY; ++y)
                {
                    if ((Math.abs(y-eY)>128) )
                    {
                        continue;
                    }
                    int distsq = (x)*(x)+(eY-y)*(eY-y)+(z)*(z);
                    if (distsq > 128*128 || distsq < 24*24)
                    {
                        continue;
                    }
                    pos = new class_2338(eX+x, y, eZ+z);

                    class_2680 iblockstate = worldserver.method_8320(pos);
                    class_2680 iblockstate_down = worldserver.method_8320(pos.method_10074());
                    class_2680 iblockstate_up = worldserver.method_8320(pos.method_10084());

                    if ( iblockstate.method_26227().method_15767(class_3486.field_15517) && !iblockstate_up.method_26212(worldserver, pos)) // isSimpleFUllBLock
                    {
                        result.liquid++;
                        if (add_water && diagnostic.check_entity_spawn(pos))
                        {
                            result.specific++;
                            if (result.samples.size() < 10)
                            {
                                result.samples.add(pos);
                            }
                        }
                    }
                    else
                    {
                        if (iblockstate_down.method_26212(worldserver, pos)) // isSimpleFUllBLock
                        {
                            class_2248 block = iblockstate_down.method_26204();
                            boolean flag = block != class_2246.field_9987 && block != class_2246.field_10499;
                            if( flag && class_1948.method_8662(worldserver, pos, iblockstate, iblockstate.method_26227(), type) && class_1948.method_8662(worldserver, pos.method_10084(), iblockstate_up, iblockstate_up.method_26227(), type))
                            {
                                result.ground ++;
                                if (add_ground && diagnostic.check_entity_spawn(pos))
                                {
                                    result.specific++;
                                    if (result.samples.size() < 10)
                                    {
                                        result.samples.add(pos);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //ashMap<String,Integer> result= new HashMap<>();
        //result.put("Potential in-water spawning spaces", liquid_spawns);
        //result.put("Potential on-ground spawning spaces", ground_spawns);
        //if (el != null) result.put(String.format("%s spawning spaces",el.getDisplayName().getUnformattedText()),specific_spawns);
        return result;
    }


    private boolean check_entity_spawn(class_2338 pos)
    {
        if (sle == null || !worldServer.method_14178().method_12129().method_12113(worldServer.method_23753(pos), worldServer.method_27056(), ctype, pos).method_34994().contains(sle))
        {
            sle = null;
            for (class_5483.class_1964 sle: worldServer.method_14178().method_12129().method_12113(worldServer.method_23753(pos), worldServer.method_27056(), ctype, pos).method_34994())
            {
                if (el.method_5864() == sle.field_9389)
                {
                    this.sle = sle;
                    break;
                }
            }
            if (sle == null || !worldServer.method_14178().method_12129().method_12113(worldServer.method_23753(pos), worldServer.method_27056(), ctype, pos).method_34994().contains(sle))
            {
                return false;
            }
        }

        class_1317.class_1319  spt = class_1317.method_6159(sle.field_9389);

        if (class_1948.method_8660(spt, worldServer, pos, sle.field_9389))
        {
            el.method_5808(pos.method_10263() + 0.5F, pos.method_10264(), pos.method_10260()+0.5F, 0.0F, 0.0F);
            return el.method_5957(worldServer) && el.method_5979(worldServer, class_3730.field_16459) &&
                    class_1317.method_20638(el.method_5864(),(class_3218)el.method_5770(), class_3730.field_16459, el.method_24515(), el.method_5770().field_9229) &&
                    worldServer.method_17892(el); // check collision rules once they stop fiddling with them after 1.14.1
        }
        return false;
    }
}
