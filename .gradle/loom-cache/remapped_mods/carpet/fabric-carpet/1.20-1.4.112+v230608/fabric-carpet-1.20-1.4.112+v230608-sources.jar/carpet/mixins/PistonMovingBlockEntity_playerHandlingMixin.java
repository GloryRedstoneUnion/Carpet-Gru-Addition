package carpet.mixins;

import carpet.CarpetSettings;
import carpet.patches.EntityPlayerMPFake;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2669;
import net.minecraft.class_3619;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2669.class)
public abstract class PistonMovingBlockEntity_playerHandlingMixin
{
    @Inject(method = "moveEntityByPiston", at = @At("HEAD"), cancellable = true)
    private static void dontPushSpectators(class_2350 direction, class_1297 entity, double d, class_2350 direction2, CallbackInfo ci)
    {
        if (CarpetSettings.creativeNoClip && entity instanceof class_1657 && (((class_1657) entity).method_7337()) && ((class_1657) entity).method_31549().field_7479) ci.cancel();
    }

    @Redirect(method = "moveCollidedEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;setDeltaMovement(DDD)V"))
    private static void ignoreAccel(class_1297 entity, double x, double y, double z)
    {
        if (CarpetSettings.creativeNoClip && entity instanceof class_1657 && (((class_1657) entity).method_7337()) && ((class_1657) entity).method_31549().field_7479) return;
        entity.method_18800(x,y,z);
    }

    @Redirect(method = "moveCollidedEntities", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/Entity;getPistonPushReaction()Lnet/minecraft/world/level/material/PushReaction;"
    ))
    private static class_3619 moveFakePlayers(class_1297 entity,
        class_1937 world, class_2338 blockPos, float ff, class_2669 pistonBlockEntity)
    {
        if (entity instanceof EntityPlayerMPFake && pistonBlockEntity.method_11495().method_27852(class_2246.field_10030))
        {
            class_243 vec3d = entity.method_18798();
            double x = vec3d.field_1352;
            double y = vec3d.field_1351;
            double z = vec3d.field_1350;
            class_2350 direction = pistonBlockEntity.method_11506();
            switch (direction.method_10166()) {
                case field_11048 -> x = direction.method_10148();
                case field_11052 -> y = direction.method_10164();
                case field_11051 -> z = direction.method_10165();
            }

            entity.method_18800(x, y, z);
        }
        return entity.method_5657();
    }

}
