@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.external;

import javax.annotation.ParametersAreNonnullByDefault;