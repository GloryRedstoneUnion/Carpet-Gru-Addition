package carpet.mixins;

import carpet.CarpetSettings;
import carpet.helpers.InventoryHelper;
import carpet.fakes.ItemEntityInterface;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1542;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2480;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin extends class_1297 implements ItemEntityInterface
{
    @Shadow private int age;
    @Shadow private int pickupDelay;

    public ItemEntityMixin(class_1299<?> entityType_1, class_1937 world_1) {
        super(entityType_1, world_1);
    }

    @Override
    public void method_5800(class_3218 world, class_1538 lightning) {
        if (CarpetSettings.lightningKillsDropsFix) {
            if (this.age > 8) { //Only kill item if it's older than 8 ticks
                super.method_5800(world, lightning);
            }
        } else {
            super.method_5800(world, lightning);
        }
    }

    @Override
    public int getPickupDelayCM() {
        return this.pickupDelay;
    }

    @Inject(method="<init>(Lnet/minecraft/world/level/Level;DDDLnet/minecraft/world/item/ItemStack;)V", at = @At("RETURN"))
    private void removeEmptyShulkerBoxTags(class_1937 worldIn, double x, double y, double z, class_1799 stack, CallbackInfo ci)
    {
        if (CarpetSettings.shulkerBoxStackSize > 1
                && stack.method_7909() instanceof class_1747 bi
                && bi.method_7711() instanceof class_2480)
        {
            InventoryHelper.cleanUpShulkerBoxTag(stack);
        }
    }

    @Redirect(
            method = "isMergable()Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/item/ItemStack;getMaxStackSize()I"
            )
    )
    private int getItemStackMaxAmount(class_1799 stack) {
        if (CarpetSettings.shulkerBoxStackSize > 1 && stack.method_7909() instanceof class_1747 && ((class_1747)stack.method_7909()).method_7711() instanceof class_2480)
            return CarpetSettings.shulkerBoxStackSize;

        return stack.method_7914();
    }

    @Inject(
            method = "tryToMerge(Lnet/minecraft/world/entity/item/ItemEntity;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void tryStackShulkerBoxes(class_1542 other, CallbackInfo ci)
    {
        class_1542 self = (class_1542)(Object)this;
        class_1799 selfStack = self.method_6983();
        if (CarpetSettings.shulkerBoxStackSize == 1 || !(selfStack.method_7909() instanceof class_1747 bi) || !(bi.method_7711() instanceof class_2480)) {
            return;
        }

        class_1799 otherStack = other.method_6983();
        if (selfStack.method_7909() == otherStack.method_7909()
                && !InventoryHelper.shulkerBoxHasItems(selfStack)
                && !InventoryHelper.shulkerBoxHasItems(otherStack)
                && Objects.equals(selfStack.method_7969(), otherStack.method_7969()) // empty block entity tags are cleaned up when spawning
                && selfStack.method_7947() != CarpetSettings.shulkerBoxStackSize)
        {
            int amount = Math.min(otherStack.method_7947(), CarpetSettings.shulkerBoxStackSize - selfStack.method_7947());

            selfStack.method_7933(amount);
            self.method_6979(selfStack);

            this.pickupDelay = Math.max(((ItemEntityInterface)other).getPickupDelayCM(), this.pickupDelay);
            this.age = Math.min(other.method_6985(), this.age);

            otherStack.method_7934(amount);
            if (otherStack.method_7960())
            {
                other.method_31472();
            }
            else
            {
                other.method_6979(otherStack);
            }
            ci.cancel();
        }
    }
}
