package carpet.mixins;

import carpet.utils.WoolTool;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5815;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5815.class) // WoolCarpetBlock
public abstract class WoolCarpetBlock_placeMixin extends class_2248
{

    public WoolCarpetBlock_placeMixin(class_2251 block$Settings_1)
    {
        super(block$Settings_1);
    }

    public class_2680 method_9605(class_1750 context)
    {
        class_2680 state = super.method_9605(context);
        if (context.method_8036() != null && !context.method_8045().field_9236)
        { // getColor()
            WoolTool.carpetPlacedAction(((class_5815)(Object)this).method_33635(), context.method_8036(), context.method_8037(), (class_3218) context.method_8045());
        }
        return state;
    }
}
