package carpet.fakes;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1923;
import net.minecraft.class_3193;

public interface ThreadedAnvilChunkStorageInterface
{
    Map<String, Integer> regenerateChunkRegion(List<class_1923> requestedChunks);

    void relightChunk(class_1923 pos);

    void releaseRelightTicket(class_1923 pos);

    Iterable<class_3193> getChunksCM();
}
