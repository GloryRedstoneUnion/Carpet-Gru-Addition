package carpet.script.utils;

import carpet.script.external.Vanilla;
import carpet.script.value.ListValue;
import carpet.script.value.NumericValue;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import carpet.script.value.ValueConversions;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.BiFunction;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2975;
import net.minecraft.class_3218;
import net.minecraft.class_7924;

public class BiomeInfo
{
    public static final Map<String, BiFunction<class_3218, class_1959, Value>> biomeFeatures = new HashMap<>()
    {{
        put("tags", (w, b) -> ListValue.wrap(w.method_30349().method_30530(class_7924.field_41236).method_40272().filter(p -> p.getSecond().method_40239().anyMatch(h -> h.comp_349() == b)).map(p -> p.getFirst().comp_327()).map(ValueConversions::of)));
        put("temperature", (w, b) -> NumericValue.of(b.method_8712()));
        put("fog_color", (w, b) -> ValueConversions.ofRGB(b.method_24377().method_24387()));
        put("foliage_color", (w, b) -> ValueConversions.ofRGB(b.method_24377().method_30811().orElse(4764952))); // client Biome.getDefaultFoliageColor
        put("sky_color", (w, b) -> ValueConversions.ofRGB(b.method_24377().method_30810()));
        put("water_color", (w, b) -> ValueConversions.ofRGB(b.method_24377().method_24388()));
        put("water_fog_color", (w, b) -> ValueConversions.ofRGB(b.method_24377().method_24389()));
        put("humidity", (w, b) -> NumericValue.of(Vanilla.Biome_getClimateSettings(b).comp_846()));
        put("precipitation", (w, b) -> StringValue.of(b.method_48162(new class_2338(0, w.method_8615(), 0)).name().toLowerCase(Locale.ROOT)));
        put("features", (w, b) -> {
            class_2378<class_2975<?, ?>> registry = w.method_30349().method_30530(class_7924.field_41239);
            return ListValue.wrap(
                    b.method_30970().method_30983().stream().map(step ->
                            ListValue.wrap(step.method_40239().map(cfp ->
                                    ValueConversions.of(registry.method_10221(cfp.comp_349().comp_334().comp_349())))
                            )
                    )
            );
        });
    }};
}
