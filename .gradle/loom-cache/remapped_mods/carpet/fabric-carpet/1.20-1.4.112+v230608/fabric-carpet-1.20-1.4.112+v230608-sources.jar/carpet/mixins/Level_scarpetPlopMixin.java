package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1937;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1937.class)
public class Level_scarpetPlopMixin
{

    @Redirect(method = "getHeight", at = @At(
            value = "INVOKE",
            target = "net/minecraft/world/level/chunk/LevelChunk.getHeight(Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I"
    ))
    private int fixSampleHeightmap(class_2818 chunk, class_2902.class_2903 type, int x, int z)
    {
        if (CarpetSettings.skipGenerationChecks.get())
        {
            class_2902.class_2903 newType = type;
            if (type == class_2902.class_2903.field_13195) newType = class_2902.class_2903.field_13200;
            else if (type == class_2902.class_2903.field_13194) newType = class_2902.class_2903.field_13202;
            return chunk.method_12005(newType, x, z);
        }
        return chunk.method_12005(type, x, z);
    }
}

