package carpet.mixins;

import carpet.CarpetServer;
import carpet.network.CarpetClient;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;
import carpet.api.settings.SettingsManager;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPacketListener_clientCommandMixin
{
    @Shadow @Final private class_310 minecraft;

    @Inject(method = "sendCommand", at = @At("HEAD"))
    private void inspectMessage(String string, CallbackInfo ci)
    {
        if (string.startsWith("call "))
        {
            String command = string.substring(5);
            CarpetClient.sendClientCommand(command);
        }
        if (CarpetServer.minecraft_server == null && !CarpetClient.isCarpet() && minecraft.field_1724 != null)
        {
            class_746 playerSource = minecraft.field_1724;
            CarpetServer.settingsManager.inspectClientsideCommand(playerSource.method_5671(),  "/"+string);
            CarpetServer.extensions.forEach(e -> {
                SettingsManager sm = e.extensionSettingsManager();
                if (sm != null) sm.inspectClientsideCommand(playerSource.method_5671(), "/"+string);
            });
        }
    }
}
