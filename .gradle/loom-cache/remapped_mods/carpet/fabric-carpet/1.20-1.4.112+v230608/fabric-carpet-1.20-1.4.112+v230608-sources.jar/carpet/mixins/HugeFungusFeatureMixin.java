package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_4780;
import net.minecraft.class_4781;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

import static carpet.CarpetSettings.FungusGrowthMode.*;

@Mixin(class_4781.class)
public class HugeFungusFeatureMixin {
    @ModifyArgs(method = "place", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/levelgen/feature/HugeFungusFeature;placeStem(Lnet/minecraft/world/level/WorldGenLevel;Lnet/minecraft/util/RandomSource;Lnet/minecraft/world/level/levelgen/feature/HugeFungusConfiguration;Lnet/minecraft/core/BlockPos;IZ)V"))
    private void mixin(Args args) {
        boolean natural = !((class_4780) args.get(2)).field_22194;
        args.set(5, natural && ((boolean) args.get(5)) ||
            !natural && (CarpetSettings.thickFungusGrowth == ALL ||
            CarpetSettings.thickFungusGrowth == RANDOM && ((class_5819) args.get(1)).method_43057() < 0.06F)
        );
    }
}
