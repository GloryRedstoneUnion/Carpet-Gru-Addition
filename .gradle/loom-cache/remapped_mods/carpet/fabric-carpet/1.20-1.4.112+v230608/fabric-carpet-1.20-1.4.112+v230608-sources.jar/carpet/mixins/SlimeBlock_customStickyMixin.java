package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;

import carpet.fakes.BlockBehaviourInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2490;
import net.minecraft.class_2680;

@Mixin(class_2490.class)
public class SlimeBlock_customStickyMixin implements BlockBehaviourInterface {

    @Override
    public boolean isSticky(class_2680 state) {
        return true;
    }

    @Override
    public boolean isStickyToNeighbor(class_1937 level, class_2338 pos, class_2680 state, class_2338 neighborPos, class_2680 neighborState, class_2350 dir, class_2350 moveDir) {
        return !neighborState.method_27852(class_2246.field_21211);
    }
}
