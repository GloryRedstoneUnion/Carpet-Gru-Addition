package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.LevelInterface;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2213;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2442;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import net.minecraft.class_7165;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2213.class)
public class BarrierBlock_updateSuppressionBlockMixin extends class_2248 {
    private boolean shouldPower = false;

    public BarrierBlock_updateSuppressionBlockMixin(class_2251 settings) { super(settings); }

    @Override
    public int method_9524(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return (shouldPower && direction == class_2350.field_11033) ? 15 : 0;
    }

    @Override
    public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 fromPos, boolean notify) {
        if (CarpetSettings.updateSuppressionBlock != -1) {
            if (fromPos.equals(pos.method_10084())) {
                class_2680 stateAbove = level.method_8320(fromPos);
                if (stateAbove.method_27852(class_2246.field_10546) && !stateAbove.method_11654(class_2442.field_11364)) {
                    level.method_39279(pos, this, 1);
                    class_7165 updater = ((LevelInterface)level).getNeighborUpdater();
                    if (updater instanceof CollectingNeighborUpdaterAccessor cnua)
                        cnua.setCount(cnua.getMaxChainedNeighborUpdates()-CarpetSettings.updateSuppressionBlock);
                }
            }
        }
        super.method_9612(state, level, pos, block, fromPos, notify);
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        class_2338 posAbove = pos.method_10084();
        class_2680 stateAbove = level.method_8320(posAbove);
        if (stateAbove.method_27852(class_2246.field_10546) && !stateAbove.method_11654(class_2442.field_11364)) {
            shouldPower = true;
            level.method_8652(posAbove, stateAbove.method_11657(class_2442.field_11364, true), class_2248.field_31028 | class_2248.field_31035);
            shouldPower = false;
        }
    }
}
