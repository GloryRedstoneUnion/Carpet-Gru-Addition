package carpet.fakes;

import net.minecraft.class_1959;

public interface BiomeInterface {
    class_1959.class_5482 getClimateSettings();
}
