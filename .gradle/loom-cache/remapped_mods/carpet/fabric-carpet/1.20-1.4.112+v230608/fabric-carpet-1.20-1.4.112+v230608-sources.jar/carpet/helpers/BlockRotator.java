package carpet.helpers;

import carpet.fakes.PistonBlockInterface;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2350;
import net.minecraft.class_2357;
import net.minecraft.class_2377;
import net.minecraft.class_2383;
import net.minecraft.class_2426;
import net.minecraft.class_243;
import net.minecraft.class_2465;
import net.minecraft.class_2470;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_2665;
import net.minecraft.class_2674;
import net.minecraft.class_2680;
import net.minecraft.class_2760;
import net.minecraft.class_2771;
import net.minecraft.class_2969;
import net.minecraft.class_3965;
import net.minecraft.class_5551;
import carpet.CarpetSettings;

public class BlockRotator
{
    public static boolean flipBlockWithCactus(class_2680 state, class_1937 world, class_1657 player, class_1268 hand, class_3965 hit)
    {
        if (!player.method_31549().field_7476 || !CarpetSettings.flippinCactus || !playerHoldsCactusMainhand(player))
        {
            return false;
        }
        CarpetSettings.impendingFillSkipUpdates.set(true);
        boolean retval = flipBlock(state, world, player, hand, hit);
        CarpetSettings.impendingFillSkipUpdates.set(false);
        return retval;
    }

    public static class_1799 dispenserRotate(class_2342 source, class_1799 stack)
    {
        class_2350 sourceFace = source.method_10120().method_11654(class_2315.field_10918);
        class_1937 world = source.method_10207();
        class_2338 blockpos = source.method_10122().method_10093(sourceFace); // offset
        class_2680 blockstate = world.method_8320(blockpos);
        class_2248 block = blockstate.method_26204();

        // Block rotation for blocks that can be placed in all 6 or 4 rotations.
        if (block instanceof class_2318 || block instanceof class_2315)
        {
            class_2350 face = blockstate.method_11654(class_2318.field_10927);
            if (block instanceof class_2665 && (
                    blockstate.method_11654(class_2665.field_12191)
                    || ( ((PistonBlockInterface)block).publicShouldExtend(world, blockpos, face) && (new class_2674(world, blockpos, face, true)).method_11537() )
                    )
            )
            {
                return stack;
            }

            class_2350 rotatedFace = face.method_35833(sourceFace.method_10166());
            if (sourceFace.method_10146() % 2 == 0 || rotatedFace == face)
            {   // Flip to make blocks always rotate clockwise relative to the dispenser
                // when index is equal to zero. when index is equal to zero the dispenser is in the opposite direction.
                rotatedFace = rotatedFace.method_10153();
            }
            world.method_8652(blockpos, blockstate.method_11657(class_2318.field_10927, rotatedFace), 3);
        }
        else if (block instanceof class_2383) // Block rotation for blocks that can be placed in only 4 horizontal rotations.
        {
            if (block instanceof class_2244)
                return stack;
            class_2350 face = blockstate.method_11654(class_2383.field_11177).method_35833(class_2350.class_2351.field_11052);

            if (sourceFace == class_2350.field_11033)
            { // same as above.
                face = face.method_10153();
            }
            world.method_8652(blockpos, blockstate.method_11657(class_2383.field_11177, face), 3);
        }
        else if (block == class_2246.field_10312)
        {
            class_2350 face = blockstate.method_11654(class_2377.field_11129);
            if (face != class_2350.field_11033)
            {
                face = face.method_35833(class_2350.class_2351.field_11052);
                world.method_8652(blockpos, blockstate.method_11657(class_2377.field_11129, face), 3);
            }
        }
        // Send block update to the block that just have been rotated.
        world.method_8492(blockpos, block, source.method_10122());

        return stack;
    }

    public static boolean flipBlock(class_2680 state, class_1937 world, class_1657 player, class_1268 hand, class_3965 hit)
    {
        class_2248 block = state.method_26204();
        class_2338 pos = hit.method_17777();
        class_243 hitVec = hit.method_17784().method_1023(pos.method_10263(), pos.method_10264(), pos.method_10260());
        class_2350 facing = hit.method_17780();
        class_2680 newState = null;
        if ((block instanceof class_2383 || block instanceof class_2241) && !(block instanceof class_2244))
        {
            newState = state.method_26186(class_2470.field_11463);
        }
        else if (block instanceof class_2426 || block instanceof class_5551)
        {
            newState = state.method_11657(class_2318.field_10927, state.method_11654(class_2318.field_10927).method_10153());
        }
        else if (block instanceof class_2315)
        {
            newState = state.method_11657(class_2315.field_10918, state.method_11654(class_2315.field_10918).method_10153());
        }
        else if (block instanceof class_2665)
        {
            if (!(state.method_11654(class_2665.field_12191)))
                newState = state.method_11657(class_2318.field_10927, state.method_11654(class_2318.field_10927).method_10153());
        }
        else if (block instanceof class_2482)
        {
            if (((class_2482) block).method_9526(state))
            {
                newState = state.method_11657(class_2482.field_11501, state.method_11654(class_2482.field_11501) == class_2771.field_12679 ? class_2771.field_12681 : class_2771.field_12679);
            }
        }
        else if (block instanceof class_2377)
        {
            if (state.method_11654(class_2377.field_11129) != class_2350.field_11033)
            {
                newState = state.method_11657(class_2377.field_11129, state.method_11654(class_2377.field_11129).method_10170());
            }
        }
        else if (block instanceof class_2510)
        {
            if ((facing == class_2350.field_11036 && hitVec.field_1351 == 1.0f) || (facing == class_2350.field_11033 && hitVec.field_1351 == 0.0f))
            {
                newState = state.method_11657(class_2510.field_11572, state.method_11654(class_2510.field_11572) == class_2760.field_12619 ? class_2760.field_12617 : class_2760.field_12619 );
            }
            else
            {
                boolean turnCounterClockwise = switch (facing) {
                    case field_11043 ->  (hitVec.field_1352 <= 0.5);
                    case field_11035 -> !(hitVec.field_1352 <= 0.5);
                    case field_11034  ->  (hitVec.field_1350 <= 0.5);
                    case field_11039  -> !(hitVec.field_1350 <= 0.5);
                    default    -> false;
                };
                newState = state.method_26186(turnCounterClockwise ? class_2470.field_11465 : class_2470.field_11463);
            }
        }
        else if (block instanceof class_2465)
        {
            newState = state.method_11657(class_2465.field_11459, switch (state.method_11654(class_2465.field_11459)) {
                case field_11048 -> class_2350.class_2351.field_11051;
                case field_11052 -> class_2350.class_2351.field_11048;
                case field_11051 -> class_2350.class_2351.field_11052;
            });
        }
        if (newState != null)
        {
            world.method_8652(pos, newState, class_2248.field_31028 | 1024); // no constant matching 1024 in Block, what does this do?
            world.method_16109(pos, state, newState);
            return true;
        }
        return false;
    }

    private static boolean playerHoldsCactusMainhand(class_1657 playerIn)
    {
        return playerIn.method_6047().method_7909() == class_1802.field_17520;
    }

    public static boolean flippinEligibility(class_1297 entity)
    {
        return CarpetSettings.flippinCactus && entity instanceof class_1657 p && p.method_6079().method_7909() == class_1802.field_17520;
    }

    public static class CactusDispenserBehaviour extends class_2969 implements class_2357
    {
        @Override
        protected class_1799 method_10135(class_2342 source, class_1799 stack)
        {
            if (CarpetSettings.rotatorBlock)
            {
                return BlockRotator.dispenserRotate(source, stack);
            }
            else
            {
                return super.method_10135(source, stack);
            }
        }
    }
}
