package carpet.mixins;

import carpet.CarpetSettings;
import carpet.helpers.InventoryHelper;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1703.class)
public class AbstractContainerMenu_stackableSBoxesMixin
{
    @Redirect(method = "doClick", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/inventory/Slot;getMaxStackSize(Lnet/minecraft/world/item/ItemStack;)I"
    ))
    private int getMaxCountForSboxesInScreenHander(class_1735 slot, class_1799 stack)
    {
        if (CarpetSettings.shulkerBoxStackSize > 1 &&
                stack.method_7909() instanceof class_1747 &&
                ((class_1747)stack.method_7909()).method_7711() instanceof class_2480 &&
                !InventoryHelper.shulkerBoxHasItems(stack)
        )
        {
            return CarpetSettings.shulkerBoxStackSize;
        }
        return slot.method_7676(stack);
    }
}
