package carpet.helpers;

import carpet.script.utils.ParticleParser;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import net.minecraft.class_7924;

public class ParticleDisplay
{
    public static void drawParticleLine(class_3222 player, class_243 from, class_243 to, String main, String accent, int count, double spread)
    {
        class_7225<class_2396<?>> lookup = player.method_37908().method_45448(class_7924.field_41210);
        class_2394 accentParticle = ParticleParser.getEffect(accent, lookup);
        class_2394 mainParticle = ParticleParser.getEffect(main, lookup);

        if (accentParticle != null) player.method_51469().method_14166(
                player,
                accentParticle,
                true,
                to.field_1352, to.field_1351, to.field_1350, count,
                spread, spread, spread, 0.0);

        double lineLengthSq = from.method_1025(to);
        if (lineLengthSq == 0) return;

        class_243 incvec = to.method_1020(from).method_1029();//    multiply(50/sqrt(lineLengthSq));
        for (class_243 delta = new class_243(0.0,0.0,0.0);
             delta.method_1027() < lineLengthSq;
             delta = delta.method_1019(incvec.method_1021(player.method_37908().field_9229.method_43057())))
        {
            player.method_51469().method_14166(
                    player,
                    mainParticle,
                    true,
                    delta.field_1352+from.field_1352, delta.field_1351+from.field_1351, delta.field_1350+from.field_1350, 1,
                    0.0, 0.0, 0.0, 0.0);
        }
    }

}
