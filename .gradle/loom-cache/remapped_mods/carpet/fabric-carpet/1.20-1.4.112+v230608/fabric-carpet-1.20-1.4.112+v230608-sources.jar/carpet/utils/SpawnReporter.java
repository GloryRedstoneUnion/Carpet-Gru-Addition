package carpet.utils;

import carpet.CarpetSettings;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1767;
import net.minecraft.class_1937;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3108;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_3701;
import net.minecraft.class_3730;
import net.minecraft.class_5138;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5575;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

import static net.minecraft.class_1311.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

public class SpawnReporter
{
    public static boolean mock_spawns = false;
    
    public static Long track_spawns = 0L;
    public static final HashMap<class_5321<class_1937>, Integer> chunkCounts = new HashMap<>();

    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Object2LongMap<class_1299<?>>> spawn_stats = new HashMap<>();
    public static double mobcap_exponent = 0.0D;
    
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Long> spawn_attempts = new HashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Long> overall_spawn_ticks = new HashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Long> spawn_ticks_full = new HashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Long> spawn_ticks_fail = new HashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Long> spawn_ticks_succ = new HashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Long> spawn_ticks_spawns = new HashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Long> spawn_cap_count = new HashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, EvictingQueue<Pair<class_1299<?>, class_2338>>> spawned_mobs = new HashMap<>();
    public static final HashMap<class_1311, Integer> spawn_tries = new HashMap<>();
    public static class_2338 lower_spawning_limit = null;
    public static class_2338 upper_spawning_limit = null;
    // in case game gets each thread for each world - these need to belong to workd.
    public static HashMap<class_1311, Long> local_spawns = null; // per world
    public static HashSet<class_1311> first_chunk_marker = null;

    static {
        reset_spawn_stats(null, true);
    }

    public static void registerSpawn(class_1308 mob, class_1311 cat, class_2338 pos)
    {
        if (lower_spawning_limit != null)
        {
            if (!( (lower_spawning_limit.method_10263() <= pos.method_10263() && pos.method_10263() <= upper_spawning_limit.method_10263()) &&
                 (lower_spawning_limit.method_10264() <= pos.method_10264() && pos.method_10264() <= upper_spawning_limit.method_10264()) && 
                 (lower_spawning_limit.method_10260() <= pos.method_10260() && pos.method_10260() <= upper_spawning_limit.method_10260())
               ))
            {
                return;
            }
        }
        Pair<class_5321<class_1937>, class_1311> key = Pair.of(mob.method_37908().method_27983(), cat);
        long count = spawn_stats.get(key).getOrDefault(mob.method_5864(), 0L);
        spawn_stats.get(key).put(mob.method_5864(), count + 1);
        spawned_mobs.get(key).put(Pair.of(mob.method_5864(), pos));
        if (!local_spawns.containsKey(cat))
        {
            CarpetSettings.LOG.error("Rogue spawn detected for category "+cat.method_6133()+" for mob "+mob.method_5864().method_5897().getString()+". If you see this message let carpet peeps know about it on github issues.");
            local_spawns.put(cat, 0L);
        }
        local_spawns.put(cat, local_spawns.get(cat)+1);
    }

    public static final int MAGIC_NUMBER = (int)Math.pow(17.0D, 2.0D);
    /*public static double currentMagicNumber()
    {
        return MAGIC_NUMBER / (Math.pow(2.0,(SpawnReporter.mobcap_exponent/4)));
    }*/

    public static List<class_2561> printMobcapsForDimension(class_3218 world, boolean multiline)
    {
        class_5321<class_1937> dim = world.method_27983();
        String name = dim.method_29177().method_12832();
        List<class_2561> lst = new ArrayList<>();
        if (multiline)
            lst.add(Messenger.s(String.format("Mobcaps for %s:",name)));
        class_1948.class_5262 lastSpawner = world.method_14178().method_27908();
        Object2IntMap<class_1311> dimCounts = lastSpawner.method_27830();
        int chunkcount = chunkCounts.getOrDefault(dim, -1);
        if (dimCounts == null || chunkcount < 0)
        {
            lst.add(Messenger.c("g   --UNAVAILABLE--"));
            return lst;
        }

        List<String> shortCodes = new ArrayList<>();
        for (class_1311 enumcreaturetype : class_1311.values())
        {
            int cur = dimCounts.getOrDefault(enumcreaturetype, -1);
            int max = (int)(chunkcount * ((double)enumcreaturetype.method_6134() / MAGIC_NUMBER)); // from ServerChunkManager.CHUNKS_ELIGIBLE_FOR_SPAWNING
            String color = Messenger.heatmap_color(cur, max);
            String mobColor = Messenger.creatureTypeColor(enumcreaturetype);
            if (multiline)
            {
                int rounds = spawn_tries.get(enumcreaturetype);
                lst.add(Messenger.c(String.format("w   %s: ", enumcreaturetype.method_6133()),
                        (cur < 0) ? "g -" : (color + " " + cur), "g  / ", mobColor + " " + max,
                        (rounds == 1) ? "w " : String.format("gi  (%d rounds/tick)", spawn_tries.get(enumcreaturetype))
                ));
            }
            else
            {
                shortCodes.add(color+" "+((cur<0)?"-":cur));
                shortCodes.add("g /");
                shortCodes.add(mobColor+" "+max);
                shortCodes.add("g ,");
            }
        }
        if (!multiline)
        {
            if (shortCodes.size()>0)
            {
                shortCodes.remove(shortCodes.size() - 1);
                lst.add(Messenger.c(shortCodes.toArray(new Object[0])));
            }
            else
            {
                lst.add(Messenger.c("g   --UNAVAILABLE--"));
            }

        }
        return lst;
    }
    
    public static List<class_2561> recent_spawns(class_1937 world, class_1311 creature_type)
    {
        List<class_2561> lst = new ArrayList<>();
        if ((track_spawns == 0L))
        {
            lst.add(Messenger.s("Spawn tracking not started"));
            return lst;
        }
        String type_code = creature_type.method_6133();
        
        lst.add(Messenger.s(String.format("Recent %s spawns:",type_code)));
        for (Pair<class_1299<?>, class_2338> pair : spawned_mobs.get(Pair.of(world.method_27983(), creature_type)).keySet()) // getDImTYpe
        {
            lst.add( Messenger.c(
                    "w  - ",
                    Messenger.tp("wb",pair.getRight()),
                    String.format("w : %s", pair.getLeft().method_5897().getString())
                    ));
        }
        
        if (lst.size()==1)
        {
            lst.add(Messenger.s(" - Nothing spawned yet, sorry."));
        }
        return lst;

    }
    
    public static List<class_2561> show_mobcaps(class_2338 pos, class_3218 worldIn)
    {
        class_1767 under = WoolTool.getWoolColorAtPosition(worldIn, pos.method_10074());
        if (under == null)
        {
            if (track_spawns > 0L)
            {
                return tracking_report(worldIn);
            }
            else
            {
                return printMobcapsForDimension(worldIn, true );
            }
        }
        class_1311 creature_type = get_type_code_from_wool_code(under);
        if (creature_type != null)
        {
            if (track_spawns > 0L)
            {
                return recent_spawns(worldIn, creature_type);
            }
            else
            {
                return printEntitiesByType(creature_type, worldIn, true);
                
            }
            
        }
        if (track_spawns > 0L)
        {
            return tracking_report(worldIn);
        }
        else
        {
            return printMobcapsForDimension(worldIn, true );
        }
        
    }
    
    public static class_1311 get_type_code_from_wool_code(class_1767 color)
    {
        return switch (color)
        {
            case field_7964   -> field_6302;
            case field_7942 -> field_6294;
            case field_7966  -> field_6300;
            case field_7957 -> field_6303;
            case field_7955  -> field_24460;
            default    -> null;
        };
    }
    
    public static List<class_2561> printEntitiesByType(class_1311 cat, class_1937 worldIn, boolean all) //Class<?> entityType)
    {
        List<class_2561> lst = new ArrayList<>();
        lst.add( Messenger.s(String.format("Loaded entities for %s class:", cat)));
        for (class_1297 entity : ((class_3218)worldIn).method_18198(class_5575.method_31795(class_1297.class), (e) -> e.method_5864().method_5891()==cat))
        {
            boolean persistent = entity instanceof class_1308 && ( ((class_1308) entity).method_5947() || ((class_1308) entity).method_17326());
            if (!all && persistent)
                continue;

            class_1299<?> type = entity.method_5864();
            class_2338 pos = entity.method_24515();
            lst.add( Messenger.c(
                    "w  - ",
                    Messenger.tp(persistent?"gb":"wb",pos),
                    String.format(persistent?"g : %s":"w : %s", type.method_5897().getString())
            ));

        }
        if (lst.size()==1)
        {
            lst.add(Messenger.s(" - Empty."));
        }
        return lst;
    }
    
    public static void initialize_mocking()
    {
        mock_spawns = true;
        
    }
    public static void stop_mocking()
    {
        mock_spawns = false;
    }
    public static void reset_spawn_stats(MinecraftServer server, boolean full)
    {

        spawn_stats.clear();
        spawned_mobs.clear();
        for (class_1311 enumcreaturetype : class_1311.values())
        {
            if (full)
            {
                spawn_tries.put(enumcreaturetype, 1);
            }
            if (server != null) for (class_5321<class_1937> dim : server.method_29435())
            {
                Pair<class_5321<class_1937>, class_1311> key = Pair.of(dim, enumcreaturetype);
                overall_spawn_ticks.put(key, 0L);
                spawn_attempts.put(key, 0L);
                spawn_ticks_full.put(key, 0L);
                spawn_ticks_fail.put(key, 0L);
                spawn_ticks_succ.put(key, 0L);
                spawn_ticks_spawns.put(key, 0L);
                spawn_cap_count.put(key, 0L);
                spawn_stats.put(key, new Object2LongOpenHashMap<>());
                spawned_mobs.put(key, new EvictingQueue<>());
            }
        }
        track_spawns = 0L;
    }

    private static String getWorldCode(class_5321<class_1937> world)
    {
        if (world == class_1937.field_25179) return "";
        return "("+world.method_29177().method_12832().toUpperCase(Locale.ROOT).replace("THE_","").charAt(0)+")";
    }
    
    public static List<class_2561> tracking_report(class_1937 worldIn)
    {

        List<class_2561> report = new ArrayList<>();
        if (track_spawns == 0L)
        {
            report.add(Messenger.c(
                    "w Spawn tracking disabled, type '",
                    "wi /spawn tracking start","/spawn tracking start",
                    "w ' to enable"));
            return report;
        }
        long duration = worldIn.method_8503().method_3780() - track_spawns;
        report.add(Messenger.c("bw --------------------"));
        String simulated = mock_spawns?"[SIMULATED] ":"";
        String location = (lower_spawning_limit != null)?String.format("[in (%d, %d, %d)x(%d, %d, %d)]",
                lower_spawning_limit.method_10263(),lower_spawning_limit.method_10264(),lower_spawning_limit.method_10260(),
                upper_spawning_limit.method_10263(),upper_spawning_limit.method_10264(),upper_spawning_limit.method_10260() ):"";
        report.add(Messenger.s(String.format("%sSpawn statistics %s: for %.1f min", simulated, location, (duration/72000.0)*60)));
        for (class_1311 enumcreaturetype : class_1311.values())
        {
            //String type_code = String.format("%s", enumcreaturetype);
            for (class_5321<class_1937> dim : worldIn.method_8503().method_29435()) //String world_code: new String[] {"", " (N)", " (E)"})
            {
                Pair<class_5321<class_1937>, class_1311> code = Pair.of(dim, enumcreaturetype);
                if (spawn_ticks_spawns.get(code) > 0L)
                {
                    double hours = overall_spawn_ticks.get(code)/72000.0;
                    report.add(Messenger.s(String.format(" > %s%s (%.1f min), %.1f m/t, %%{%.1fF %.1f- %.1f+}; %.2f s/att",
                        enumcreaturetype.method_6133().substring(0,3), getWorldCode(dim),
                        60*hours,
                        (1.0D*spawn_cap_count.get(code))/ spawn_attempts.get(code),
                        (100.0D*spawn_ticks_full.get(code))/ spawn_attempts.get(code),
                        (100.0D*spawn_ticks_fail.get(code))/ spawn_attempts.get(code),
                        (100.0D*spawn_ticks_succ.get(code))/ spawn_attempts.get(code),
                        (1.0D*spawn_ticks_spawns.get(code))/(spawn_ticks_fail.get(code)+spawn_ticks_succ.get(code))
                    )));
                    for (class_1299<?> type: spawn_stats.get(code).keySet())
                    {
                        report.add(Messenger.s(String.format("   - %s: %d spawns, %d per hour",
                                type.method_5897().getString(),
                                spawn_stats.get(code).getLong(type),
                                (72000 * spawn_stats.get(code).getLong(type)/duration ))));
                    }
                }
            }
        }
        return report;
    }

    

    public static void killEntity(class_1309 entity)
    {
        if (entity.method_5765())
        {
            entity.method_5854().method_31472();
        }
        if (entity.method_5782())
        {
            for (class_1297 e: entity.method_5685())
            {
                e.method_31472();
            }
        }
        if (entity instanceof class_3701)
        {
            for (class_1297 e: entity.method_5770().method_8335(entity, entity.method_5829()))
            {
                e.method_31472();
            }
        }
        entity.method_31472();
    }

    // yeeted from NaturalSpawner - temporary access fix
    private static List<class_5483.class_1964> getSpawnEntries(class_3218 serverLevel, class_5138 structureManager, class_2794 chunkGenerator, class_1311 mobCategory, class_2338 blockPos, @Nullable class_6880<class_1959> holder) {
        return class_1948.method_38091(blockPos, serverLevel, mobCategory, structureManager) ? class_3108.field_13705.method_34994() : chunkGenerator.method_12113(holder != null ? holder : serverLevel.method_23753(blockPos), structureManager, mobCategory, blockPos).method_34994();
    }

    public static List<class_2561> report(class_2338 pos, class_3218 worldIn)
    {
        List<class_2561> rep = new ArrayList<>();
        int x = pos.method_10263(); int y = pos.method_10264(); int z = pos.method_10260();
        class_2791 chunk = worldIn.method_22350(pos);
        int lc = chunk.method_12005(class_2902.class_2903.field_13202, x, z) + 1;
        String where = String.format((y >= lc) ? "%d blocks above it." : "%d blocks below it.",  class_3532.method_15382(y-lc));
        if (y == lc) where = "right at it.";
        rep.add(Messenger.s(String.format("Maximum spawn Y value for (%+d, %+d) is %d. You are "+where, x, z, lc )));
        rep.add(Messenger.s("Spawns:"));
        for (class_1311 enumcreaturetype : class_1311.values())
        {
            String type_code = String.format("%s", enumcreaturetype).substring(0, 3);
            List<class_5483.class_1964> lst = getSpawnEntries(worldIn, worldIn.method_27056(), worldIn.method_14178().method_12129(), enumcreaturetype, pos, worldIn.method_23753(pos) );//  ((ChunkGenerator)worldIn.getChunkManager().getChunkGenerator()).getEntitySpawnList(, worldIn.getStructureAccessor(), enumcreaturetype, pos);
            if (lst != null && !lst.isEmpty())
            {
                for (class_5483.class_1964 spawnEntry : lst)
                {
                    if (class_1317.method_6159(spawnEntry.field_9389)==null)
                        continue; // vanilla bug
                    boolean canspawn = class_1948.method_8660(class_1317.method_6159(spawnEntry.field_9389), worldIn, pos, spawnEntry.field_9389);
                    int will_spawn = -1;
                    boolean fits;
                    boolean fits1;
                    
                    class_1308 mob;
                    try
                    {
                        mob = (class_1308) spawnEntry.field_9389.method_5883(worldIn);
                    }
                    catch (Exception exception)
                    {
                        CarpetSettings.LOG.warn("Exception while creating mob for spawn reporter", exception);
                        return rep;
                    }
                    
                    boolean fits_true = false;
                    boolean fits_false = false;
                    
                    if (canspawn)
                    {
                        will_spawn = 0;
                        for (int attempt = 0; attempt < 50; ++attempt)
                        {
                            float f = x + 0.5F;
                            float f1 = z + 0.5F;
                            mob.method_5808(f, y, f1, worldIn.field_9229.method_43057() * 360.0F, 0.0F);
                            fits1 = worldIn.method_17892(mob);
                            class_1299<?> etype = mob.method_5864();

                            for (int i = 0; i < 20; ++i)
                            {
                                if (
                                        class_1317.method_20638(etype,worldIn, class_3730.field_16459, pos, worldIn.field_9229) &&
                                        class_1948.method_8660(class_1317.method_6159(etype), worldIn, pos, etype) &&
                                        mob.method_5979(worldIn, class_3730.field_16459)
                                    // && mob.canSpawn(worldIn) // entity collisions // mostly - except ocelots
                                )
                                {
                                    if (etype == class_1299.field_6081)
                                    {
                                        class_2680 blockState = worldIn.method_8320(pos.method_10074());
                                        if ((pos.method_10264() < worldIn.method_8615()) || !(blockState.method_27852(class_2246.field_10219) || blockState.method_26164(class_3481.field_15503))) {
                                           continue;
                                        }
                                    }
                                    will_spawn += 1;
                                }
                            }
                            mob.method_5943(worldIn, worldIn.method_8404(mob.method_24515()), class_3730.field_16459, null, null);
                            // the code invokes onInitialSpawn after getCanSpawHere
                            fits = fits1 && worldIn.method_17892(mob);
                            if (fits)
                            {
                                fits_true = true;
                            }
                            else
                            {
                                fits_false = true;
                            }
                            
                            killEntity(mob);
                            
                            try
                            {
                                mob = (class_1308) spawnEntry.field_9389.method_5883(worldIn);
                            }
                            catch (Exception exception)
                            {
                                CarpetSettings.LOG.warn("Exception while creating mob for spawn reporter", exception);
                                return rep;
                            }
                        }
                    }
                    
                    String creature_name = mob.method_5864().method_5897().getString();
                    String pack_size = String.format("%d", mob.method_5945());//String.format("%d-%d", animal.minGroupCount, animal.maxGroupCount);
                    int weight = spawnEntry.method_34979().method_34976();
                    if (canspawn)
                    {
                        String c = (fits_true && will_spawn>0)?"e":"gi";
                        rep.add(Messenger.c(
                                String.format("%s %s: %s (%d:%d-%d/%d), can: ",c,type_code,creature_name,weight,spawnEntry.field_9388, spawnEntry.field_9387,  mob.method_5945()),
                                "l YES",
                                c+" , fit: ",
                                ((fits_true && fits_false)?"y YES and NO":(fits_true?"l YES":"r NO")),
                                c+" , will: ",
                                ((will_spawn>0)?"l ":"r ")+Math.round((double)will_spawn)/10+"%"
                        ));
                    }
                    else
                    {
                        rep.add(Messenger.c(String.format("gi %s: %s (%d:%d-%d/%d), can: ",type_code,creature_name,weight,spawnEntry.field_9388, spawnEntry.field_9387, mob.method_5945()), "n NO"));
                    }
                    killEntity(mob);
                }
            }
        }
        return rep;
    }
}
