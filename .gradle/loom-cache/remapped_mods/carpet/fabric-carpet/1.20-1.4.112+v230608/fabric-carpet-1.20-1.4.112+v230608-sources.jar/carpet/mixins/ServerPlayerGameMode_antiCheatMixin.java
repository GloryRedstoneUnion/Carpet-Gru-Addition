package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = class_3225.class, priority = 69420) // not that important for carpet
public class ServerPlayerGameMode_antiCheatMixin
{
    // that shoudn't've been a constant at the first place
    // resolves problems with mobs using reach entity attributes.

    @Redirect(method = "handleBlockBreakAction", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;getEyePosition()Lnet/minecraft/world/phys/Vec3;"
    ))
    private class_243 getEyePos(class_3222 instance,
                           final class_2338 pos, final class_2846.class_2847 action, final class_2350 direction, final int maxBuildHeight, final int sequence)
    {
        if (CarpetSettings.antiCheatDisabled &&
                instance.method_33571().method_1025(class_243.method_24953(pos)) < 1024
        ) return class_243.method_24953(pos);
        return instance.method_33571();
    }
}
