package carpet.mixins;

import carpet.fakes.MinecraftServerInterface;
import carpet.helpers.ServerTickRateManager;
import carpet.patches.CopyProfilerResult;
import carpet.utils.CarpetProfiler;
import net.minecraft.class_156;
import net.minecraft.class_3218;
import net.minecraft.class_3688;
import net.minecraft.class_3695;
import net.minecraft.class_3696;
import net.minecraft.class_3738;
import net.minecraft.class_4093;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.BooleanSupplier;

@Mixin(value = MinecraftServer.class, priority = Integer.MAX_VALUE - 10)
public abstract class MinecraftServer_tickspeedMixin extends class_4093<class_3738> implements MinecraftServerInterface
{
    @Shadow private volatile boolean running;

    @Shadow private long nextTickTime;

    @Shadow @Final private static Logger LOGGER;

    @Shadow private class_3695 profiler;

    public MinecraftServer_tickspeedMixin(String name)
    {
        super(name);
    }

    @Shadow protected abstract void tickServer(BooleanSupplier booleanSupplier_1);

    @Shadow protected abstract boolean haveTime();

    @Shadow private long delayedTasksMaxNextTickTime;

    @Shadow private volatile boolean isReady;

    @Shadow private long lastOverloadWarning;

    @Shadow private boolean mayHaveDelayedTasks;

    @Shadow public abstract Iterable<class_3218> getAllLevels();

    @Shadow private int tickCount;

    @Shadow protected abstract void waitUntilNextTick();

    @Shadow protected abstract void startMetricsRecordingTick();

    @Shadow protected abstract void endMetricsRecordingTick();

    @Shadow private boolean debugCommandProfilerDelayStart;
    CarpetProfiler.ProfilerToken currentSection;

    private float carpetMsptAccum = 0.0f;

    private ServerTickRateManager serverTickRateManager;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(CallbackInfo ci)
    {
        serverTickRateManager = new ServerTickRateManager((MinecraftServer)(Object)this);
    }

    @Override
    public ServerTickRateManager getTickRateManager()
    {
        return serverTickRateManager;
    }

    /**
     * To ensure compatibility with other mods we should allow milliseconds
     */

    // Cancel a while statement
    @Redirect(method = "runServer", at = @At(value = "FIELD", target = "Lnet/minecraft/server/MinecraftServer;running:Z"))
    private boolean cancelRunLoop(MinecraftServer server)
    {
        return false;
    } // target run()

    // Replaced the above cancelled while statement with this one
    // could possibly just inject that mspt selection at the beginning of the loop, but then adding all mspt's to
    // replace 50L will be a hassle
    @Inject(method = "runServer", at = @At(value = "INVOKE", shift = At.Shift.AFTER,
            target = "Lnet/minecraft/server/MinecraftServer;buildServerStatus()Lnet/minecraft/network/protocol/status/ServerStatus;"))
    private void modifiedRunLoop(CallbackInfo ci)
    {
        while (this.running)
        {
            //long long_1 = Util.getMeasuringTimeMs() - this.timeReference;
            //CM deciding on tick speed
            if (CarpetProfiler.tick_health_requested != 0L)
            {
                CarpetProfiler.start_tick_profiling();
            }
            long msThisTick = 0L;
            long long_1 = 0L;
            float mspt = serverTickRateManager.mspt();
            if (serverTickRateManager.isInWarpSpeed() && serverTickRateManager.continueWarp())
            {
                //making sure server won't flop after the warp or if the warp is interrupted
                this.nextTickTime = this.lastOverloadWarning = class_156.method_658();
                carpetMsptAccum = mspt;
            }
            else
            {
                if (Math.abs(carpetMsptAccum - mspt) > 1.0f)
                {
                	// Tickrate changed. Ensure that we use the correct value.
                	carpetMsptAccum = mspt;
                }

                msThisTick = (long)carpetMsptAccum; // regular tick
                carpetMsptAccum += mspt - msThisTick;

                long_1 = class_156.method_658() - this.nextTickTime;
            }
            //end tick deciding
            //smoothed out delay to include mcpt component. With 50L gives defaults.
            if (long_1 > /*2000L*/1000L+20*mspt && this.nextTickTime - this.lastOverloadWarning >= /*15000L*/10000L+100*mspt)
            {
                long long_2 = (long)(long_1 / mspt);//50L;
                LOGGER.warn("Can't keep up! Is the server overloaded? Running {}ms or {} ticks behind", long_1, long_2);
                this.nextTickTime += (long)(long_2 * mspt);//50L;
                this.lastOverloadWarning = this.nextTickTime;
            }

            if (this.debugCommandProfilerDelayStart) {
                this.debugCommandProfilerDelayStart = false;
                this.profilerTimings = Pair.of(class_156.method_648(), tickCount);
                //this.field_33978 = new MinecraftServer.class_6414(Util.getMeasuringTimeNano(), this.ticks);
            }
            this.nextTickTime += msThisTick;//50L;
            //TickDurationMonitor tickDurationMonitor = TickDurationMonitor.create("Server");
            //this.startMonitor(tickDurationMonitor);
            this.startMetricsRecordingTick();
            this.profiler.method_15396("tick");
            this.tickServer(serverTickRateManager.isInWarpSpeed() ? ()->true : this::haveTime);
            this.profiler.method_15405("nextTickWait");
            if (serverTickRateManager.isInWarpSpeed()) // clearing all hanging tasks no matter what when warping
            {
                while(this.runEveryTask()) {Thread.yield();}
            }
            this.mayHaveDelayedTasks = true;
            this.delayedTasksMaxNextTickTime = Math.max(class_156.method_658() + /*50L*/ msThisTick, this.nextTickTime);
            // run all tasks (this will not do a lot when warping), but that's fine since we already run them
            this.waitUntilNextTick();
            this.profiler.method_15407();
            this.endMetricsRecordingTick();
            this.isReady = true;
        }

    }

    // just because profilerTimings class is public
    Pair<Long,Integer> profilerTimings = null;
    /// overworld around profiler timings
    @Inject(method = "isTimeProfilerRunning", at = @At("HEAD"), cancellable = true)
    public void isCMDebugRunning(CallbackInfoReturnable<Boolean> cir)
    {
        cir.setReturnValue(debugCommandProfilerDelayStart || profilerTimings != null);
    }
    @Inject(method = "stopTimeProfiler", at = @At("HEAD"), cancellable = true)
    public void stopCMDebug(CallbackInfoReturnable<class_3696> cir)
    {
        if (this.profilerTimings == null) {
            cir.setReturnValue(class_3688.field_16265);
        } else {
            class_3696 profileResult = new CopyProfilerResult(
                    profilerTimings.getRight(), profilerTimings.getLeft(),
                    this.tickCount, class_156.method_648()
            );
            this.profilerTimings = null;
            cir.setReturnValue(profileResult);
        }
    }


    private boolean runEveryTask() {
        if (super.method_16075()) {
            return true;
        } else {
            if (true) { // unconditionally this time
                for(class_3218 serverlevel : getAllLevels()) {
                    if (serverlevel.method_14178().method_19492()) {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    @Inject(method = "tickServer", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/MinecraftServer;saveEverything(ZZZ)Z", // save
            shift = At.Shift.BEFORE
    ))
    private void startAutosave(BooleanSupplier booleanSupplier_1, CallbackInfo ci)
    {
        currentSection = CarpetProfiler.start_section(null, "Autosave", CarpetProfiler.TYPE.GENERAL);
    }

    @Inject(method = "tickServer", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/MinecraftServer;saveEverything(ZZZ)Z",
            shift = At.Shift.AFTER
    ))
    private void finishAutosave(BooleanSupplier booleanSupplier_1, CallbackInfo ci)
    {
        CarpetProfiler.end_current_section(currentSection);
    }

    @Inject(method = "tickChildren", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/MinecraftServer;getConnection()Lnet/minecraft/server/network/ServerConnectionListener;",
            shift = At.Shift.BEFORE
    ))
    private void startNetwork(BooleanSupplier booleanSupplier_1, CallbackInfo ci)
    {
        currentSection = CarpetProfiler.start_section(null, "Network", CarpetProfiler.TYPE.GENERAL);
    }

    @Inject(method = "tickChildren", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/players/PlayerList;tick()V",
            shift = At.Shift.AFTER
    ))
    private void finishNetwork(BooleanSupplier booleanSupplier_1, CallbackInfo ci)
    {
        CarpetProfiler.end_current_section(currentSection);
    }

    @Inject(method = "waitUntilNextTick", at = @At("HEAD"))
    private void startAsync(CallbackInfo ci)
    {
        currentSection = CarpetProfiler.start_section(null, "Async Tasks", CarpetProfiler.TYPE.GENERAL);
    }
    @Inject(method = "waitUntilNextTick", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/MinecraftServer;managedBlock(Ljava/util/function/BooleanSupplier;)V",
            shift = At.Shift.BEFORE
    ))
    private void stopAsync(CallbackInfo ci)
    {
        if (CarpetProfiler.tick_health_requested != 0L)
        {
            CarpetProfiler.end_current_section(currentSection);
            CarpetProfiler.end_tick_profiling((MinecraftServer) (Object)this);
        }
    }


}
