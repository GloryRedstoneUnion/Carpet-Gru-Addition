package carpet.mixins;

import carpet.fakes.ServerWorldInterface;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.function.Supplier;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1538;
import net.minecraft.class_1923;
import net.minecraft.class_1927;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_2874;
import net.minecraft.class_3218;
import net.minecraft.class_3695;
import net.minecraft.class_5268;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5362;
import net.minecraft.class_5455;
import net.minecraft.class_5577;
import net.minecraft.class_5579;
import net.minecraft.class_6880;

import static carpet.script.CarpetEventServer.Event.EXPLOSION;
import static carpet.script.CarpetEventServer.Event.LIGHTNING;
import static carpet.script.CarpetEventServer.Event.CHUNK_UNLOADED;


@Mixin(class_3218.class)
public abstract class ServerLevel_scarpetMixin extends class_1937 implements ServerWorldInterface
{
    protected ServerLevel_scarpetMixin(class_5269 writableLevelData, class_5321<class_1937> resourceKey, class_5455 registryAccess, class_6880<class_2874> holder, Supplier<class_3695> supplier, boolean bl, boolean bl2, long l, int i)
    {
        super(writableLevelData, resourceKey, registryAccess, holder, supplier, bl, bl2, l, i);
    }

    @Inject(method = "tickChunk", locals = LocalCapture.CAPTURE_FAILHARD, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerLevel;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z",
            shift = At.Shift.BEFORE,
            ordinal = 1
    ))
    private void onNaturalLightinig(class_2818 chunk, int randomTickSpeed, CallbackInfo ci,
                                    //ChunkPos chunkPos, boolean bl, int i, int j, Profiler profiler, BlockPos blockPos, boolean bl2)
                                    class_1923 chunkPos, boolean bl, int i, int j, class_3695 profiler, class_2338 blockPos, class_1266 localDifficulty, boolean bl2, class_1538 lightningEntity)
    {
        if (LIGHTNING.isNeeded()) LIGHTNING.onWorldEventFlag((class_3218) (Object)this, blockPos, bl2?1:0);
    }

    private class_1927.class_4179 getCMDestroyType(final class_1928.class_4313<class_1928.class_4310> rule) {
        return method_8450().method_8355(rule) ? class_1927.class_4179.field_40879 : class_1927.class_4179.field_18687;
    }

    @Inject(method = "explode", at = @At("HEAD"))
    private void handleExplosion(/*@Nullable*/ class_1297 entity, /*@Nullable*/ class_1282 damageSource, /*@Nullable*/ class_5362 explosionBehavior, double d, double e, double f, float g, boolean bl, class_1937.class_7867 explosionInteraction, CallbackInfoReturnable<class_1927> cir)
    {
        if (EXPLOSION.isNeeded()) {
            class_1927.class_4179 var10000 = switch (explosionInteraction) {
                case field_40888 -> class_1927.class_4179.field_40878;
                case field_40889 -> this.getCMDestroyType(class_1928.field_40880);
                case field_40890 -> this.method_8450().method_8355(class_1928.field_19388) ? this.getCMDestroyType(class_1928.field_40881) : class_1927.class_4179.field_40878;
                case field_40891 -> this.getCMDestroyType(class_1928.field_40882);
                default -> throw new IncompatibleClassChangeError();
            };

            EXPLOSION.onExplosion((class_3218) (Object) this, entity, null, d, e, f, g, bl, null, null, var10000);
        }
    }

    @Inject(method = "unload", at = @At("HEAD"))
    private void handleChunkUnload(class_2818 levelChunk, CallbackInfo ci)
    {
        if (CHUNK_UNLOADED.isNeeded())
        {
            class_3218 level = (class_3218)((Object)this);
            CHUNK_UNLOADED.onChunkEvent(level, levelChunk.method_12004(), false);
        }
    }

    @Final
    @Shadow
    private class_5268 serverLevelData;
    @Shadow @Final private class_5579<class_1297> entityManager;

    @Override
    public class_5268 getWorldPropertiesCM(){
        return serverLevelData;
    }

    @Override
    public class_5577<class_1297> getEntityLookupCMPublic() {
        return entityManager.method_31841();
    }
}
