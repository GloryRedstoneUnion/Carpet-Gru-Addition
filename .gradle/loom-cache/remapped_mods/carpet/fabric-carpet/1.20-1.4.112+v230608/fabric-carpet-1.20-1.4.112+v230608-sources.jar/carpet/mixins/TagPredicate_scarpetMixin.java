package carpet.mixins;

import carpet.fakes.BlockPredicateInterface;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_6862;
import net.minecraft.class_6885;

@Mixin(targets = "net.minecraft.commands.arguments.blocks.BlockPredicateArgument$TagPredicate")
public class TagPredicate_scarpetMixin implements BlockPredicateInterface
{
    @Shadow @Final private class_6885<class_2248> tag;

    @Shadow @Final private Map<String, String> vagueProperties;

    @Shadow @Final /*@Nullable*/ private class_2487 nbt;

    @Override
    public class_2680 getCMBlockState()
    {
        return null;
    }

    @Override
    public class_6862<class_2248> getCMBlockTagKey()
    {
        // might be good to explose the holder set nature of it.
        return tag.method_40248().left().orElse(null);
    }

    @Override
    public Map<Value, Value> getCMProperties()
    {
        return vagueProperties.entrySet().stream().collect(Collectors.toMap(
                e -> new StringValue(e.getKey()),
                e -> new StringValue(e.getValue())
        ));
    }

    @Override
    public class_2487 getCMDataTag()
    {
        return nbt;
    }
}
