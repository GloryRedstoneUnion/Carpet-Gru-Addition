package carpet.logging.logHelpers;

import carpet.helpers.ParticleDisplay;
import carpet.logging.LoggerRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;

public class PathfindingVisualizer
{
    public static void slowPath(class_1297 entity, class_243 target, float miliseconds, boolean successful)
    {
        if (!LoggerRegistry.__pathfinding) return;
        LoggerRegistry.getLogger("pathfinding").log( (option, player)->
        {
            if (!(player instanceof class_3222))
                return null;
            int minDuration;
            try
            {
                minDuration = Integer.parseInt(option);
            }
            catch (NumberFormatException ignored)
            {
                return  null;
            }
            if (miliseconds < minDuration)
                return null;
            if (player.method_5858(entity) > 1000 && player.method_5707(target) > 1000)
                return null;
            if (minDuration < 1)
                minDuration = 1;

            String accent = successful ? "happy_villager" : "angry_villager";
            String color = (miliseconds/minDuration < 2)? "dust 1 1 0 1" : ((miliseconds/minDuration < 4)?"dust 1 0.5 0 1":"dust 1 0 0 1");
            ParticleDisplay.drawParticleLine((class_3222) player, entity.method_19538(), target, color, accent, 5, 0.5);
            return null;
        });
    }
}
