package carpet.script.value;

import javax.annotation.Nullable;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class StringValue extends Value
{
    public static Value EMPTY = StringValue.of("");

    private final String str;

    @Override
    public String getString()
    {
        return str;
    }

    @Override
    public boolean getBoolean()
    {
        return str != null && !str.isEmpty();
    }

    @Override
    public Value clone()
    {
        return new StringValue(str);
    }

    public StringValue(String str)
    {
        this.str = str;
    }

    public static Value of(@Nullable String value)
    {
        return value == null ? Value.NULL : new StringValue(value);
    }

    @Override
    public String getTypeString()
    {
        return "string";
    }

    @Override
    public class_2520 toTag(boolean force)
    {
        return class_2519.method_23256(str);
    }
}
