package carpet.mixins;

import carpet.fakes.RecipeManagerInterface;
import com.google.common.collect.Lists;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_7924;

@Mixin(class_1863.class)
public class RecipeManager_scarpetMixin implements RecipeManagerInterface
{

    @Shadow private Map<class_3956<?>, Map<class_2960, class_1860<?>>> recipes;

    @Override
    public List<class_1860<?>> getAllMatching(class_3956<?> type, class_2960 output, final class_5455 registryAccess)
    {
        Map<class_2960, class_1860<?>> typeRecipes = recipes.get(type);
        // happens when mods add recipe to the registry without updating recipe manager
        if (typeRecipes == null) return Collections.emptyList();
        if (typeRecipes.containsKey(output)) return Collections.singletonList(typeRecipes.get(output));
        final class_2378<class_1792> regs = registryAccess.method_30530(class_7924.field_41197);
        return Lists.newArrayList(typeRecipes.values().stream().filter(
                r -> regs.method_10221(r.method_8110(registryAccess).method_7909()).equals(output)).collect(Collectors.toList()));
    }
}
