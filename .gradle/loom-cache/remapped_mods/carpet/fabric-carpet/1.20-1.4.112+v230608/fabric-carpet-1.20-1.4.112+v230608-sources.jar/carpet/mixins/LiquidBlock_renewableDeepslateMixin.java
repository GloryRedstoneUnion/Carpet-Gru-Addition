package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2404.class)
public abstract class LiquidBlock_renewableDeepslateMixin {

    @Shadow protected abstract void fizz(class_1936 world, class_2338 pos);

    @Inject(method = "shouldSpreadLiquid", at = @At(value = "INVOKE",target = "Lnet/minecraft/world/level/material/FluidState;isSource()Z"), cancellable = true)
    private void receiveFluidToDeepslate(class_1937 world, class_2338 pos, class_2680 state, CallbackInfoReturnable<Boolean> cir)
    {
        if(CarpetSettings.renewableDeepslate && !world.method_8316(pos).method_15771() && world.method_27983() == class_1937.field_25179 && pos.method_10264() < 0)
        {
            world.method_8501(pos, class_2246.field_29031.method_9564());
            this.fizz(world, pos);
            cir.setReturnValue(false);
            cir.cancel();
        }
    }
}
