package carpet.script.api;

import carpet.script.CarpetContext;
import carpet.script.CarpetEventServer;
import carpet.script.CarpetScriptHost;
import carpet.script.Context;
import carpet.script.Expression;
import carpet.script.argument.FunctionArgument;
import carpet.script.argument.Vector3Argument;
import carpet.script.exception.InternalExpressionException;
import carpet.script.value.EntityValue;
import carpet.script.value.ListValue;
import carpet.script.value.NBTSerializableValue;
import carpet.script.value.NumericValue;
import carpet.script.value.Value;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1301;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_2168;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_7924;

public class Entities
{
    private static ListValue getPlayersFromWorldMatching(Context c, Predicate<class_3222> condition)
    {
        List<Value> ret = new ArrayList<>();
        for (class_3222 player : ((CarpetContext) c).level().method_18456())
        {
            if (condition.test(player))
            {
                ret.add(new EntityValue(player));
            }
        }
        return ListValue.wrap(ret);
    }

    public static void apply(Expression expression)
    {
        expression.addContextFunction("player", -1, (c, t, lv) ->
        {
            if (lv.isEmpty())
            {
                CarpetContext cc = (CarpetContext) c;
                if (cc.host.user != null)
                {
                    class_3222 player = cc.server().method_3760().method_14566(cc.host.user);
                    return EntityValue.of(player);
                }
                class_1297 callingEntity = cc.source().method_9228();
                if (callingEntity instanceof class_1657)
                {
                    return EntityValue.of(callingEntity);
                }
                class_243 pos = ((CarpetContext) c).source().method_9222();
                class_1657 closestPlayer = ((CarpetContext) c).level().method_8604(pos.field_1352, pos.field_1351, pos.field_1350, -1.0, class_1301.field_6154);
                return EntityValue.of(closestPlayer);
            }
            String playerName = lv.get(0).getString();
            return switch (playerName)
                    {
                        case "all" -> {
                            List<Value> ret = new ArrayList<>();
                            for (class_3222 player : ((CarpetContext) c).server().method_3760().method_14571())
                            {
                                ret.add(new EntityValue(player));
                            }
                            yield ListValue.wrap(ret);
                        }
                        case "*" -> getPlayersFromWorldMatching(c, p -> true);
                        case "survival" -> getPlayersFromWorldMatching(c, p -> p.field_13974.method_14267()); // includes adventure
                        case "creative" -> getPlayersFromWorldMatching(c, class_3222::method_7337);
                        case "spectating" -> getPlayersFromWorldMatching(c, class_3222::method_7325);
                        case "!spectating" -> getPlayersFromWorldMatching(c, p -> !p.method_7325());
                        default -> {
                            class_3222 player = ((CarpetContext) c).server().method_3760().method_14566(playerName);
                            yield player != null ? new EntityValue(player) : Value.NULL;
                        }
                    };
        });

        expression.addContextFunction("spawn", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            if (lv.size() < 2)
            {
                throw new InternalExpressionException("'spawn' function takes mob name, and position to spawn");
            }
            String entityString = lv.get(0).getString();
            class_2960 entityId;
            try
            {
                entityId = class_2960.method_12835(new StringReader(entityString));
                class_1299<? extends class_1297> type = cc.registry(class_7924.field_41266).method_17966(entityId).orElse(null);
                if (type == null || !type.method_5896())
                {
                    return Value.NULL;
                }
            }
            catch (CommandSyntaxException ignored)
            {
                return Value.NULL;
            }

            Vector3Argument position = Vector3Argument.findIn(lv, 1);
            if (position.fromBlock)
            {
                position.vec = position.vec.method_1023(0, 0.5, 0);
            }
            class_2487 tag = new class_2487();
            boolean hasTag = false;
            if (lv.size() > position.offset)
            {
                Value nbt = lv.get(position.offset);
                NBTSerializableValue v = (nbt instanceof final NBTSerializableValue nbtsv)
                        ? nbtsv
                        : NBTSerializableValue.parseStringOrFail(nbt.getString());
                hasTag = true;
                tag = v.getCompoundTag();
            }
            tag.method_10582("id", entityId.toString());
            class_243 vec3d = position.vec;

            class_3218 serverWorld = cc.level();
            class_1297 entity = class_1299.method_17842(tag, serverWorld, e -> {
                e.method_5808(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350, e.method_36454(), e.method_36455());
                return e;
            });
            if (entity == null)
            {
                return Value.NULL;
            }
            if (!hasTag && entity instanceof final class_1308 mob)
            {
                mob.method_5943(serverWorld, serverWorld.method_8404(entity.method_24515()), class_3730.field_16462, null, null);
            }
            if (!serverWorld.method_30736(entity))
            {
                entity.method_31472();
                return Value.NULL;
            }
            return new EntityValue(entity);
        });

        expression.addContextFunction("entity_id", 1, (c, t, lv) ->
        {
            Value who = lv.get(0);
            if (who instanceof final NumericValue numericValue)
            {
                return EntityValue.of(((CarpetContext) c).level().method_8469((int) numericValue.getLong()));
            }
            return EntityValue.of(((CarpetContext) c).level().method_14190(UUID.fromString(who.getString())));
        });

        expression.addContextFunction("entity_list", 1, (c, t, lv) ->
        {
            String who = lv.get(0).getString();
            class_2168 source = ((CarpetContext) c).source();
            EntityValue.EntityClassDescriptor eDesc = EntityValue.getEntityDescriptor(who, source.method_9211());
            List<? extends class_1297> entityList = source.method_9225().method_18198(eDesc.directType, eDesc.filteringPredicate);
            return ListValue.wrap(entityList.stream().map(EntityValue::new));
        });

        expression.addContextFunction("entity_area", -1, (c, t, lv) ->
        {
            if (lv.size() < 3)
            {
                throw new InternalExpressionException("'entity_area' requires entity type, center and range arguments");
            }
            String who = lv.get(0).getString();
            CarpetContext cc = (CarpetContext) c;
            Vector3Argument centerLocator = Vector3Argument.findIn(lv, 1, false, true);

            class_238 centerBox;
            if (centerLocator.entity != null)
            {
                centerBox = centerLocator.entity.method_5829();
            }
            else
            {
                class_243 center = centerLocator.vec;
                if (centerLocator.fromBlock)
                {
                    center.method_1031(0.5, 0.5, 0.5);
                }
                centerBox = new class_238(center, center);
            }
            Vector3Argument rangeLocator = Vector3Argument.findIn(lv, centerLocator.offset);
            if (rangeLocator.fromBlock)
            {
                throw new InternalExpressionException("Range of 'entity_area' cannot come from a block argument");
            }
            class_243 range = rangeLocator.vec;
            class_238 area = centerBox.method_1009(range.field_1352, range.field_1351, range.field_1350);
            EntityValue.EntityClassDescriptor eDesc = EntityValue.getEntityDescriptor(who, cc.server());
            List<? extends class_1297> entityList = cc.level().method_18023(eDesc.directType, area, eDesc.filteringPredicate);
            return ListValue.wrap(entityList.stream().map(EntityValue::new));
        });

        expression.addContextFunction("entity_selector", -1, (c, t, lv) ->
        {
            String selector = lv.get(0).getString();
            List<Value> retlist = new ArrayList<>();
            for (class_1297 e : EntityValue.getEntitiesFromSelector(((CarpetContext) c).source(), selector))
            {
                retlist.add(new EntityValue(e));
            }
            return ListValue.wrap(retlist);
        });

        expression.addContextFunction("query", -1, (c, t, lv) ->
        {
            if (lv.size() < 2)
            {
                throw new InternalExpressionException("'query' takes entity as a first argument, and queried feature as a second");
            }
            Value v = lv.get(0);
            if (!(v instanceof final EntityValue ev))
            {
                throw new InternalExpressionException("First argument to query should be an entity");
            }
            String what = lv.get(1).getString().toLowerCase(Locale.ROOT);
            if (what.equals("tags"))
            {
                c.host.issueDeprecation("'tags' for entity querying");
            }
            return switch (lv.size())
                    {
                        case 2 -> ev.get(what, null);
                        case 3 -> ev.get(what, lv.get(2));
                        default -> ev.get(what, ListValue.wrap(lv.subList(2, lv.size())));
                    };
        });

        // or update
        expression.addContextFunction("modify", -1, (c, t, lv) ->
        {
            if (lv.size() < 2)
            {
                throw new InternalExpressionException("'modify' takes entity as a first argument, and queried feature as a second");
            }
            Value v = lv.get(0);
            if (!(v instanceof final EntityValue ev))
            {
                throw new InternalExpressionException("First argument to modify should be an entity");
            }
            String what = lv.get(1).getString();
            switch (lv.size())
            {
                case 2 -> ev.set(what, null);
                case 3 -> ev.set(what, lv.get(2));
                default -> ev.set(what, ListValue.wrap(lv.subList(2, lv.size())));
            }
            return v;
        });

        expression.addContextFunction("entity_types", -1, (c, t, lv) ->
        {
            if (lv.size() > 1)
            {
                throw new InternalExpressionException("'entity_types' requires one or no arguments");
            }
            String desc = (lv.size() == 1) ? lv.get(0).getString() : "*";
            return EntityValue.getEntityDescriptor(desc, ((CarpetContext) c).server()).listValue(((CarpetContext) c).registryAccess());
        });

        expression.addContextFunction("entity_load_handler", -1, (c, t, lv) ->
        {
            if (lv.size() < 2)
            {
                throw new InternalExpressionException("'entity_load_handler' required the entity type, and a function to call");
            }
            Value entityValue = lv.get(0);
            List<String> descriptors = (entityValue instanceof final ListValue list)
                    ? list.getItems().stream().map(Value::getString).toList()
                    : Collections.singletonList(entityValue.getString());
            Set<class_1299<? extends class_1297>> types = new HashSet<>();
            descriptors.forEach(s -> types.addAll(EntityValue.getEntityDescriptor(s, ((CarpetContext) c).server()).types));
            FunctionArgument funArg = FunctionArgument.findIn(c, expression.module, lv, 1, true, false);
            CarpetEventServer events = ((CarpetScriptHost) c.host).scriptServer().events;
            if (funArg.function == null)
            {
                types.forEach(et -> events.removeBuiltInEvent(CarpetEventServer.Event.getEntityLoadEventName(et), (CarpetScriptHost) c.host));
                types.forEach(et -> events.removeBuiltInEvent(CarpetEventServer.Event.getEntityHandlerEventName(et), (CarpetScriptHost) c.host));
            }
            else
            {
                ///compat
                int numberOfArguments = funArg.function.getArguments().size() - funArg.args.size();
                if (numberOfArguments == 1)
                {
                    c.host.issueDeprecation("entity_load_handler() with single argument callback");
                    types.forEach(et -> events.addBuiltInEvent(CarpetEventServer.Event.getEntityLoadEventName(et), c.host, funArg.function, funArg.args));
                }
                else
                {
                    types.forEach(et -> events.addBuiltInEvent(CarpetEventServer.Event.getEntityHandlerEventName(et), c.host, funArg.function, funArg.args));
                }
            }
            return new NumericValue(types.size());
        });

        // or update
        expression.addContextFunction("entity_event", -1, (c, t, lv) ->
        {
            if (lv.size() < 3)
            {
                throw new InternalExpressionException("'entity_event' requires at least 3 arguments, entity, event to be handled, and function name, with optional arguments");
            }
            Value v = lv.get(0);
            if (!(v instanceof final EntityValue ev))
            {
                throw new InternalExpressionException("First argument to entity_event should be an entity");
            }
            String what = lv.get(1).getString();

            FunctionArgument funArg = FunctionArgument.findIn(c, expression.module, lv, 2, true, false);

            ev.setEvent((CarpetContext) c, what, funArg.function, funArg.args);

            return Value.NULL;
        });
    }
}
