package carpet.mixins;

import carpet.patches.EntityPlayerMPFake;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1657.class)
public abstract class Player_fakePlayersMixin
{
    /**
     * To make sure player attacks are able to knockback fake players
     */
    @Redirect(
            method = "attack",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/world/entity/Entity;hurtMarked:Z",
                    ordinal = 0
            )
    )
    private boolean velocityModifiedAndNotCarpetFakePlayer(class_1297 target)
    {
        return target.field_6037 && !(target instanceof EntityPlayerMPFake);
    }
}
