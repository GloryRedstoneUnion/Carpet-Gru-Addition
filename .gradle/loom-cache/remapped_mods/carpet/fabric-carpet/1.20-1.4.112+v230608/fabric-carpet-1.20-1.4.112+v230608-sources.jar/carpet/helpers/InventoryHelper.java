package carpet.helpers;

import net.minecraft.class_1799;
import net.minecraft.class_2487;

public class InventoryHelper
{
    // From nbt/NbtElement.java createTag()
    public static final int TAG_END         = 0;
    public static final int TAG_BYTE        = 1;
    public static final int TAG_SHORT       = 2;
    public static final int TAG_INT         = 3;
    public static final int TAG_LONG        = 4;
    public static final int TAG_FLOAT       = 5;
    public static final int TAG_DOUBLE      = 6;
    public static final int TAG_BYTEARRAY   = 7;
    public static final int TAG_STRING      = 8;
    public static final int TAG_LIST        = 9;
    public static final int TAG_COMPOUND    = 10;
    public static final int TAG_INTARRAY    = 11;
    public static final int TAG_LONGARRAY   = 12;

    public static boolean cleanUpShulkerBoxTag(class_1799 stack)
    {
        boolean changed = false;
        class_2487 tag = stack.method_7969();

        if (tag == null || !tag.method_10573("BlockEntityTag", TAG_COMPOUND))
            return false;

        class_2487 bet = tag.method_10562("BlockEntityTag");
        if (bet.method_10573("Items", TAG_LIST) && bet.method_10554("Items", TAG_COMPOUND).isEmpty())
        {
            bet.method_10551("Items");
            changed = true;
        }

        if (bet.method_33133() || (bet.method_10546() == 1 && bet.method_10558("id").equals("minecraft:shulker_box")))
        {
            tag.method_10551("BlockEntityTag");
            changed = true;
        }
        if (tag.method_33133())
        {
            stack.method_7980(null);
            changed = true;
        }
        return changed;
    }

    public static boolean shulkerBoxHasItems(class_1799 stack)
    {
        class_2487 tag = stack.method_7969();

        if (tag == null || !tag.method_10573("BlockEntityTag", TAG_COMPOUND))
            return false;

        class_2487 bet = tag.method_10562("BlockEntityTag");
        return bet.method_10573("Items", TAG_LIST) && !bet.method_10554("Items", TAG_COMPOUND).isEmpty();
    }
}
