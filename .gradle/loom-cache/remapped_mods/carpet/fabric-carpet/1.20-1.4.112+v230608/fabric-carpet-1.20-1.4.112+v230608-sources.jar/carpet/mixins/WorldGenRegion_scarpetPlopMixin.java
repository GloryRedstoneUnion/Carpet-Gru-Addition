package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2338;
import net.minecraft.class_3233;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3233.class)
public class WorldGenRegion_scarpetPlopMixin
{
    @Inject(method = "markPosForPostprocessing", at = @At("HEAD"), cancellable = true)
    private void markOrNot(class_2338 blockPos, CallbackInfo ci)
    {
        if (CarpetSettings.skipGenerationChecks.get()) ci.cancel();
    }
}
