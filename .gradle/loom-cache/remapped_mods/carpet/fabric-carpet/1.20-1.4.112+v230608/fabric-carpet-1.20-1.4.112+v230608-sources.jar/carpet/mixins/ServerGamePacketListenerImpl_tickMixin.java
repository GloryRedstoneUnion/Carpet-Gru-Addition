package carpet.mixins;

import carpet.fakes.MinecraftServerInterface;
import net.minecraft.class_2828;
import net.minecraft.class_2851;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public class ServerGamePacketListenerImpl_tickMixin
{
    @Shadow public class_3222 player;

    @Shadow private double firstGoodX;

    @Shadow private double firstGoodY;

    @Shadow private double firstGoodZ;

    @Inject(method = "handlePlayerInput", at = @At(value = "RETURN"))
    private void checkMoves(class_2851 p, CallbackInfo ci)
    {
        if (p.method_12372() != 0.0F || p.method_12373() != 0.0F || p.method_12371() || p.method_12370())
        {
            ((MinecraftServerInterface)player.method_5682()).getTickRateManager().resetPlayerActivity();
        }
    }

    // to skip reposition adjustment check
    private static long lastMovedTick = 0L;
    private static double lastMoved = 0.0D;

    @Inject(method = "handleMovePlayer",  at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;isSleeping()Z",
            shift = At.Shift.BEFORE
    ))
    private void checkMove(class_2828 p, CallbackInfo ci)
    {
        double movedBy = player.method_19538().method_1028(firstGoodX, firstGoodY, firstGoodZ);
        if (movedBy == 0.0D) return;
        // corrective tick
        if (movedBy < 0.0009 && lastMoved > 0.0009 && Math.abs(player.method_5682().method_3780()-lastMovedTick-20)<2)
        {
            return;
        }
        if (movedBy > 0.0D)
        {
            lastMoved = movedBy;
            lastMovedTick = player.method_5682().method_3780();
            ((MinecraftServerInterface)player.method_5682()).getTickRateManager().resetPlayerActivity();
        }
    }
}
