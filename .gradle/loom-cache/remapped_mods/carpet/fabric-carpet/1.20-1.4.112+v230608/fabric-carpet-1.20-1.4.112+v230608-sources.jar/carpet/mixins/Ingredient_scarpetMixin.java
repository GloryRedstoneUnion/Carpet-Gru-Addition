package carpet.mixins;

import carpet.fakes.IngredientInterface;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1856;

@Mixin(class_1856.class)
public class Ingredient_scarpetMixin implements IngredientInterface
{
    @Shadow @Final private class_1856.class_1859[] values;

    @Override
    public List<Collection<class_1799>> getRecipeStacks()
    {
        return Arrays.stream(values).map(class_1856.class_1859::method_8108).toList();
    }
}
