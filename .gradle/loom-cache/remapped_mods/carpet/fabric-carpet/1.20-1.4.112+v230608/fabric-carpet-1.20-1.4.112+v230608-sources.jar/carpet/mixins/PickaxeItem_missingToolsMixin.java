package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1766;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1810.class)
public class PickaxeItem_missingToolsMixin extends class_1766
{

    protected PickaxeItem_missingToolsMixin(float attackDamage, float attackSpeed, class_1832 material, class_6862<class_2248> tag, class_1793 settings) {
        super(attackDamage, attackSpeed, material, tag, settings);
    }

    @Override
    public float method_7865(class_1799 stack, class_2680 state) {
        if (CarpetSettings.missingTools && state.method_26204().method_9573(state) == class_2498.field_11537)
        {
            return field_7940;
        }
        return super.method_7865(stack, state);
    }
}
