package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2627;
import net.minecraft.class_3619;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2627.class)
public class ShulkerBoxBlockEntity_creativeNoClipMixin
{
    @Redirect(method = "moveCollidedEntities", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/Entity;getPistonPushReaction()Lnet/minecraft/world/level/material/PushReaction;"
    ))
    private class_3619 getPistonBehaviourOfNoClipPlayers(class_1297 entity)
    {
        if (CarpetSettings.creativeNoClip && entity instanceof class_1657 && (((class_1657) entity).method_7337()) && ((class_1657) entity).method_31549().field_7479)
            return class_3619.field_15975;
        return entity.method_5657();
    }
}
