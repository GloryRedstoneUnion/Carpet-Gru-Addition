package carpet.commands;

import carpet.CarpetServer;
import carpet.utils.Messenger;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class TestCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher)
    {
        dispatcher.register(method_9247("testcarpet").
                then(method_9247("dump").
                        executes((c) -> CarpetServer.settingsManager.dumpAllRulesToStream(System.out, null)).
                        then(method_9244("category", word()).
                                executes( (c) -> CarpetServer.settingsManager.dumpAllRulesToStream(System.out, getString(c, "category"))))).
                then(method_9244("first",word()).
                        executes( (c)-> test(c, getString(c, "first")+" 1"))).
                then(method_9244("second", word()).
                        executes( (c)-> test(c, getString(c, "second")+" 2"))));
    }

    private static int test(CommandContext<class_2168> c, String term)
    {
        Messenger.m(c.getSource(),term.substring(0,1)+" "+term+": how did you get here?");
        return 1;
    }
}
