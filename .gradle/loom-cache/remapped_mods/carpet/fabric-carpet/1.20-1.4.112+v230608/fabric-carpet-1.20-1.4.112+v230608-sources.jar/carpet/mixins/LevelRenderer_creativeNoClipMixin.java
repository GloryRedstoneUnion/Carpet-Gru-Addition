package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_746;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_761.class)
public class LevelRenderer_creativeNoClipMixin
{
    @Redirect(method = "renderLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;isSpectator()Z"))
    private boolean canSeeWorld(class_746 clientPlayerEntity)
    {
        return clientPlayerEntity.method_7325() || (CarpetSettings.creativeNoClip && clientPlayerEntity.method_7337());
    }

}
