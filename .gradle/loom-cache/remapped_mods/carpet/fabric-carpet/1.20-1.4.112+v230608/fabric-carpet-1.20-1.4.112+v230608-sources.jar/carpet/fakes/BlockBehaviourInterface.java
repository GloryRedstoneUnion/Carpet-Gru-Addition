package carpet.fakes;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public interface BlockBehaviourInterface {

    /**
     * @return whether this block is sticky in any way when moved by pistons
     */
    public boolean isSticky(class_2680 state);

    /**
     * @return whether the neighboring block is pulled along if this block is moved by pistons
     */
    public boolean isStickyToNeighbor(class_1937 level, class_2338 pos, class_2680 state, class_2338 neighborPos, class_2680 neighborState, class_2350 dir, class_2350 moveDir);

}
