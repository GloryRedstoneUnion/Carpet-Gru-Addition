package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1303.class)
public abstract class ExperienceOrb_xpNoCooldownMixin extends class_1297
{
    @Shadow
    private int count;

    @Shadow
    private int value;

    public ExperienceOrb_xpNoCooldownMixin(class_1299<?> type, class_1937 world)
    {
        super(type, world);
    }

    @Shadow
    protected abstract int repairPlayerItems(class_1657 player, int amount);

    @Inject(method = "playerTouch", at = @At("HEAD"))
    private void addXP(class_1657 player, CallbackInfo ci) {
        if (CarpetSettings.xpNoCooldown && !method_37908().field_9236) {
            player.field_7504 = 0;
            // reducing the count to 1 and leaving vanilla to deal with it
            while (this.count > 1) {
                int remainder = this.repairPlayerItems(player, this.value);
                if (remainder > 0) {
                    player.method_7255(remainder);
                }
                this.count--;
            }
        }
    }
}
