package carpet.fakes;

import net.minecraft.class_2338;

public interface BlockEntityInterface
{
    void setCMPos(class_2338 pos);
}
