package carpet.mixins;

import carpet.logging.LoggerRegistry;
import carpet.logging.logHelpers.TrajectoryLogHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1665.class)
public abstract class AbstractArrowMixin extends class_1297
{
    private TrajectoryLogHelper logHelper;
    public AbstractArrowMixin(class_1299<?> entityType_1, class_1937 world_1) { super(entityType_1, world_1); }

    @Inject(method = "<init>(Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V", at = @At("RETURN"))
    private void addLogger(class_1299<? extends class_1676> entityType_1, class_1937 world_1, CallbackInfo ci)
    {
        if (LoggerRegistry.__projectiles && !world_1.field_9236)
            logHelper = new TrajectoryLogHelper("projectiles");
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void tickCheck(CallbackInfo ci)
    {
        if (LoggerRegistry.__projectiles && logHelper != null)
            logHelper.onTick(method_23317(), method_23318(), method_23321(), method_18798());
    }

    // todo should be moved on one place this is acceessed from
    @Inject(method = "onHitEntity", at = @At("RETURN"))
    private void removeOnEntity(class_3966 entityHitResult, CallbackInfo ci)
    {
        if (LoggerRegistry.__projectiles && logHelper != null)
        {
            logHelper.onFinish();
            logHelper = null;
        }
    }

    @Inject(method = "onHitBlock", at = @At("RETURN"))
    private void removeOnBlock(class_3965 blockHitResult, CallbackInfo ci)
    {
        if (LoggerRegistry.__projectiles && logHelper != null)
        {
            logHelper.onFinish();
            logHelper = null;
        }
    }
}
