package carpet.logging.logHelpers;

import carpet.logging.LoggerRegistry;
import carpet.utils.Messenger;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1927;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_5455;
import net.minecraft.class_7924;

import static carpet.utils.Messenger.c;

public class ExplosionLogHelper
{
    private final boolean createFire;
    private final class_1927.class_4179 blockDestructionType;
    private final class_5455 regs;
    public final class_243 pos;
    private final float power;
    private boolean affectBlocks = false;
    private final Object2IntMap<EntityChangedStatusWithCount> impactedEntities = new Object2IntOpenHashMap<>();

    private static long lastGametime = 0;
    private static int explosionCountInCurrentGT = 0;
    private static boolean newTick;

    public ExplosionLogHelper(double x, double y, double z, float power, boolean createFire, class_1927.class_4179 blockDestructionType, class_5455 regs) {
        this.power = power;
        this.pos = new class_243(x,y,z);
        this.createFire = createFire;
        this.blockDestructionType = blockDestructionType;
        this.regs = regs;
    }

    public void setAffectBlocks(boolean b)
    {
        affectBlocks = b;
    }

    public void onExplosionDone(long gametime)
    {
        newTick = false;
        if (!(lastGametime == gametime)){
            explosionCountInCurrentGT = 0;
            lastGametime = gametime;
            newTick = true;
        }
        explosionCountInCurrentGT++;
        LoggerRegistry.getLogger("explosions").log( (option) -> {
            List<class_2561> messages = new ArrayList<>();
            if(newTick) messages.add(c("wb tick : ", "d " + gametime));
            if ("brief".equals(option))
            {
                messages.add( c("d #" + explosionCountInCurrentGT,"gb ->",
                        Messenger.dblt("l", pos.field_1352, pos.field_1351, pos.field_1350), (affectBlocks)?"m  (affects blocks)":"m  (doesn't affect blocks)" ));
            }
            if ("full".equals(option))
            {
                messages.add( c("d #" + explosionCountInCurrentGT,"gb ->", Messenger.dblt("l", pos.field_1352, pos.field_1351, pos.field_1350) ));
                messages.add(c("w   affects blocks: ", "m " + this.affectBlocks));
                messages.add(c("w   creates fire: ", "m " + this.createFire));
                messages.add(c("w   power: ", "c " + this.power));
                messages.add(c( "w   destruction: ",   "c " + this.blockDestructionType.name()));
                if (impactedEntities.isEmpty())
                {
                    messages.add(c("w   affected entities: ", "m None"));
                }
                else
                {
                    messages.add(c("w   affected entities:"));
                    impactedEntities.forEach((k, v) ->
                    {
                        messages.add(c((k.pos.equals(pos))?"r   - TNT":"w   - ",
                                Messenger.dblt((k.pos.equals(pos))?"r":"y", k.pos.field_1352, k.pos.field_1351, k.pos.field_1350), "w  dV",
                                Messenger.dblt("d", k.accel.field_1352, k.accel.field_1351, k.accel.field_1350),
                                "w  "+ regs.method_30530(class_7924.field_41266).method_10221(k.type).method_12832(), (v>1)?"l ("+v+")":""
                        ));
                    });
                }
            }
            return messages.toArray(new class_2561[0]);
        });
    }

    public void onEntityImpacted(class_1297 entity, class_243 accel)
    {
        EntityChangedStatusWithCount ent = new EntityChangedStatusWithCount(entity, accel);
        impactedEntities.put(ent, impactedEntities.getOrDefault(ent, 0)+1);
    }


    public static record EntityChangedStatusWithCount(class_243 pos, class_1299<?> type, class_243 accel)
    {
        public EntityChangedStatusWithCount(class_1297 e, class_243 accel)
        {
            this(e.method_19538(), e.method_5864(), accel);
        }
    }
}
