package carpet.script.utils;

import carpet.script.CarpetContext;
import carpet.script.CarpetScriptHost;
import carpet.script.external.Carpet;
import carpet.script.external.Vanilla;
import carpet.script.value.BooleanValue;
import carpet.script.value.EntityValue;
import carpet.script.value.ListValue;
import carpet.script.value.MapValue;
import carpet.script.value.NumericValue;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import carpet.script.value.ValueConversions;
import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_155;
import net.minecraft.class_1928;
import net.minecraft.class_241;
import net.minecraft.class_2784;
import net.minecraft.class_3264;
import net.minecraft.class_5217;
import net.minecraft.class_5218;

public class SystemInfo
{
    private static final Map<String, Function<CarpetContext, Value>> options = new HashMap<>()
    {{
        put("app_name", c ->
        {
            String name = c.host.getName();
            return name == null ? Value.NULL : new StringValue(name);
        });
        put("app_list", c -> ListValue.wrap(((CarpetScriptHost) c.host).scriptServer().modules.keySet().stream().filter(Objects::nonNull).map(StringValue::new)));
        put("app_scope", c -> StringValue.of((c.host).isPerUser() ? "player" : "global"));
        put("app_players", c -> ListValue.wrap(c.host.getUserList().stream().map(StringValue::new)));

        put("world_name", c -> new StringValue(c.server().method_27728().method_150()));
        put("world_seed", c -> new NumericValue(c.level().method_8412()));
        put("server_motd", c -> StringValue.of(c.server().method_3818()));
        put("world_path", c -> StringValue.of(c.server().method_27050(class_5218.field_24188).toString()));
        put("world_folder", c -> {
            Path serverPath = c.server().method_27050(class_5218.field_24188);
            int nodeCount = serverPath.getNameCount();
            if (nodeCount < 2)
            {
                return Value.NULL;
            }
            String tlf = serverPath.getName(nodeCount - 2).toString();
            return StringValue.of(tlf);
        });
        put("world_dimensions", c -> ListValue.wrap(c.server().method_29435().stream().map(k -> ValueConversions.of(k.method_29177()))));
        put("world_spawn_point", c -> {
            class_5217 prop = c.server().method_30002().method_8401();
            return ListValue.of(NumericValue.of(prop.method_215()), NumericValue.of(prop.method_144()), NumericValue.of(prop.method_166()));
        });

        put("world_bottom", c -> new NumericValue(c.level().method_31607()));

        put("world_top", c -> new NumericValue(c.level().method_31600()));

        put("world_center", c -> {
            class_2784 worldBorder = c.level().method_8621();
            return ListValue.fromTriple(worldBorder.method_11964(), 0, worldBorder.method_11980());
        });

        put("world_size", c -> new NumericValue(c.level().method_8621().method_11965() / 2));

        put("world_max_size", c -> new NumericValue(c.level().method_8621().method_11959()));

        put("world_time", c -> new NumericValue(c.level().method_8510()));

        put("game_difficulty", c -> StringValue.of(c.server().method_27728().method_207().method_5460()));
        put("game_hardcore", c -> BooleanValue.of(c.server().method_27728().method_152()));
        put("game_storage_format", c -> StringValue.of(c.server().method_27728().method_27440(c.server().method_27728().method_168())));
        put("game_default_gamemode", c -> StringValue.of(c.server().method_3790().method_8381()));
        put("game_max_players", c -> new NumericValue(c.server().method_3802()));
        put("game_view_distance", c -> new NumericValue(c.server().method_3760().method_14568()));
        put("game_mod_name", c -> StringValue.of(c.server().getServerModName()));
        put("game_version", c -> StringValue.of(c.server().method_3827()));
        put("game_target", c -> StringValue.of(Vanilla.MinecraftServer_getReleaseTarget(c.server())));
        put("game_protocol", c -> NumericValue.of(class_155.method_31372()));
        put("game_major_target", c -> {
            String[] vers = Vanilla.MinecraftServer_getReleaseTarget(c.server()).split("\\.");
            return NumericValue.of((vers.length > 1) ? Integer.parseInt(vers[1]) : 0);
        });
        put("game_minor_target", c -> {
            String[] vers = Vanilla.MinecraftServer_getReleaseTarget(c.server()).split("\\.");
            return NumericValue.of((vers.length > 2) ? Integer.parseInt(vers[2]) : 0);
        });
        put("game_stable", c -> BooleanValue.of(class_155.method_16673().method_48022()));
        put("game_data_version", c -> NumericValue.of(class_155.method_16673().method_37912().method_38494()));
        put("game_pack_version", c -> NumericValue.of(class_155.method_16673().method_48017(class_3264.field_14190)));

        put("server_ip", c -> StringValue.of(c.server().method_3819()));
        put("server_whitelisted", c -> BooleanValue.of(c.server().method_3729()));
        put("server_whitelist", c -> {
            MapValue whitelist = new MapValue(Collections.emptyList());
            for (String s : c.server().method_3760().method_14560())
            {
                whitelist.append(StringValue.of(s));
            }
            return whitelist;
        });
        put("server_banned_players", c -> {
            MapValue whitelist = new MapValue(Collections.emptyList());
            for (String s : c.server().method_3760().method_14563().method_14636())
            {
                whitelist.append(StringValue.of(s));
            }
            return whitelist;
        });
        put("server_banned_ips", c -> {
            MapValue whitelist = new MapValue(Collections.emptyList());
            for (String s : c.server().method_3760().method_14585().method_14636())
            {
                whitelist.append(StringValue.of(s));
            }
            return whitelist;
        });
        put("server_dev_environment", c -> BooleanValue.of(Vanilla.isDevelopmentEnvironment()));
        put("server_mods", c -> Vanilla.getServerMods(c.server()));
        put("server_last_tick_times", c -> {
            //assuming we are in the tick world section
            // might be off one tick when run in the off tasks or asynchronously.
            int currentReportedTick = c.server().method_3780() - 1;
            List<Value> ticks = new ArrayList<>(100);
            long[] tickArray = c.server().field_4573;
            for (int i = currentReportedTick + 100; i > currentReportedTick; i--)
            {
                ticks.add(new NumericValue((tickArray[i % 100]) / 1000000.0));
            }
            return ListValue.wrap(ticks);
        });

        put("java_max_memory", c -> new NumericValue(Runtime.getRuntime().maxMemory()));
        put("java_allocated_memory", c -> new NumericValue(Runtime.getRuntime().totalMemory()));
        put("java_used_memory", c -> new NumericValue(Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
        put("java_cpu_count", c -> new NumericValue(Runtime.getRuntime().availableProcessors()));
        put("java_version", c -> StringValue.of(System.getProperty("java.version")));
        put("java_bits", c -> {
            for (String property : new String[]{"sun.arch.data.model", "com.ibm.vm.bitmode", "os.arch"})
            {
                String value = System.getProperty(property);
                if (value != null && value.contains("64"))
                {
                    return new NumericValue(64);
                }
            }
            return new NumericValue(32);
        });
        put("java_system_cpu_load", c -> {
            OperatingSystemMXBean osBean = ManagementFactory.getPlatformMXBean(
                    OperatingSystemMXBean.class);
            return new NumericValue(osBean.getCpuLoad());
        });
        put("java_process_cpu_load", c -> {
            OperatingSystemMXBean osBean = ManagementFactory.getPlatformMXBean(
                    OperatingSystemMXBean.class);
            return new NumericValue(osBean.getProcessCpuLoad());
        });
        put("world_carpet_rules", c -> Carpet.getAllCarpetRules());
        put("world_gamerules", c -> {
            Map<Value, Value> rules = new HashMap<>();
            class_1928 gameRules = c.level().method_8450();
            class_1928.method_20744(new class_1928.class_4311()
            {
                @Override
                public <T extends class_1928.class_4315<T>> void method_20762(class_1928.class_4313<T> key, class_1928.class_4314<T> type)
                {
                    rules.put(StringValue.of(key.method_20771()), StringValue.of(gameRules.method_20746(key).toString()));
                }
            });
            return MapValue.wrap(rules);
        });
        put("world_min_spawning_light", c -> NumericValue.of(c.level().method_8597().method_44223()));

        put("source_entity", c -> EntityValue.of(c.source().method_9228()));
        put("source_position", c -> ValueConversions.of(c.source().method_9222()));
        put("source_dimension", c -> ValueConversions.of(c.level()));
        put("source_rotation", c -> {
            class_241 rotation = c.source().method_9210();
            return ListValue.of(new NumericValue(rotation.field_1343), new NumericValue(rotation.field_1342));
        });
        put("scarpet_version", c -> StringValue.of(Carpet.getCarpetVersion()));
    }};

    public static Value get(String what, CarpetContext cc)
    {
        return options.getOrDefault(what, c -> null).apply(cc);
    }

    public static Value getAll()
    {
        return ListValue.wrap(options.keySet().stream().map(StringValue::of));
    }

}
