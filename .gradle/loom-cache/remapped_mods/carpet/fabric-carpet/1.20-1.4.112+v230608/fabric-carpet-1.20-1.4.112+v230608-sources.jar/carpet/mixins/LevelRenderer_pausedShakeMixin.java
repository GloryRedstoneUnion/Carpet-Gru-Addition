package carpet.mixins;

import carpet.fakes.LevelInterface;
import carpet.fakes.MinecraftClientInferface;
import carpet.helpers.TickRateManager;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value = class_761.class, priority = 69420)
public class LevelRenderer_pausedShakeMixin
{
    @Shadow @Final private class_310 minecraft;

    @Shadow private class_638 level;
    float initial = -1234.0f;

    // require 0 is for optifine being a bitch as it usually is.
    @ModifyVariable(method = "renderLevel", argsOnly = true, require = 0, ordinal = 0, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/multiplayer/ClientLevel;entitiesForRendering()Ljava/lang/Iterable;"
    ))
    private float changeTickPhase(float previous)
    {
        initial = previous;
        TickRateManager trm = ((LevelInterface)level).tickRateManager();
        if (!trm.runsNormally())
            return ((MinecraftClientInferface)minecraft).getPausedTickDelta();
        return previous;
    }

    // require 0 is for optifine being a bitch as it usually is.
    @ModifyVariable(method = "renderLevel", argsOnly = true, require = 0, ordinal = 0 ,at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/particle/ParticleEngine;render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;Lnet/minecraft/client/renderer/LightTexture;Lnet/minecraft/client/Camera;F)V",
            shift = At.Shift.BEFORE
    ))
    private float changeTickPhaseBack(float previous)
    {
        // this may not set with optifine bitch
        return initial==-1234.0f?previous:initial;
    }

}
