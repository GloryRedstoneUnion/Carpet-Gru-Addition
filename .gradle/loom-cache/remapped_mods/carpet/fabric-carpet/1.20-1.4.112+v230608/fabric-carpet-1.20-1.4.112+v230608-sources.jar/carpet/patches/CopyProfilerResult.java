package carpet.patches;

import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_3534;
import net.minecraft.class_3696;

public class CopyProfilerResult implements class_3696 {
    int startI, endI;
    long startL, endL;
    public CopyProfilerResult(int startI, long startL, int endI, long endL)
    {
        this.startI = startI;
        this.startL = startL;
        this.endI = endI;
        this.endL = endL;
    }
    @Override
    public List<class_3534> method_16067(String parentPath) {
        return Collections.emptyList();
    }

    @Override
    public boolean method_16069(Path path) {
        return false;
    }

    @Override
    public long method_16068() {
        return startL;
    }

    @Override
    public int method_16072() {
        return startI;
    }

    @Override
    public long method_16073() {
        return endL;
    }

    @Override
    public int method_16070() {
        return endI;
    }

    @Override
    public String method_34970() {
        return "";
    }
}
