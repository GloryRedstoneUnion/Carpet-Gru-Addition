package carpet.fakes;

import carpet.script.value.Value;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_6862;

public interface BlockPredicateInterface
{
    class_2680 getCMBlockState();
    class_6862<class_2248> getCMBlockTagKey();
    Map<Value, Value> getCMProperties();
    class_2487 getCMDataTag();
}
