package carpet.mixins;

import carpet.utils.SpawnOverrides;
import it.unimi.dsi.fastutil.longs.LongSet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3195;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_6880;

@Mixin(class_2794.class)
public abstract class ChunkGenerator_customMobSpawnsMixin
{
    @Inject(
            method = "getMobsAt", locals = LocalCapture.CAPTURE_FAILHARD,
            at = @At(
                    value = "INVOKE",
                   target = "Ljava/util/Map$Entry;getKey()Ljava/lang/Object;"
            ), cancellable = true)
    private void checkCMSpawns(class_6880<class_1959> holder, class_5138 structureFeatureManager, class_1311 mobCategory, class_2338 blockPos,
                               CallbackInfoReturnable<class_6012<class_5483.class_1964>> cir,
                               Map<class_3195, LongSet> map, Iterator<?> var6, Map.Entry<class_3195, LongSet> entry)
    {
        class_6012<class_5483.class_1964> res = SpawnOverrides.test(structureFeatureManager, entry.getValue(), mobCategory, entry.getKey(), blockPos);
        if (res != null)
        {
            cir.setReturnValue(res);
        }
    }
}
