package carpet.helpers;
//Author: masa

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1542;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1900;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_8567;
import carpet.logging.logHelpers.ExplosionLogHelper;
import carpet.mixins.ExplosionAccessor;
import carpet.CarpetSettings;
import carpet.utils.Messenger;
import it.unimi.dsi.fastutil.objects.Object2DoubleOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import static carpet.script.CarpetEventServer.Event.EXPLOSION_OUTCOME;

public class OptimizedExplosion
{
    private static List<class_1297> entitylist;
    private static class_243 vec3dmem;
    private static long tickmem;
    // For disabling the explosion particles and sound
    public static int explosionSound = 0;

    // masa's optimizations
    private static Object2DoubleOpenHashMap<Pair<class_243, class_238>> densityCache = new Object2DoubleOpenHashMap<>();
    private static MutablePair<class_243, class_238> pairMutable = new MutablePair<>();
    private static Object2ObjectOpenHashMap<class_2338, class_2680> stateCache = new Object2ObjectOpenHashMap<>();
    private static Object2ObjectOpenHashMap<class_2338, class_3610> fluidCache = new Object2ObjectOpenHashMap<>();
    private static class_2338.class_2339 posMutable = new class_2338.class_2339(0, 0, 0);
    private static ObjectOpenHashSet<class_2338> affectedBlockPositionsSet = new ObjectOpenHashSet<>();
    private static boolean firstRay;
    private static boolean rayCalcDone;
    private static ArrayList<Float> chances = new ArrayList<>();
    private static class_2338 blastChanceLocation;

    // Creating entity list for scarpet event
    private static List<class_1297> entityList = new ArrayList<>();

    public static void doExplosionA(class_1927 e, ExplosionLogHelper eLogger) {
        ExplosionAccessor eAccess = (ExplosionAccessor) e;
        
        entityList.clear();
        boolean eventNeeded = EXPLOSION_OUTCOME.isNeeded() && !eAccess.getLevel().method_8608();
        blastCalc(e);

        if (!CarpetSettings.explosionNoBlockDamage) {
            rayCalcDone = false;
            firstRay = true;
            getAffectedPositionsOnPlaneY(e,  0,  0, 15,  0, 15); // bottom
            getAffectedPositionsOnPlaneY(e, 15,  0, 15,  0, 15); // top
            getAffectedPositionsOnPlaneX(e,  0,  1, 14,  0, 15); // west
            getAffectedPositionsOnPlaneX(e, 15,  1, 14,  0, 15); // east
            getAffectedPositionsOnPlaneZ(e,  0,  1, 14,  1, 14); // north
            getAffectedPositionsOnPlaneZ(e, 15,  1, 14,  1, 14); // south
            stateCache.clear();
            fluidCache.clear();

            e.method_8346().addAll(affectedBlockPositionsSet);
            affectedBlockPositionsSet.clear();
        }

        float f3 = eAccess.getRadius() * 2.0F;
        int k1 = class_3532.method_15357(eAccess.getX() - (double) f3 - 1.0D);
        int l1 = class_3532.method_15357(eAccess.getX() + (double) f3 + 1.0D);
        int i2 = class_3532.method_15357(eAccess.getY() - (double) f3 - 1.0D);
        int i1 = class_3532.method_15357(eAccess.getY() + (double) f3 + 1.0D);
        int j2 = class_3532.method_15357(eAccess.getZ() - (double) f3 - 1.0D);
        int j1 = class_3532.method_15357(eAccess.getZ() + (double) f3 + 1.0D);
        class_243 vec3d = new class_243(eAccess.getX(), eAccess.getY(), eAccess.getZ());

        if (vec3dmem == null || !vec3dmem.equals(vec3d) || tickmem != eAccess.getLevel().method_8510()) {
            vec3dmem = vec3d;
            tickmem = eAccess.getLevel().method_8510();
            entitylist = eAccess.getLevel().method_8335(null, new class_238(k1, i2, j2, l1, i1, j1));
            explosionSound = 0;
        }

        explosionSound++;

        class_1297 explodingEntity = eAccess.getSource();
        for (int k2 = 0; k2 < entitylist.size(); ++k2) {
            class_1297 entity = entitylist.get(k2);


            if (entity == explodingEntity) {
                // entitylist.remove(k2);
                removeFast(entitylist, k2);
                k2--;
                continue;
            }

            if (entity instanceof class_1541 && explodingEntity != null &&
                    entity.method_23317() == explodingEntity.method_23317() &&
                    entity.method_23318() == explodingEntity.method_23318() &&
                    entity.method_23321() == explodingEntity.method_23321()) {
                if (eLogger != null) {
                    eLogger.onEntityImpacted(entity, new class_243(0,-0.9923437498509884d, 0));
                }
                continue;
            }

            if (!entity.method_5659()) {
                double d12 = Math.sqrt(entity.method_5649(eAccess.getX(), eAccess.getY(), eAccess.getZ())) / (double) f3;

                if (d12 <= 1.0D) {
                    double d5 = entity.method_23317() - eAccess.getX();
                    // Change in 1.16 snapshots to fix a bug with TNT jumping
                    double d7 = (entity instanceof class_1541 ? entity.method_23318() : entity.method_23320()) - eAccess.getY();
                    double d9 = entity.method_23321() - eAccess.getZ();
                    double d13 = (double) Math.sqrt(d5 * d5 + d7 * d7 + d9 * d9);

                    if (d13 != 0.0D) {
                        d5 = d5 / d13;
                        d7 = d7 / d13;
                        d9 = d9 / d13;
                        double density;

                        pairMutable.setLeft(vec3d);
                        pairMutable.setRight(entity.method_5829());
                        density = densityCache.getOrDefault(pairMutable, Double.MAX_VALUE);

                        if (density == Double.MAX_VALUE)
                        {
                            Pair<class_243, class_238> pair = Pair.of(vec3d, entity.method_5829());
                            density = class_1927.method_17752(vec3d, entity);
                            densityCache.put(pair, density);
                        }

                        // If it is needed, it saves the entity
                        if (eventNeeded) {
                            entityList.add(entity);
                        }

                        double d10 = (1.0D - d12) * density;
                        entity.method_5643(e.method_8349(),
                                (float) ((int) ((d10 * d10 + d10) / 2.0D * 7.0D * (double) f3 + 1.0D)));
                        double d11 = d10;

                        if (entity instanceof class_1309) {
                            d11 = class_1900.method_8237((class_1309) entity, d10);
                        }

                        if (eLogger != null) {
                            eLogger.onEntityImpacted(entity, new class_243(d5 * d11, d7 * d11, d9 * d11));
                        }

                        entity.method_18799(entity.method_18798().method_1031(d5 * d11, d7 * d11, d9 * d11));

                        if (entity instanceof class_1657 player) {

                            if (!player.method_7325()
                                    && (!player.method_7337() || !player.method_31549().field_7479)) {  //getAbilities
                                e.method_8351().put(player, new class_243(d5 * d10, d7 * d10, d9 * d10));
                            }
                        }
                    }
                }
            }
        }

        densityCache.clear();
    }

    public static void doExplosionB(class_1927 e, boolean spawnParticles)
    {
        ExplosionAccessor eAccess = (ExplosionAccessor) e; 
        class_1937 world = eAccess.getLevel();
        double posX = eAccess.getX();
        double posY = eAccess.getY();
        double posZ = eAccess.getZ();

        // If it is needed, calls scarpet event
        if (EXPLOSION_OUTCOME.isNeeded() && !world.method_8608()) {
            EXPLOSION_OUTCOME.onExplosion((class_3218) world, eAccess.getSource(), e::method_8347,  eAccess.getX(), eAccess.getY(), eAccess.getZ(), eAccess.getRadius(), eAccess.isFire(), e.method_8346(), entityList, eAccess.getBlockInteraction());
        }

        boolean damagesTerrain = eAccess.getBlockInteraction() != class_1927.class_4179.field_40878;

        // explosionSound incremented till disabling the explosion particles and sound
        if (explosionSound < 100 || explosionSound % 100 == 0)
        {
            world.method_43128(null, posX, posY, posZ, class_3417.field_15152, class_3419.field_15245, 4.0F,
                    (1.0F + (world.field_9229.method_43057() - world.field_9229.method_43057()) * 0.2F) * 0.7F);

            if (spawnParticles)
            {
                if (eAccess.getRadius() >= 2.0F && damagesTerrain)
                {
                    world.method_8406(class_2398.field_11221, posX, posY, posZ, 1.0D, 0.0D, 0.0D);
                }
                else
                {
                    world.method_8406(class_2398.field_11236, posX, posY, posZ, 1.0D, 0.0D, 0.0D);
                }
            }
        }

        if (damagesTerrain)
        {
            ObjectArrayList<Pair<class_1799, class_2338>> objectArrayList = new ObjectArrayList<>();
            class_156.method_43028((ObjectArrayList<class_2338>) e.method_8346(), world.field_9229);

            boolean dropFromExplosions = CarpetSettings.xpFromExplosions || e.method_8347() instanceof class_1657;

            for (class_2338 blockpos : e.method_8346())
            {
                class_2680 state = world.method_8320(blockpos);
                class_2248 block = state.method_26204();

                if (!state.method_26215())
                {
                    if (block.method_9533(e) && world instanceof class_3218 serverLevel)
                    {
                        class_2586 blockEntity = state.method_31709() ? world.method_8321(blockpos) : null;  //hasBlockEntity()

                        class_8567.class_8568 lootBuilder = (new class_8567.class_8568((class_3218)eAccess.getLevel()))
                                .method_51874(class_181.field_24424, class_243.method_24953(blockpos))
                                .method_51874(class_181.field_1229, class_1799.field_8037)
                                .method_51877(class_181.field_1228, blockEntity)
                                .method_51877(class_181.field_1226, eAccess.getSource());

                        if (eAccess.getBlockInteraction() == class_1927.class_4179.field_40879)
                            lootBuilder.method_51874(class_181.field_1225, eAccess.getRadius());

                        state.method_26180(serverLevel, blockpos, class_1799.field_8037, dropFromExplosions);

                        state.method_26189(lootBuilder).forEach((itemStackx) -> {
                            method_24023(objectArrayList, itemStackx, blockpos.method_10062());
                        });
                    }

                    world.method_8652(blockpos, class_2246.field_10124.method_9564(), 3);
                    block.method_9586(world, blockpos, e);
                }
            }
            objectArrayList.forEach(p -> class_2248.method_9577(world, p.getRight(), p.getLeft()));

        }

        if (eAccess.isFire())
        {
            for (class_2338 blockpos1 : e.method_8346())
            {
                // Use the same Chunk reference because the positions are in the same xz-column
                class_2791 chunk = world.method_8497(blockpos1.method_10263() >> 4, blockpos1.method_10260() >> 4);

                class_2338 down = blockpos1.method_10087(1);
                if (eAccess.getRandom().method_43048(3) == 0 &&
                        chunk.method_8320(blockpos1).method_26215() &&
                        chunk.method_8320(down).method_26216(world, down)
                        )
                {
                    world.method_8501(blockpos1, class_2246.field_10036.method_9564());
                }
            }
        }
    }

    // copied from Explosion, need to move the code to the explosion code anyways and use shadows for
    // simplicity, its not jarmodding anyways
    private static void method_24023(ObjectArrayList<Pair<class_1799, class_2338>> objectArrayList, class_1799 itemStack, class_2338 blockPos) {
        int i = objectArrayList.size();

        for(int j = 0; j < i; ++j) {
            Pair<class_1799, class_2338> pair = objectArrayList.get(j);
            class_1799 itemStack2 = pair.getLeft();
            if (class_1542.method_24017(itemStack2, itemStack)) {
                class_1799 itemStack3 = class_1542.method_24018(itemStack2, itemStack, 16);
                objectArrayList.set(j, Pair.of(itemStack3, pair.getRight()));
                if (itemStack.method_7960()) {
                    return;
                }
            }
        }

        objectArrayList.add(Pair.of(itemStack, blockPos));
    }

    private static void removeFast(List<class_1297> lst, int index) {
        if (index < lst.size() - 1)
            lst.set(index, lst.get(lst.size() - 1));
        lst.remove(lst.size() - 1);
    }

    private static void rayCalcs(class_1927 e) {
        ExplosionAccessor eAccess = (ExplosionAccessor) e;
        boolean first = true;

        for (int j = 0; j < 16; ++j) {
            for (int k = 0; k < 16; ++k) {
                for (int l = 0; l < 16; ++l) {
                    if (j == 0 || j == 15 || k == 0 || k == 15 || l == 0 || l == 15) {
                        double d0 = (double) ((float) j / 15.0F * 2.0F - 1.0F);
                        double d1 = (double) ((float) k / 15.0F * 2.0F - 1.0F);
                        double d2 = (double) ((float) l / 15.0F * 2.0F - 1.0F);
                        double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
                        d0 = d0 / d3;
                        d1 = d1 / d3;
                        d2 = d2 / d3;
                        float rand = eAccess.getLevel().field_9229.method_43057();
                        if (CarpetSettings.tntRandomRange >= 0) {
                            rand = (float) CarpetSettings.tntRandomRange;
                        }
                        float f = eAccess.getRadius() * (0.7F + rand * 0.6F);
                        double d4 = eAccess.getX();
                        double d6 = eAccess.getY();
                        double d8 = eAccess.getZ();

                        for (float f1 = 0.3F; f > 0.0F; f -= 0.22500001F) {
                            class_2338 blockpos = class_2338.method_49637(d4, d6, d8);
                            class_2680 state = eAccess.getLevel().method_8320(blockpos);
                            class_3610 fluidState = eAccess.getLevel().method_8316(blockpos);

                            if (!state.method_26215()) {
                                float f2 = Math.max(state.method_26204().method_9520(), fluidState.method_15760());
                                if (eAccess.getSource() != null)
                                    f2 = eAccess.getSource().method_5774(e, eAccess.getLevel(), blockpos, state, fluidState, f2);
                                f -= (f2 + 0.3F) * 0.3F;
                            }

                            if (f > 0.0F && (eAccess.getSource() == null ||
                                    eAccess.getSource().method_5853(e, eAccess.getLevel(), blockpos, state, f)))
                            {
                                affectedBlockPositionsSet.add(blockpos);
                            }
                            else if (first) {
                                return;
                            }

                            first = false;

                            d4 += d0 * 0.30000001192092896D;
                            d6 += d1 * 0.30000001192092896D;
                            d8 += d2 * 0.30000001192092896D;
                        }
                    }
                }
            }
        }
    }

    private static void getAffectedPositionsOnPlaneX(class_1927 e, int x, int yStart, int yEnd, int zStart, int zEnd)
    {
        if (!rayCalcDone)
        {
            final double xRel = (double) x / 15.0D * 2.0D - 1.0D;

            for (int z = zStart; z <= zEnd; ++z)
            {
                double zRel = (double) z / 15.0D * 2.0D - 1.0D;

                for (int y = yStart; y <= yEnd; ++y)
                {
                    double yRel = (double) y / 15.0D * 2.0D - 1.0D;

                    if (checkAffectedPosition(e, xRel, yRel, zRel))
                    {
                        return;
                    }
                }
            }
        }
    }

    private static void getAffectedPositionsOnPlaneY(class_1927 e, int y, int xStart, int xEnd, int zStart, int zEnd)
    {
        if (!rayCalcDone)
        {
            final double yRel = (double) y / 15.0D * 2.0D - 1.0D;

            for (int z = zStart; z <= zEnd; ++z)
            {
                double zRel = (double) z / 15.0D * 2.0D - 1.0D;

                for (int x = xStart; x <= xEnd; ++x)
                {
                    double xRel = (double) x / 15.0D * 2.0D - 1.0D;

                    if (checkAffectedPosition(e, xRel, yRel, zRel))
                    {
                        return;
                    }
                }
            }
        }
    }

    private static void getAffectedPositionsOnPlaneZ(class_1927 e, int z, int xStart, int xEnd, int yStart, int yEnd)
    {
        if (!rayCalcDone)
        {
            final double zRel = (double) z / 15.0D * 2.0D - 1.0D;

            for (int x = xStart; x <= xEnd; ++x)
            {
                double xRel = (double) x / 15.0D * 2.0D - 1.0D;

                for (int y = yStart; y <= yEnd; ++y)
                {
                    double yRel = (double) y / 15.0D * 2.0D - 1.0D;

                    if (checkAffectedPosition(e, xRel, yRel, zRel))
                    {
                        return;
                    }
                }
            }
        }
    }

    private static boolean checkAffectedPosition(class_1927 e, double xRel, double yRel, double zRel)
    {
        ExplosionAccessor eAccess = (ExplosionAccessor) e;
        double len = Math.sqrt(xRel * xRel + yRel * yRel + zRel * zRel);
        double xInc = (xRel / len) * 0.3;
        double yInc = (yRel / len) * 0.3;
        double zInc = (zRel / len) * 0.3;
        float rand = eAccess.getLevel().field_9229.method_43057();
        float sizeRand = (CarpetSettings.tntRandomRange >= 0 ? (float) CarpetSettings.tntRandomRange : rand);
        float size = eAccess.getRadius() * (0.7F + sizeRand * 0.6F);
        double posX = eAccess.getX();
        double posY = eAccess.getY();
        double posZ = eAccess.getZ();

        for (float f1 = 0.3F; size > 0.0F; size -= 0.22500001F)
        {
            posMutable.method_10102(posX, posY, posZ);

            // Don't query already cached positions again from the world
            class_2680 state = stateCache.get(posMutable);
            class_3610 fluid = fluidCache.get(posMutable);
            class_2338 posImmutable = null;

            if (state == null)
            {
                posImmutable = posMutable.method_10062();
                state = eAccess.getLevel().method_8320(posImmutable);
                stateCache.put(posImmutable, state);
                fluid = eAccess.getLevel().method_8316(posImmutable);
                fluidCache.put(posImmutable, fluid);
            }

            if (!state.method_26215())
            {
                float resistance = Math.max(state.method_26204().method_9520(), fluid.method_15760());

                if (eAccess.getSource() != null)
                {
                    resistance = eAccess.getSource().method_5774(e, eAccess.getLevel(), posMutable, state, fluid, resistance);
                }

                size -= (resistance + 0.3F) * 0.3F;
            }

            if (size > 0.0F)
            {
                if ((eAccess.getSource() == null || eAccess.getSource().method_5853(e, eAccess.getLevel(), posMutable, state, size)))
                    affectedBlockPositionsSet.add(posImmutable != null ? posImmutable : posMutable.method_10062());
            }
            else if (firstRay)
            {
                rayCalcDone = true;
                return true;
            }

            firstRay = false;

            posX += xInc;
            posY += yInc;
            posZ += zInc;
        }

        return false;
    }

    public static void setBlastChanceLocation(class_2338 p){
        blastChanceLocation = p;
    }

    private static void blastCalc(class_1927 e){
        ExplosionAccessor eAccess = (ExplosionAccessor) e;
        if(blastChanceLocation == null || blastChanceLocation.method_40081(eAccess.getX(), eAccess.getY(), eAccess.getZ()) > 200) return;
        chances.clear();
        for (int j = 0; j < 16; ++j) {
            for (int k = 0; k < 16; ++k) {
                for (int l = 0; l < 16; ++l) {
                    if (j == 0 || j == 15 || k == 0 || k == 15 || l == 0 || l == 15) {
                        double d0 = (double) ((float) j / 15.0F * 2.0F - 1.0F);
                        double d1 = (double) ((float) k / 15.0F * 2.0F - 1.0F);
                        double d2 = (double) ((float) l / 15.0F * 2.0F - 1.0F);
                        double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
                        d0 = d0 / d3;
                        d1 = d1 / d3;
                        d2 = d2 / d3;
                        float f = eAccess.getRadius() * (0.7F + 0.6F);
                        double d4 = eAccess.getX();
                        double d6 = eAccess.getY();
                        double d8 = eAccess.getZ();
                        boolean found = false;

                        for (float f1 = 0.3F; f > 0.0F; f -= 0.22500001F) {
                            class_2338 blockpos = class_2338.method_49637(d4, d6, d8);
                            class_2680 state = eAccess.getLevel().method_8320(blockpos);
                            class_3610 fluidState = eAccess.getLevel().method_8316(blockpos);

                            if (!state.method_26215()) {
                                float f2 = Math.max(state.method_26204().method_9520(), fluidState.method_15760());
                                if (eAccess.getSource() != null)
                                    f2 = eAccess.getSource().method_5774(e, eAccess.getLevel(), blockpos, state, fluidState, f2);
                                f -= (f2 + 0.3F) * 0.3F;
                            }

                            if (f > 0.0F && (eAccess.getSource() == null ||
                                    eAccess.getSource().method_5853(e, eAccess.getLevel(), blockpos, state, f))) {
                                if(!found && blockpos.equals(blastChanceLocation)){
                                    chances.add(f);
                                    found = true;
                                }
                            }

                            d4 += d0 * 0.30000001192092896D;
                            d6 += d1 * 0.30000001192092896D;
                            d8 += d2 * 0.30000001192092896D;
                        }
                    }
                }
            }
        }

        //showTNTblastChance(e);
    }

    private static void showTNTblastChance(class_1927 e){
        ExplosionAccessor eAccess = (ExplosionAccessor) e;
        double randMax = 0.6F * eAccess.getRadius();
        double total = 0;
        boolean fullyBlownUp = false;
        boolean first = true;
        int rays = 0;
        for(float f3 : chances){
            rays++;
            double calc = f3 - randMax;
            if(calc > 0) fullyBlownUp = true;
            double chancePerRay = (Math.abs(calc) / randMax);
            if(!fullyBlownUp){
                if(first){
                    first = false;
                    total = chancePerRay;
                }else {
                    total = total * chancePerRay;
                }
            }
        }
        if(fullyBlownUp) total = 0;
        double chance = 1 - total;
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setRoundingMode (RoundingMode.DOWN);
        nf.setMaximumFractionDigits(2);
        for(class_1657 player : eAccess.getLevel().method_18456()){
            Messenger.m(player,"w Pop: ",
                    "c " + nf.format(chance) + " ",
                    "^w Chance for the block to be destroyed by the blast: " + chance,
                    "?" + chance,
                    "w Remain: ",
                    String.format("c %.2f ", total),
                    "^w Chance the block survives the blast: " + total,
                    "?" + total,
                    "w Rays: ",
                    String.format("c %d ", rays),
                    "^w TNT blast rays going through the block",
                    "?" + rays,
                    "w Size: ",
                    String.format("c %.1f ", eAccess.getRadius()),
                    "^w TNT blast size",
                    "?" + eAccess.getRadius(),
                    "w @: ",
                    String.format("c [%.1f %.1f %.1f] ", eAccess.getX(), eAccess.getY(), eAccess.getZ()),
                    "^w TNT blast location X:" + eAccess.getX() + " Y:" + eAccess.getY() + " Z:" + eAccess.getZ(),
                    "?" + eAccess.getX() + " " + eAccess.getY() + " " + eAccess.getZ()
            );
        }
    }
}
