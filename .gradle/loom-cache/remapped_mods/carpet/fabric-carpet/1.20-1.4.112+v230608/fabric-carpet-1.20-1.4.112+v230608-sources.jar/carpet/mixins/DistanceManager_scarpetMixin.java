package carpet.mixins;

import carpet.fakes.ChunkTicketManagerInterface;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.class_3204;
import net.minecraft.class_3228;
import net.minecraft.class_4706;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_3204.class)
public abstract class DistanceManager_scarpetMixin implements ChunkTicketManagerInterface
{
    @Shadow @Final private Long2ObjectOpenHashMap<class_4706<class_3228<?>>> tickets;

    @Override
    public Long2ObjectOpenHashMap<class_4706<class_3228<?>>>  getTicketsByPosition()
    {
        return tickets;
    }

}
