package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1703.class)
public abstract class AbstractContainerMenu_ctrlQCraftingMixin
{

    @Shadow public abstract void clicked(int int_1, int int_2, class_1713 slotActionType_1, class_1657 playerEntity_1);
    
    @Shadow public abstract void broadcastChanges();

    @Shadow @Final public class_2371<class_1735> slots;

    @Shadow protected abstract void resetQuickCraft();

    @Shadow public abstract class_1799 getCarried();

    @Inject( method = "doClick", at = @At(value = "HEAD"), cancellable = true)
    private void onThrowClick(int slotId, int clickData, class_1713 actionType, class_1657 playerEntity, CallbackInfo ci)
    {
        if (actionType == class_1713.field_7795 && CarpetSettings.ctrlQCraftingFix && this.getCarried().method_7960() && slotId >= 0)
        {
            class_1735 slot_4 = slots.get(slotId);
            if (/*slot_4 != null && */slot_4.method_7681() && slot_4.method_7674(playerEntity))
            {
                if(slotId == 0 && clickData == 1)
                {
                    class_1792 craftedItem = slot_4.method_7677().method_7909();
                    while(slot_4.method_7681() && slot_4.method_7677().method_7909() == craftedItem)
                    {
                        this.clicked(slotId, 0, class_1713.field_7795, playerEntity);
                    }
                    this.broadcastChanges();
                    this.resetQuickCraft();
                    ci.cancel();
                }
            }
        }
    }
}
