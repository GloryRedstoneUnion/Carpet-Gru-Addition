@ParametersAreNonnullByDefault
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
package carpet.script.value;

import javax.annotation.ParametersAreNonnullByDefault;
