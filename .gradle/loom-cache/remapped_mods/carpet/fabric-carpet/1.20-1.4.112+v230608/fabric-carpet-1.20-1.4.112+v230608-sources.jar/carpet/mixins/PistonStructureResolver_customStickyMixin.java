package carpet.mixins;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import carpet.fakes.BlockBehaviourInterface;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2674;
import net.minecraft.class_2680;

@Mixin(class_2674.class)
public class PistonStructureResolver_customStickyMixin {

    @Shadow @Final private class_1937 level;
    @Shadow @Final private class_2350 pushDirection;

    @Inject(
        method = "isSticky",
        cancellable = true,
        at = @At(
            value = "HEAD"
        )
    )
    private static void isSticky(class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(((BlockBehaviourInterface)state.method_26204()).isSticky(state));
    }

    // fields that are needed because @Redirects cannot capture locals
    private class_2338 pos_addBlockLine;
    private class_2338 behindPos_addBlockLine;

    @Inject(
        method = "addBlockLine",
        locals = LocalCapture.CAPTURE_FAILHARD,
        at = @At(
            value = "INVOKE",
            ordinal = 1,
            target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
        )
    )
    private void captureBlockLinePositions(class_2338 pos, class_2350 fromDir, CallbackInfoReturnable<Boolean> cir, class_2680 state, int dst, class_2338 behindPos) {
        pos_addBlockLine = behindPos.method_10093(pushDirection);
        behindPos_addBlockLine = behindPos;
    }

    @Redirect(
        method = "addBlockLine",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/piston/PistonStructureResolver;canStickToEachOther(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;)Z"
        )
    )
    private boolean onAddBlockLineCanStickToEachOther(class_2680 state, class_2680 behindState) {
        return ((BlockBehaviourInterface)state.method_26204()).isStickyToNeighbor(level, pos_addBlockLine, state, behindPos_addBlockLine, behindState, pushDirection.method_10153(), pushDirection);
    }

    // fields that are needed because @Redirects cannot capture locals
    private class_2350 dir_addBranchingBlocks;
    private class_2338 neighborPos_addBranchingBlocks;

    @Inject(
        method = "addBranchingBlocks",
        locals = LocalCapture.CAPTURE_FAILHARD,
        at = @At(
            value = "INVOKE",
            ordinal = 1,
            target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
        )
    )
    private void captureNeighborPositions(class_2338 pos, CallbackInfoReturnable<Boolean> cir, class_2680 state, class_2350[] dirs, int i, int j, class_2350 dir, class_2338 neighborPos) {
        dir_addBranchingBlocks = dir;
        neighborPos_addBranchingBlocks = neighborPos;
    }

    @Redirect(
        method = "addBranchingBlocks",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/piston/PistonStructureResolver;canStickToEachOther(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;)Z"
        )
    )
    private boolean onAddBranchingBlocksCanStickToEachOther(class_2680 neighborState, class_2680 state, class_2338 pos) {
        return ((BlockBehaviourInterface)state.method_26204()).isStickyToNeighbor(level, pos, state, neighborPos_addBranchingBlocks, neighborState, dir_addBranchingBlocks, pushDirection);
    }
}
