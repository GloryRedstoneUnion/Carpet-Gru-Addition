package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2674;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(value = class_2674.class, priority = 420)  // piston push limit is important for carpet
public class PistonStructureResolver_pushLimitMixin
{
    @ModifyConstant(method = "addBlockLine", constant = @Constant(intValue = class_2674.field_31384), expect = 3)
    private int pushLimit(int original)
    {
        return CarpetSettings.pushLimit;
    }
}
